@echo off
cd /d "%~dp0android-app"
echo ===== ZalupaMusic: building Android APK =====

rem ---- search for JDK 17 or 21 (Gradle does not work with newer Java) ----
set "JDK="
if defined JAVA_HOME call :try "%JAVA_HOME%"
if not defined JDK if exist "%~dp0jdk-path.txt" for /f "usebackq delims=" %%L in ("%~dp0jdk-path.txt") do call :try "%%L"
if not defined JDK for %%P in ("%ProgramFiles%\Android\Android Studio\jbr" "%ProgramFiles%\Android\Android Studio\jre" "%LOCALAPPDATA%\Programs\Android Studio\jbr" "%ProgramFiles%\Android\Android Studio Preview\jbr") do call :try "%%~P"
if not defined JDK for /d %%D in ("%ProgramFiles%\Eclipse Adoptium\jdk-21*" "%ProgramFiles%\Eclipse Adoptium\jdk-17*" "%ProgramFiles%\Microsoft\jdk-21*" "%ProgramFiles%\Java\jdk-21*" "%ProgramFiles%\Java\jdk-17*") do call :try "%%~D"
if not defined JDK for %%R in ("%ProgramFiles%\Android" "%LOCALAPPDATA%\Programs" "%LOCALAPPDATA%\JetBrains" "%ProgramFiles%\JetBrains" "%ProgramFiles%\Eclipse Adoptium" "%ProgramFiles%\Microsoft" "%ProgramFiles%\Java") do if not defined JDK if exist "%%~R" for /f "delims=" %%F in ('where /r "%%~R" java.exe 2^>nul') do if not defined JDK call :tryexe "%%F"

if defined JDK goto java_ok
echo.
echo [!] JDK 17 or 21 not found. Other versions will not work with this build.
echo     Install JDK 21 with this command, then run build-apk.bat again:
echo       winget install EclipseAdoptium.Temurin.21.JDK
goto fail

:java_ok
set "JAVA_HOME=%JDK%"
echo Using JDK: %JAVA_HOME%
if not defined ANDROID_HOME if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"

echo [1/6] Installing dependencies...
call npm install
if errorlevel 1 goto fail

echo [2/6] Building web part...
call npm run web
if errorlevel 1 goto fail

echo [3/6] Creating Android project...
if exist android goto have_android
call npx cap add android
if errorlevel 1 goto fail
:have_android

echo [4/6] Icons and manifest...
call npx capacitor-assets generate --android
if errorlevel 1 echo [!] Icons were not generated - default icon will be used
call node scripts\patch-android.js
if errorlevel 1 goto fail

echo [5/6] Syncing...
call npx cap sync android
if errorlevel 1 goto fail

echo [6/6] Building APK - first build takes 5-15 minutes...
cd android
call gradlew.bat --stop >nul 2>nul
call gradlew.bat assembleDebug
if errorlevel 1 goto fail
cd ..

if not exist "..\dist" mkdir "..\dist"
copy /y "android\app\build\outputs\apk\debug\app-debug.apk" "..\dist\ZalupaMusic.apk" >nul
if errorlevel 1 goto fail

echo.
echo DONE. APK: dist\ZalupaMusic.apk
echo Copy it to your phone and install it.
explorer "..\dist"
pause
exit /b 0

:fail
echo.
echo ERROR. Copy the text above and send it to me.
pause
exit /b 1

rem ---- helpers ----
:try
if defined JDK exit /b 0
if not exist "%~1\bin\java.exe" exit /b 0
set "JOK="
"%~1\bin\java.exe" -version 2>&1 | findstr /c:"version \"21." /c:"version \"17." >nul && set "JOK=1"
if defined JOK set "JDK=%~1"
exit /b 0

:tryexe
for %%G in ("%~dp1..") do call :try "%%~fG"
exit /b 0
