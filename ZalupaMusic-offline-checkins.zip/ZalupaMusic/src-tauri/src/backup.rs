use crate::moments::{media_path, read, write, Result, LOCK};
use base64::{engine::general_purpose::STANDARD, Engine};
use flate2::{read::GzDecoder, write::GzEncoder, Compression};
use serde_json::{json, Map, Value};
use std::{collections::HashSet, fs, io::{Read, Write}, path::{Path, PathBuf}};

const PREFS: &[&str] = &["settings", "theme", "eq", "xfade", "volume", "perf"];

fn layer(state: &Value, keys: &[&str]) -> Value {
    Value::Object(keys.iter().filter_map(|key| state.get(*key).map(|v| (key.to_string(), v.clone()))).collect())
}

fn files<'a>(state: &'a Value, dir: &Path) -> impl Iterator<Item = (String, PathBuf)> + 'a {
    let dir = dir.to_owned();
    let mut seen = HashSet::new();
    state["checkins"].as_array().into_iter().flatten().filter_map(move |entry| {
        let path = entry["media"].as_str()?;
        (media_path(path) && seen.insert(path.to_owned())).then(|| (path.to_owned(), dir.join(path)))
    })
}

fn size(path: impl AsRef<Path>) -> u64 {
    fs::metadata(path).map_or(0, |meta| meta.len())
}

#[tauri::command]
pub async fn backup_sizes(app: tauri::AppHandle) -> Result<Value> {
    let dir = super::data_dir(&app)?;
    let _guard = LOCK.lock().map_err(|e| e.to_string())?;
    let state = read(&dir)?;
    let bytes = |keys: &[&str]| layer(&state, keys).to_string().len();
    Ok(json!({
        "profile": bytes(&["profile", "stats"]),
        "library": bytes(&["tracks", "playlists"]),
        "checkins": bytes(&["checkins"]),
        "settings": bytes(PREFS),
        "media": files(&state, &dir).map(|(_, p)| size(p)).sum::<u64>(),
        "audio": state["tracks"].as_array().into_iter().flatten()
            .filter_map(|t| t["path"].as_str()).map(size).sum::<u64>()
    }))
}

#[tauri::command]
pub async fn create_backup(app: tauri::AppHandle, path: String, selected: Vec<String>) -> Result<()> {
    let dir = super::data_dir(&app)?;
    let _guard = LOCK.lock().map_err(|e| e.to_string())?;
    let state = read(&dir)?;
    let target = PathBuf::from(path);
    let has = |key: &str| selected.iter().any(|item| item == key);
    let mut data = Map::new();
    for (name, keys) in [
        ("profile", &["profile", "stats"][..]), ("library", &["tracks", "playlists"][..]),
        ("checkins", &["checkins"][..]), ("settings", PREFS),
    ] {
        if has(name) {
            data.extend(layer(&state, keys).as_object().unwrap().clone());
        }
    }
    if let Some(tracks) = data.get_mut("tracks").and_then(Value::as_array_mut) {
        for track in tracks {
            if let Some(obj) = track.as_object_mut() {
                obj.remove("cover");
                obj.remove("path");
                obj.remove("coverChecked");
            }
        }
    }
    let mut media = Map::new();
    if has("media") {
        for (relative, file) in files(&state, &dir) {
            if file.is_file() {
                let bytes = fs::read(file).map_err(|e| e.to_string())?;
                media.insert(relative, json!(STANDARD.encode(bytes)));
            }
        }
    }
    let mut audio = Vec::new();
    let staging = if has("audio") {
        if target.exists() { return Err("Папка назначения уже существует".into()); }
        let parent = target.parent().ok_or("Нет папки назначения")?;
        Some(tempfile::tempdir_in(parent).map_err(|e| e.to_string())?)
    } else { None };
    if let Some(folder) = &staging {
        for (index, track) in state["tracks"].as_array().into_iter().flatten().enumerate() {
            let Some(path) = track["path"].as_str() else { continue };
            let source = Path::new(path);
            if !source.is_file() { continue; }
            let ext = source.extension().and_then(|e| e.to_str())
                .filter(|e| e.len() <= 8 && e.bytes().all(|b| b.is_ascii_alphanumeric())).unwrap_or("audio");
            let name = format!("{index}.{ext}");
            fs::copy(source, folder.path().join(&name)).map_err(|e| e.to_string())?;
            audio.push(json!({"id": track["id"], "file": name, "title": track["title"], "artist": track["artist"]}));
        }
    }
    let manifest = json!({"format": "zalupamusic-backup", "version": 1, "data": data, "media": media, "audio": audio});
    if let Some(folder) = staging {
        write(&folder.path().join("backup.json"), manifest.to_string().as_bytes())?;
        fs::rename(folder.path(), &target).map_err(|e| e.to_string())?;
        Ok(())
    } else {
        let mut encoder = GzEncoder::new(Vec::new(), Compression::fast());
        serde_json::to_writer(&mut encoder, &manifest).map_err(|e| e.to_string())?;
        let bytes = encoder.finish().map_err(|e| e.to_string())?;
        write(&target, &bytes)
    }
}

fn merge_rows(state: &mut Value, data: &Value, key: &str) {
    let Some(incoming) = data[key].as_array() else { return };
    if !state[key].is_array() { state[key] = json!([]); }
    let current = state[key].as_array_mut().unwrap();
    for row in incoming {
        if row["id"].is_string() && !current.iter().any(|old| old["id"] == row["id"]) {
            let mut row = row.clone();
            if key == "checkins" && (!row["title"].is_string() || !row["ts"].is_u64()
                || !row["tags"].as_array().is_some_and(|tags| tags.iter().all(Value::is_string))
                || !row["media"].as_str().is_some_and(media_path)) {
                continue;
            }
            if key == "playlists" && (!row["name"].is_string() || !row["trackIds"].is_array()) {
                continue;
            }
            if key == "tracks" {
                if !row["title"].is_string() || !row["artist"].is_string() || !row["tags"].is_array() {
                    continue;
                }
                row["path"] = json!("");
                row.as_object_mut().unwrap().remove("cover");
            }
            current.push(row);
        }
    }
}

#[tauri::command]
pub async fn restore_backup(app: tauri::AppHandle, path: String) -> Result<()> {
    let dir = super::data_dir(&app)?;
    let _guard = LOCK.lock().map_err(|e| e.to_string())?;
    let path = PathBuf::from(path);
    use std::io::BufRead;
    let mut file = std::io::BufReader::new(fs::File::open(&path).map_err(|e| e.to_string())?);
    let input: Box<dyn Read> = if file.fill_buf().map_err(|e| e.to_string())?.starts_with(&[0x1f, 0x8b]) {
        Box::new(GzDecoder::new(file))
    } else {
        Box::new(file)
    };
    let manifest: Value = serde_json::from_reader(std::io::BufReader::new(input)).map_err(|e| e.to_string())?;
    if manifest["format"] != "zalupamusic-backup" || manifest["version"] != 1 || !manifest["data"].is_object() {
        return Err("Неподдерживаемый формат бэкапа".into());
    }
    let data = &manifest["data"];
    let mut state = read(&dir)?;
    for key in ["tracks", "playlists", "checkins"] { merge_rows(&mut state, data, key); }
    if let Some(profile) = data["profile"].as_object() {
        for (key, value) in profile {
            if !value.is_null() { state["profile"][key] = value.clone(); }
        }
    }
    for key in ["plays", "secs"] {
        if let Some(values) = data["stats"][key].as_object() {
            for (id, value) in values {
                if let Some(count) = value.as_f64() {
                    if count > state["stats"][key][id].as_f64().unwrap_or(-1.0) {
                        state["stats"][key][id] = value.clone();
                    }
                }
            }
        }
    }
    for key in PREFS {
        if let Some(value) = data.get(*key) {
            if *key == "settings" {
                if let Some(values) = value.as_object() {
                    for (name, value) in values { state["settings"][name] = value.clone(); }
                }
            } else {
                state[*key] = value.clone();
            }
        }
    }
    let mut missing_media = Vec::new();
    if let Some(media) = manifest["media"].as_object() {
        for (relative, encoded) in media {
            if !media_path(relative) { return Err("Некорректный путь медиа в бэкапе".into()); }
            let file = dir.join(relative);
            if !file.exists() {
                let bytes = STANDARD.decode(encoded.as_str().ok_or("Некорректное медиа")?).map_err(|e| e.to_string())?;
                missing_media.push((file, bytes));
            }
        }
    }
    let mut restored_folders = Vec::new();
    for item in manifest["audio"].as_array().into_iter().flatten() {
        let name = item["file"].as_str().ok_or("Некорректное имя аудио")?;
        let (stem, ext) = name.split_once('.').ok_or("Некорректное имя аудио")?;
        if stem.is_empty() || ext.is_empty() || !stem.bytes().all(|c| c.is_ascii_digit())
            || !ext.bytes().all(|c| c.is_ascii_alphanumeric()) {
            return Err("Некорректное имя аудио".into());
        }
        let source = path.with_file_name(name);
        if !source.is_file() { return Err(format!("В бэкапе отсутствует {name}")); }
        let Some(id) = item["id"].as_str() else { continue };
        if !state["tracks"].is_array() { state["tracks"] = json!([]); }
        let tracks = state["tracks"].as_array_mut().unwrap();
        let index = tracks.iter().position(|t| t["id"] == id);
        if index.and_then(|i| tracks[i]["path"].as_str()).is_some_and(|p| Path::new(p).is_file()) { continue; }
        let folder = tempfile::tempdir_in(dir.join("music")).map_err(|e| e.to_string())?;
        let dest = folder.path().join(name);
        fs::copy(source, &dest).map_err(|e| e.to_string())?;
        restored_folders.push(folder);
        let value = json!(dest.to_string_lossy());
        if let Some(i) = index {
            tracks[i]["path"] = value;
            tracks[i]["coverChecked"] = json!(false);
        } else {
            tracks.push(json!({
                "id": id, "path": value, "title": item["title"].as_str().unwrap_or(name),
                "artist": item["artist"].as_str().unwrap_or(""), "tags": []
            }));
        }
    }
    let mut installed_media = Vec::new();
    let commit = (|| {
        for (path, bytes) in missing_media {
            write(&path, &bytes)?;
            installed_media.push(path);
        }
        write(&dir.join("state.json"), state.to_string().as_bytes())
    })();
    if let Err(error) = commit {
        for path in installed_media { let _ = fs::remove_file(path); }
        return Err(error);
    }
    for folder in restored_folders { let _ = folder.keep(); }
    Ok(())
}

