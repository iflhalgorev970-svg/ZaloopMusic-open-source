//! Мини-сервер для телефона: раздаёт библиотеку, аудио (с Range) и обложки по локальной сети.
//! Доступ только по секретному токену из QR-кода.

use serde_json::{json, Value};
use std::collections::hash_map::RandomState;
use std::fs;
use std::hash::{BuildHasher, Hasher};
use std::io::{Read, Seek, SeekFrom};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use tiny_http::{Header, Request, Response, Server, StatusCode};

const INDEX_HTML: &str = include_str!("../../mobile/index.html");
const M_CSS: &str = include_str!("../../mobile/m.css");
const M_JS: &str = include_str!("../../mobile/m.js");
const MANIFEST: &str = include_str!("../../mobile/manifest.webmanifest");
const ICON_192: &[u8] = include_bytes!("../../mobile/icon-192.png");
const ICON_512: &[u8] = include_bytes!("../../mobile/icon-512.png");

// сколько файлов сейчас отдаётся телефону и когда телефон обращался в последний раз (для анимации на ПК)
static ACTIVE: AtomicUsize = AtomicUsize::new(0);
static LAST_MS: AtomicU64 = AtomicU64::new(0);

fn now_ms() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

pub struct ServerInfo {
    pub port: u16,
    pub token: Arc<Mutex<String>>,
    dir: PathBuf,
}

fn rand_token() -> String {
    let mut out = String::new();
    for _ in 0..2 {
        let mut h = RandomState::new().build_hasher();
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_nanos() as u64)
            .unwrap_or(0);
        h.write_u64(nanos);
        out.push_str(&format!("{:016x}", h.finish()));
    }
    out
}

/// Все адреса ПК в локальных сетях: сначала похожие на домашний Wi-Fi (192.168.x.x),
/// виртуальные адаптеры (WSL, Hyper-V, Docker, VPN) — в самом конце.
fn lan_addrs() -> Vec<(String, String)> {
    let mut v: Vec<(u8, String, String)> = Vec::new();
    if let Ok(list) = local_ip_address::list_afinet_netifas() {
        for (name, ip) in list {
            if let std::net::IpAddr::V4(a) = ip {
                if a.is_loopback() || a.is_link_local() || a.is_unspecified() {
                    continue;
                }
                let o = a.octets();
                let lname = name.to_lowercase();
                let virt = ["vethernet", "wsl", "virtualbox", "vmware", "hyper-v", "docker", "vpn", "tailscale", "zerotier", "bluetooth", "loopback"]
                    .iter()
                    .any(|k| lname.contains(k));
                let rank: u8 = if virt {
                    9
                } else if o[0] == 192 && o[1] == 168 {
                    0
                } else if o[0] == 10 {
                    1
                } else if o[0] == 172 && (16..=31).contains(&o[1]) {
                    2
                } else {
                    4
                };
                v.push((rank, a.to_string(), name));
            }
        }
    }
    v.sort_by_key(|x| x.0);
    v.into_iter().map(|(_, ip, n)| (ip, n)).collect()
}

pub fn start(dir: PathBuf) -> Result<ServerInfo, String> {
    let tok_file = dir.join("server.json");
    let token = fs::read_to_string(&tok_file)
        .ok()
        .and_then(|s| serde_json::from_str::<Value>(&s).ok())
        .and_then(|v| v["token"].as_str().map(String::from))
        .filter(|t| t.len() >= 16)
        .unwrap_or_else(|| {
            let t = rand_token();
            let _ = fs::write(&tok_file, json!({ "token": t }).to_string());
            t
        });

    let mut bound = None;
    for port in 7878u16..7900 {
        if let Ok(s) = Server::http(("127.0.0.1", port)) {
            bound = Some((s, port));
            break;
        }
    }
    let (server, port) = bound.ok_or("нет свободного порта 7878-7899")?;

    let token = Arc::new(Mutex::new(token));
    let t2 = token.clone();
    let d2 = dir.clone();
    std::thread::spawn(move || {
        for rq in server.incoming_requests() {
            let t = t2.clone();
            let d = d2.clone();
            // отдельный поток на запрос: длинная отдача аудио не блокирует остальные
            std::thread::spawn(move || handle(rq, &d, &t));
        }
    });

    if let Ok(t) = token.lock() {
        let _ = fs::write(&tok_file, json!({ "token": *t, "port": port }).to_string());
    }
    Ok(ServerInfo { port, token, dir })
}

fn hdr(name: &str, value: &str) -> Header {
    Header::from_bytes(name.as_bytes(), value.as_bytes()).unwrap()
}

fn cors() -> Header {
    hdr("Access-Control-Allow-Origin", "*")
}

fn send(rq: Request, data: Vec<u8>, content_type: &str) {
    let resp = Response::from_data(data)
        .with_header(hdr("Content-Type", content_type))
        .with_header(hdr("Cache-Control", "no-store"))
        .with_header(cors());
    let _ = rq.respond(resp);
}

fn status(rq: Request, code: u16) {
    let _ = rq.respond(Response::empty(StatusCode(code)).with_header(cors()));
}

fn handle(mut rq: Request, dir: &Path, token: &Mutex<String>) {
    let url = rq.url().to_string();
    let (path, query) = match url.split_once('?') {
        Some((a, b)) => (a.to_string(), b.to_string()),
        None => (url.clone(), String::new()),
    };
    let key = query
        .split('&')
        .find_map(|kv| kv.strip_prefix("k="))
        .unwrap_or("")
        .to_string();
    let authed = token.lock().map(|t| *t == key).unwrap_or(false);
    if authed {
        LAST_MS.store(now_ms(), Ordering::Relaxed);
    }

    if rq.method() == &tiny_http::Method::Options {
        let _ = rq.respond(
            Response::empty(StatusCode(204))
                .with_header(cors())
                .with_header(hdr("Access-Control-Allow-Methods", "GET, HEAD, POST, OPTIONS"))
                .with_header(hdr("Access-Control-Allow-Headers", "Range, Content-Type"))
                .with_header(hdr("Access-Control-Max-Age", "86400")),
        );
        return;
    }

    match path.as_str() {
        "/" | "/index.html" => send(rq, INDEX_HTML.as_bytes().to_vec(), "text/html; charset=utf-8"),
        "/m.css" => send(rq, M_CSS.as_bytes().to_vec(), "text/css; charset=utf-8"),
        "/offline-moments.js" => send(rq, include_bytes!("../../src/offline-moments.js").to_vec(), "application/javascript; charset=utf-8"),
        "/moments.js" => send(rq, include_bytes!("../../src/moments.js").to_vec(), "application/javascript; charset=utf-8"),
        "/api/checkins" if authed => {
            let result = if rq.method() == &tiny_http::Method::Post {
                let limit = crate::moments::LIMIT * 4 / 3 + 65536;
                let mut bytes = Vec::new();
                match rq.as_reader().take(limit + 1).read_to_end(&mut bytes) {
                    Ok(n) if n as u64 <= limit => serde_json::from_slice(&bytes)
                        .map_err(|e| e.to_string()).and_then(|v: Value| {
                            if let Some(profile) = v.get("profile") { crate::moments::save_profile(dir, profile) }
                            else { crate::moments::add(dir, v) }
                        }),
                    _ => Err("Слишком большой запрос".into()),
                }
            } else {
                crate::moments::profile(dir)
            };
            let body = result.unwrap_or_else(|error| json!({"error": error}));
            send(rq, body.to_string().into_bytes(), "application/json; charset=utf-8");
        }
        p if authed && crate::moments::media_path(p.trim_start_matches('/')) => {
            let file = dir.join(p.trim_start_matches('/'));
            serve_file(rq, &file.to_string_lossy());
        }
        "/m.js" => send(rq, M_JS.as_bytes().to_vec(), "application/javascript; charset=utf-8"),
        "/manifest.webmanifest" => send(rq, MANIFEST.as_bytes().to_vec(), "application/manifest+json"),
        "/icon-192.png" => send(rq, ICON_192.to_vec(), "image/png"),
        "/icon-512.png" => send(rq, ICON_512.to_vec(), "image/png"),
        "/api/library" => {
            if authed { library(rq, dir) } else { status(rq, 401) }
        }
        p if p.starts_with("/media/") => {
            if authed { track_file(rq, dir, &p[7..], false) } else { status(rq, 401) }
        }
        p if p.starts_with("/cover/") => {
            if authed { track_file(rq, dir, &p[7..], true) } else { status(rq, 401) }
        }
        _ => status(rq, 404),
    }
}

fn read_state(dir: &Path) -> Value {
    fs::read_to_string(dir.join("state.json"))
        .ok()
        .and_then(|s| serde_json::from_str(&s).ok())
        .unwrap_or(Value::Null)
}

fn library(rq: Request, dir: &Path) {
    let v = read_state(dir);
    let tracks: Vec<Value> = v["tracks"]
        .as_array()
        .map(|a| {
            a.iter()
                .map(|t| {
                    let p = t["path"].as_str().unwrap_or("");
                    let ext = Path::new(p)
                        .extension()
                        .and_then(|e| e.to_str())
                        .unwrap_or("mp3")
                        .to_lowercase();
                    let size = fs::metadata(p).map(|m| m.len()).unwrap_or(0);
                    let missing = !Path::new(p).exists();
                    json!({
                        "id": t["id"], "title": t["title"], "artist": t["artist"],
                        "tags": t["tags"], "cover": t["cover"].is_string(),
                        "ext": ext, "size": size, "missing": missing
                    })
                })
                .collect()
        })
        .unwrap_or_default();
    let playlists: Vec<Value> = v["playlists"]
        .as_array()
        .map(|a| {
            a.iter()
                .map(|p| json!({ "id": p["id"], "name": p["name"], "trackIds": p["trackIds"] }))
                .collect()
        })
        .unwrap_or_default();
    let body = json!({
        "profile": v["profile"],
        "tracks": tracks,
        "playlists": playlists
    })
    .to_string();
    send(rq, body.into_bytes(), "application/json; charset=utf-8");
}

fn track_file(rq: Request, dir: &Path, id: &str, cover: bool) {
    let v = read_state(dir);
    let field = if cover { "cover" } else { "path" };
    let path = v["tracks"]
        .as_array()
        .and_then(|a| a.iter().find(|t| t["id"].as_str() == Some(id)))
        .and_then(|t| t[field].as_str().map(String::from));
    match path {
        Some(p) => serve_file(rq, &p),
        None => status(rq, 404),
    }
}

fn mime(path: &str) -> &'static str {
    match path.rsplit('.').next().unwrap_or("").to_lowercase().as_str() {
        "mp4" => "video/mp4",
        "webm" => "video/webm",
        "mp3" => "audio/mpeg",
        "flac" => "audio/flac",
        "wav" => "audio/wav",
        "ogg" | "opus" => "audio/ogg",
        "m4a" => "audio/mp4",
        "aac" => "audio/aac",
        "jpg" | "jpeg" => "image/jpeg",
        "png" => "image/png",
        _ => "application/octet-stream",
    }
}

fn parse_range(r: &str, len: u64) -> Option<(u64, u64)> {
    if len == 0 {
        return None;
    }
    let spec = r.strip_prefix("bytes=")?;
    let (a, b) = spec.split_once('-')?;
    if a.is_empty() {
        let n: u64 = b.parse().ok()?;
        let n = n.min(len);
        return Some((len - n, len - 1));
    }
    let s: u64 = a.parse().ok()?;
    if s >= len {
        return None;
    }
    let e = if b.is_empty() { len - 1 } else { b.parse::<u64>().ok()?.min(len - 1) };
    if e < s { None } else { Some((s, e)) }
}

fn serve_file(rq: Request, path: &str) {
    let mut f = match fs::File::open(path) {
        Ok(f) => f,
        Err(_) => return status(rq, 404),
    };
    let len = f.metadata().map(|m| m.len()).unwrap_or(0);
    let range = rq
        .headers()
        .iter()
        .find(|h| h.field.equiv("Range"))
        .map(|h| h.value.as_str().to_string());
    let (start, end, partial) = match range.and_then(|r| parse_range(&r, len)) {
        Some((s, e)) => (s, e, true),
        None => (0, len.saturating_sub(1), false),
    };
    if f.seek(SeekFrom::Start(start)).is_err() {
        return status(rq, 500);
    }
    let size = if len == 0 { 0 } else { end - start + 1 };
    let mut headers = vec![
        hdr("Content-Type", mime(path)),
        hdr("Accept-Ranges", "bytes"),
        hdr("Cache-Control", "no-store"),
        hdr("Access-Control-Expose-Headers", "Content-Range, Content-Length, Accept-Ranges"),
        cors(),
    ];
    if partial {
        headers.push(hdr("Content-Range", &format!("bytes {}-{}/{}", start, end, len)));
    }
    let resp = Response::new(
        StatusCode(if partial { 206 } else { 200 }),
        headers,
        f.take(size),
        Some(size as usize),
        None,
    );
    ACTIVE.fetch_add(1, Ordering::Relaxed);
    let _ = rq.respond(resp);
    ACTIVE.fetch_sub(1, Ordering::Relaxed);
    LAST_MS.store(now_ms(), Ordering::Relaxed);
}

/// Ссылка для телефона + QR-код (SVG). `ip` — выбранный адрес ПК (иначе лучший из найденных).
#[tauri::command]
pub fn get_phone_link(info: tauri::State<'_, ServerInfo>, ip: Option<String>) -> Result<Value, String> {
    let addrs = lan_addrs();
    let ip = ip
        .filter(|x| addrs.iter().any(|a| &a.0 == x))
        .or_else(|| addrs.first().map(|a| a.0.clone()))
        .unwrap_or_else(|| "127.0.0.1".to_string());
    let token = info.token.lock().map_err(|e| e.to_string())?.clone();
    let url = format!("http://{}:{}/?k={}", ip, info.port, token);
    // для подключения по USB-кабелю (adb reverse) и эмулятора
    let usb_url = format!("http://127.0.0.1:{}/?k={}", info.port, token);
    let code = qrcode::QrCode::new(url.as_bytes()).map_err(|e| e.to_string())?;
    let svg = code
        .render::<qrcode::render::svg::Color>()
        .min_dimensions(220, 220)
        .dark_color(qrcode::render::svg::Color("#000000"))
        .light_color(qrcode::render::svg::Color("#ffffff"))
        .build();
    let list: Vec<Value> = addrs.iter().map(|(i, n)| json!({ "ip": i, "name": n })).collect();
    Ok(json!({ "url": url, "usbUrl": usb_url, "svg": svg, "ip": ip, "port": info.port, "addrs": list }))
}

/// Статус телефона: идёт ли сейчас передача и как давно он обращался к ПК.
#[tauri::command]
pub fn phone_status() -> Value {
    let last = LAST_MS.load(Ordering::Relaxed);
    let ago = if last == 0 { Value::Null } else { json!(now_ms().saturating_sub(last)) };
    json!({ "active": ACTIVE.load(Ordering::Relaxed), "lastAgoMs": ago })
}

/// Сбросить доступ: старая ссылка/QR перестают работать.
#[tauri::command]
pub fn reset_phone_token(info: tauri::State<'_, ServerInfo>) -> Result<(), String> {
    let t = rand_token();
    fs::write(info.dir.join("server.json"), json!({ "token": t, "port": info.port }).to_string()).map_err(|e| e.to_string())?;
    *info.token.lock().map_err(|e| e.to_string())? = t;
    Ok(())
}

// ---------------- ADB: телефон находится сам, без QR и IP ----------------

const APP_ID: &str = "com.zalupamusic.app";

fn adb_cmd(adb: &Path) -> std::process::Command {
    let mut c = std::process::Command::new(adb);
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        c.creation_flags(0x0800_0000); // без мигающего окна консоли
    }
    c
}

fn find_adb() -> Option<PathBuf> {
    let exe = if cfg!(windows) { "adb.exe" } else { "adb" };
    let mut cands: Vec<PathBuf> = vec![];
    for var in ["ANDROID_HOME", "ANDROID_SDK_ROOT"] {
        if let Ok(v) = std::env::var(var) {
            cands.push(PathBuf::from(v).join("platform-tools").join(exe));
        }
    }
    if let Ok(v) = std::env::var("LOCALAPPDATA") {
        cands.push(PathBuf::from(v).join("Android").join("Sdk").join("platform-tools").join(exe));
    }
    if let Ok(v) = std::env::var("HOME") {
        cands.push(PathBuf::from(&v).join("Android").join("Sdk").join("platform-tools").join(exe));
        cands.push(PathBuf::from(&v).join("Library/Android/sdk/platform-tools").join(exe));
    }
    if let Ok(p) = std::env::current_exe() {
        if let Some(d) = p.parent() {
            cands.push(d.join(exe));
            cands.push(d.join("platform-tools").join(exe));
        }
    }
    if let Some(found) = cands.into_iter().find(|p| p.exists()) {
        return Some(found);
    }
    // adb из PATH
    let p = PathBuf::from(exe);
    if adb_cmd(&p).arg("version").output().map(|o| o.status.success()).unwrap_or(false) {
        return Some(p);
    }
    None
}

fn run_adb(adb: &Path, serial: &str, args: &[&str]) -> Result<String, String> {
    let mut c = adb_cmd(adb);
    if !serial.is_empty() {
        c.args(["-s", serial]);
    }
    let out = c.args(args).output().map_err(|e| e.to_string())?;
    let text = format!("{}{}", String::from_utf8_lossy(&out.stdout), String::from_utf8_lossy(&out.stderr));
    if out.status.success() { Ok(text) } else { Err(text.trim().to_string()) }
}

/// Какие телефоны сейчас подключены по USB (и есть ли adb вообще).
#[tauri::command]
pub async fn adb_status() -> Result<Value, String> {
    let adb = match find_adb() {
        Some(a) => a,
        None => return Ok(json!({ "adb": false, "devices": [] })),
    };
    let out = adb_cmd(&adb).arg("devices").arg("-l").output().map_err(|e| e.to_string())?;
    let text = String::from_utf8_lossy(&out.stdout).to_string();
    let mut devices: Vec<Value> = vec![];
    for line in text.lines().skip(1) {
        let mut it = line.split_whitespace();
        let (Some(serial), Some(state)) = (it.next(), it.next()) else { continue };
        let model = line
            .split_whitespace()
            .find_map(|p| p.strip_prefix("model:"))
            .unwrap_or("Android")
            .replace('_', " ");
        let installed = state == "device"
            && run_adb(&adb, serial, &["shell", "pm", "list", "packages", APP_ID])
                .map(|s| s.contains(APP_ID))
                .unwrap_or(false);
        devices.push(json!({ "serial": serial, "state": state, "model": model, "installed": installed }));
    }
    Ok(json!({ "adb": true, "devices": devices }))
}

/// Подключает телефон к ПК-серверу через USB: пробрасывает порт, передаёт ключ и открывает приложение.
#[tauri::command]
pub async fn adb_link(info: tauri::State<'_, ServerInfo>, serial: String) -> Result<Value, String> {
    let adb = find_adb().ok_or("adb не найден. Установи Android Studio (Platform-Tools) или положи adb.exe рядом с приложением")?;
    let port = info.port;
    let token = info.token.lock().map_err(|e| e.to_string())?.clone();

    run_adb(&adb, &serial, &["reverse", &format!("tcp:{}", port), &format!("tcp:{}", port)])
        .map_err(|e| format!("Не удалось пробросить порт: {}", e))?;

    let remote_dir = format!("/sdcard/Android/data/{}/files", APP_ID);
    let _ = run_adb(&adb, &serial, &["shell", "mkdir", "-p", &remote_dir]);
    let local = info.dir.join("zm_connect.json");
    let cfg = json!({ "server": format!("http://127.0.0.1:{}", port), "k": token, "t": now_ms(), "autoSync": true });
    fs::write(&local, cfg.to_string()).map_err(|e| e.to_string())?;
    run_adb(&adb, &serial, &["push", &local.to_string_lossy(), &format!("{}/zm_connect.json", remote_dir)])
        .map_err(|e| format!("Не удалось передать ключ: {}", e))?;
    let _ = fs::remove_file(&local);

    // открыть приложение на телефоне
    let _ = run_adb(&adb, &serial, &["shell", "monkey", "-p", APP_ID, "-c", "android.intent.category.LAUNCHER", "1"]);
    Ok(json!({ "ok": true }))
}

/// Ставит APK на телефон, если он лежит рядом с приложением или в папке dist проекта.
#[tauri::command]
pub async fn adb_install(serial: String) -> Result<Value, String> {
    let adb = find_adb().ok_or("adb не найден")?;
    let mut cands: Vec<PathBuf> = vec![];
    if let Ok(p) = std::env::current_exe() {
        let mut d = p.parent().map(|x| x.to_path_buf());
        for _ in 0..6 {
            if let Some(dir) = d {
                cands.push(dir.join("ZalupaMusic.apk"));
                cands.push(dir.join("dist").join("ZalupaMusic.apk"));
                d = dir.parent().map(|x| x.to_path_buf());
            } else { break; }
        }
    }
    let apk = cands.into_iter().find(|p| p.exists()).ok_or("ZalupaMusic.apk не найден. Положи его рядом с ZalupaMusic.exe")?;
    run_adb(&adb, &serial, &["install", "-r", &apk.to_string_lossy()])?;
    Ok(json!({ "ok": true }))
}
