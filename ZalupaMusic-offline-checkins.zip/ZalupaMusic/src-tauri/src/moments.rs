use base64::{engine::general_purpose::STANDARD, Engine};
use serde_json::{json, Value};
use std::{fs, io::Write, path::Path, sync::Mutex};

pub static LOCK: Mutex<()> = Mutex::new(());
pub type Result<T> = std::result::Result<T, String>;
pub const LIMIT: u64 = 32 * 1024 * 1024;

pub fn read(dir: &Path) -> Result<Value> {
    match fs::read(dir.join("state.json")) {
        Ok(bytes) => serde_json::from_slice(&bytes).map_err(|e| e.to_string()),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(json!({})),
        Err(e) => Err(e.to_string()),
    }
}

pub fn write(path: &Path, data: &[u8]) -> Result<()> {
    let parent = path.parent().ok_or("Нет папки назначения")?;
    fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    let mut file = tempfile::NamedTempFile::new_in(parent).map_err(|e| e.to_string())?;
    file.write_all(data).map_err(|e| e.to_string())?;
    file.as_file().sync_all().map_err(|e| e.to_string())?;
    file.persist(path).map_err(|e| e.to_string())?;
    Ok(())
}

pub fn media_path(path: &str) -> bool {
    let Some(name) = path.strip_prefix("checkins/") else { return false };
    let Some((id, ext)) = name.split_once('.') else { return false };
    !id.is_empty() && id.len() <= 80 && id.bytes().all(|c| c.is_ascii_alphanumeric() || c == b'-')
        && matches!(ext, "jpg" | "mp4" | "webm")
}

pub fn profile(dir: &Path) -> Result<Value> {
    let _guard = LOCK.lock().map_err(|e| e.to_string())?;
    let state = read(dir)?;
    let tracks: Vec<_> = state["tracks"].as_array().into_iter().flatten()
        .map(|t| json!({"id": t["id"], "title": t["title"], "artist": t["artist"]})).collect();
    Ok(json!({
        "profile": state["profile"], "tracks": tracks, "stats": state["stats"],
        "checkins": state["checkins"], "playlistCount": state["playlists"].as_array().map_or(0, Vec::len)
    }))
}

pub fn add(dir: &Path, request: Value) -> Result<Value> {
    let _guard = LOCK.lock().map_err(|e| e.to_string())?;
    let mut state = read(dir)?;
    let mut entry = request["entry"].clone();
    let id = entry["id"].as_str().ok_or("Нет ID")?;
    let ext = request["ext"].as_str().unwrap_or("");
    let path = format!("checkins/{id}.{ext}");
    if !media_path(&path) || entry["title"].as_str().map_or(true, |s| s.trim().is_empty()) {
        return Err("Некорректный чек-ин".into());
    }
    if !entry["ts"].is_u64() || !entry["text"].is_string()
        || !entry["tags"].as_array().is_some_and(|tags| tags.iter().all(Value::is_string))
        || !entry["trackId"].is_string() {
        return Err("Некорректные поля чек-ина".into());
    }
    let track = state["tracks"].as_array().into_iter().flatten()
        .find(|t| t["id"].is_string() && t["id"] == entry["trackId"]).unwrap_or(&entry["track"]);
    let title = track["title"].as_str().filter(|s| !s.trim().is_empty()).ok_or("Трек не найден")?;
    let snapshot = json!({"title": title, "artist": track["artist"].as_str().unwrap_or("")});
    entry["track"] = snapshot;
    entry["media"] = json!(path);
    if !state["checkins"].is_array() { state["checkins"] = json!([]); }
    let list = state["checkins"].as_array_mut().unwrap();
    if let Some(existing) = list.iter().find(|old| old["id"] == entry["id"]) {
        return Ok(existing.clone());
    }
    let bytes = STANDARD.decode(request["data"].as_str().unwrap_or("")).map_err(|e| e.to_string())?;
    if bytes.is_empty() || bytes.len() as u64 > LIMIT { return Err("Некорректный размер медиа".into()); }
    write(&dir.join(path), &bytes)?;
    list.push(entry.clone());
    if let Err(error) = write(&dir.join("state.json"), state.to_string().as_bytes()) {
        let _ = fs::remove_file(dir.join(entry["media"].as_str().unwrap()));
        return Err(error);
    }
    Ok(entry)
}

#[tauri::command]
pub fn checkin_profile(app: tauri::AppHandle) -> Result<Value> {
    profile(&super::data_dir(&app)?)
}

pub fn save_profile(dir: &Path, profile: &Value) -> Result<Value> {
    let name = profile["name"].as_str().map(str::trim)
        .filter(|name| !name.is_empty() && name.chars().count() <= 24).ok_or("Некорректное имя")?;
    let avatar = profile["avatar"].as_str()
        .filter(|value| value.starts_with("data:image/") && value.len() <= 2 * 1024 * 1024);
    let _guard = LOCK.lock().map_err(|e| e.to_string())?;
    let mut state = read(dir)?;
    state["profile"] = json!({"name": name, "avatar": avatar});
    write(&dir.join("state.json"), state.to_string().as_bytes())?;
    Ok(state["profile"].clone())
}

#[tauri::command]
pub fn checkin_media(app: tauri::AppHandle, path: String) -> Result<String> {
    if !media_path(&path) { return Err("Некорректный путь".into()); }
    Ok(super::data_dir(&app)?.join(path).to_string_lossy().into_owned())
}
