$f = Join-Path $env:APPDATA 'com.zalupamusic.app\server.json'
if (-not (Test-Path $f)) { exit 1 }
$j = Get-Content $f -Raw | ConvertFrom-Json
$p = 7878
if ($j.port) { $p = $j.port }
$u = "http://localhost:$p/?k=$($j.token)"
Set-Clipboard -Value $u
Write-Output "$p $u"
