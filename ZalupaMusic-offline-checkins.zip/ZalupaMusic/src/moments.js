(() => {
  const el = (tag, text) => {
    const node = document.createElement(tag);
    if (text != null) node.textContent = text;
    return node;
  };
  const trackText = (track) => [track?.artist, track?.title].filter(Boolean).join(" — ");
  const read = (blob) => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(",")[1]);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });

  async function photo(source, title, track, maxSide = 1800) {
    const bitmap = await createImageBitmap(source);
    try {
      const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
      const canvas = el("canvas");
      canvas.width = Math.max(title ? 320 : 1, Math.round(bitmap.width * scale));
      canvas.height = Math.max(title ? 160 : 1, Math.round(bitmap.height * scale));
      const ctx = canvas.getContext("2d");
      ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      if (title) {
        const pad = Math.max(12, Math.round(canvas.width * .04));
        const font = Math.min(Math.round(canvas.height / 6), Math.max(16, Math.round(canvas.width * .05)));
        const band = 2 * font + 2 * pad;
        ctx.fillStyle = "rgba(0,0,0,.72)";
        ctx.fillRect(0, canvas.height - band, canvas.width, band);
        ctx.fillStyle = "white";
        ctx.font = "bold " + font + "px system-ui";
        ctx.fillText(title, pad, canvas.height - pad - font, canvas.width - 2 * pad);
        ctx.font = Math.round(font * .72) + "px system-ui";
        ctx.fillText(track || "Трек", pad, canvas.height - pad, canvas.width - 2 * pad);
      }
      return await new Promise((resolve, reject) => {
        canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error("Не удалось обработать фото")), "image/jpeg", .85);
      });
    } finally {
      bitmap.close();
    }
  }

  async function videoExtension(file) {
    const extension = file.type === "video/webm" ? "webm" : file.type === "video/mp4" ? "mp4" : "";
    if (!extension) throw new Error("Выберите видео MP4 или WebM");
    const video = el("video");
    const url = URL.createObjectURL(file);
    try {
      video.preload = "metadata";
      await new Promise((resolve, reject) => {
        video.onloadedmetadata = resolve;
        video.onerror = () => reject(new Error("Не удалось открыть видео"));
        video.src = url;
      });
      if (!Number.isFinite(video.duration) || video.duration <= 0 || video.duration > 15) {
        throw new Error("Видео должно быть не длиннее 15 секунд");
      }
      return extension;
    } finally {
      video.removeAttribute("src");
      video.load();
      URL.revokeObjectURL(url);
    }
  }

  async function download(url, entry, video, saveFile) {
    const response = await fetch(url);
    if (!response.ok) throw new Error("Медиа не найдено");
    const original = await response.blob();
    const result = video ? original : await photo(original, entry.title, trackText(entry.track));
    const name = "checkin-" + entry.id + "." + entry.media.split(".").pop();
    if (saveFile) return saveFile(name, await read(result));
    const object = URL.createObjectURL(result);
    const link = el("a");
    link.href = object;
    link.download = name;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(object), 30000);
  }

  const renders = new WeakMap();
  async function render(root, api, mobile = false) {
    const token = {};
    renders.set(root, token);
    for (const media of root.querySelectorAll("img[src^='blob:'],video[src^='blob:']")) URL.revokeObjectURL(media.src);
    root.replaceChildren(el("p", "Загрузка…"));
    try {
      const data = await api.profile();
      const tracks = data.tracks || [];
      const entries = data.checkins || [];
      const fragment = document.createDocumentFragment();
      if (mobile) {
        const profile = el("div");
        profile.className = "moment-profile";
        if (typeof data.profile?.avatar === "string" && data.profile.avatar.startsWith("data:image/")) {
          const avatar = el("img");
          avatar.src = data.profile.avatar;
          avatar.alt = "";
          profile.append(avatar);
        } else {
          const initials = el("span", (data.profile?.name || "?").trim().charAt(0).toUpperCase());
          initials.className = "moment-avatar";
          initials.setAttribute("aria-hidden", "true");
          profile.append(initials);
        }
        profile.append(el("h2", data.profile?.name || "Профиль"));
        const plays = Object.values(data.stats?.plays || {}).reduce((a, b) => a + Number(b || 0), 0);
        profile.append(el("p", "Треки: " + tracks.length + " · Плейлисты: " + data.playlistCount +
          " · Прослушивания: " + plays + " · Чек-ины: " + entries.length));
        if (api.saveProfile) {
          const editProfile = el("form");
          editProfile.hidden = true;
          const name = el("input");
          name.className = "input";
          name.placeholder = "Имя профиля";
          name.setAttribute("aria-label", "Имя профиля");
          name.required = true;
          name.maxLength = 24;
          name.value = data.profile?.name || "";
          const avatar = el("input");
          avatar.type = "file";
          avatar.accept = "image/*";
          avatar.setAttribute("aria-label", "Фото профиля");
          const submit = el("button", "Сохранить");
          submit.className = "btn";
          const feedback = el("p");
          feedback.setAttribute("role", "status");
          editProfile.append(name, avatar, submit, feedback);
          const edit = el("button", "Изменить профиль");
          edit.className = "btn";
          edit.onclick = () => { editProfile.hidden = !editProfile.hidden; };
          editProfile.onsubmit = async event => {
            event.preventDefault();
            if (!name.value.trim() || submit.disabled) return;
            submit.disabled = true;
            try {
              const file = avatar.files[0];
              const picture = file ? "data:image/jpeg;base64," + await read(await photo(file, null, null, 384)) : data.profile?.avatar || null;
              await api.saveProfile({ name: name.value.trim(), avatar: picture });
              await render(root, api, mobile);
            } catch (error) { feedback.textContent = String(error.message || error); }
            finally { submit.disabled = false; }
          };
          profile.append(edit, editProfile);
        }
        if (data.pendingCount) profile.append(el("p", "Ждут отправки на ПК: " + data.pendingCount));
        fragment.append(profile);
      } else {
        fragment.append(el("h3", "Чек-ины"));
      }
      const status = el("p");
      status.setAttribute("role", "status");
      const add = el("button", "+ чек-ин");
      add.className = "btn primary";
      const form = el("form");
      form.hidden = true;
      const input = (tag, label) => {
        const wrapper = el("label", label);
        const control = el(tag);
        control.className = "input";
        wrapper.append(control);
        form.append(wrapper);
        return control;
      };
      const title = input("input", "Название момента");
      title.required = true;
      title.maxLength = 100;
      const body = input("textarea", "Описание");
      body.maxLength = 2000;
      const tags = input("input", "Теги через запятую");
      tags.maxLength = 300;
      const track = input("select", "Трек");
      for (const item of tracks) {
        const option = el("option", trackText(item) || "Без названия");
        option.value = item.id;
        track.append(option);
      }
      const file = input("input", "Фото или видео до 15 секунд");
      file.type = "file";
      file.accept = "image/*,video/mp4,video/webm";
      file.required = true;
      const save = el("button", "Сохранить чек-ин");
      save.className = "btn primary";
      form.append(save);
      add.disabled = !tracks.length;
      add.onclick = () => {
        form.hidden = !form.hidden;
        if (!form.hidden) title.focus();
      };
      if (!tracks.length) status.textContent = "Добавьте трек на телефоне или подключитесь к библиотеке ПК.";
      let draftId;
      form.oninput = () => { if (!save.disabled) draftId = undefined; };
      form.onsubmit = async (event) => {
        event.preventDefault();
        if (save.disabled || !title.value.trim()) return;
        save.disabled = true;
        status.textContent = "Сохраняем…";
        try {
          const source = file.files[0];
          if (source.size > 32 * 1024 * 1024) throw new Error("Файл должен быть не больше 32 МБ");
          const isVideo = source.type.startsWith("video/");
          const ext = isVideo ? await videoExtension(source) : "jpg";
          const data = await read(isVideo ? source : await photo(source));
          draftId ||= Date.now().toString(36) + "-" + Array.from(crypto.getRandomValues(new Uint32Array(3)), n => n.toString(36)).join("-");
          const selected = tracks.find(item => item.id === track.value);
          await api.add({ ext, data, entry: {
            id: draftId, ts: Date.now(), title: title.value.trim(), text: body.value.trim(),
            tags: [...new Set(tags.value.split(",").map(t => t.trim()).filter(Boolean))], trackId: track.value,
            track: selected && { title: selected.title, artist: selected.artist }
          } });
          await render(root, api, mobile);
        } catch (error) {
          status.textContent = String(error.message || error);
        } finally {
          save.disabled = false;
        }
      };
      if (api.add) fragment.append(add, form, status);
      if (!entries.length) fragment.append(el("p", "Пока нет чек-инов."));
      for (const entry of [...entries].sort((a, b) => b.ts - a.ts)) {
        const card = el("article");
        card.className = "glass card moment-card";
        const video = /\.(mp4|webm)$/.test(entry.media || "");
        const media = el(video ? "video" : "img");
        if (video) { media.controls = true; media.preload = "metadata"; }
        else { media.loading = "lazy"; media.alt = entry.title || ""; }
        const mediaStatus = el("p");
        mediaStatus.setAttribute("role", "status");
        media.onerror = () => { media.hidden = true; mediaStatus.textContent = "Медиа недоступно"; };
        const exportButton = el("button", video ? "Скачать видео" : "Экспорт фото");
        exportButton.className = "btn";
        if (entry.media) {
          try { media.src = await api.media(entry.media); }
          catch { media.onerror(); exportButton.disabled = true; }
        } else {
          media.onerror();
          exportButton.disabled = true;
        }
        exportButton.onclick = async () => {
          exportButton.disabled = true;
          try { await download(media.src, entry, video, api.saveFile); }
          catch (error) { mediaStatus.textContent = String(error.message || error); }
          finally { exportButton.disabled = false; }
        };
        card.append(el("h3", entry.title), el("p", trackText(entry.track || tracks.find(t => t.id === entry.trackId))),
          el("small", new Date(entry.ts).toLocaleString("ru-RU")), media);
        if (entry.pending) card.append(el("small", "Ожидает синхронизации"));
        if (entry.text) card.append(el("p", entry.text));
        if (entry.tags?.length) card.append(el("p", entry.tags.map(t => "#" + t).join(" ")));
        card.append(exportButton, mediaStatus);
        fragment.append(card);
      }
      if (renders.get(root) === token) root.replaceChildren(fragment);
      else for (const media of fragment.querySelectorAll("img[src^='blob:'],video[src^='blob:']")) URL.revokeObjectURL(media.src);
    } catch (error) {
      if (renders.get(root) !== token) return;
      root.replaceChildren(el("p", String(error.message || error)));
      const retry = el("button", "Повторить");
      retry.className = "btn";
      retry.onclick = () => render(root, api, mobile);
      root.append(retry);
    }
  }

  function timeoutSignal(ms) {
    const controller = new AbortController();
    setTimeout(() => controller.abort(), ms);
    return controller.signal;
  }

  function phone(url) {
    const request = async (options) => {
      const response = await fetch(url("/api/checkins"), { signal: timeoutSignal(30000), ...options });
      if (!response.ok) throw new Error("Проверьте подключение к ПК и ключ доступа");
      const data = await response.json();
      if (data.error) throw new Error(data.error);
      return data;
    };
    return {
      profile: () => request({ cache: "no-store" }),
      add: (data) => request({ method: "POST", body: JSON.stringify(data) }),
      saveProfile: (profile) => request({ method: "POST", body: JSON.stringify({ profile }) }),
      media: (path) => url("/" + path)
    };
  }

  window.ZmMoments = { render, phone };
})();
