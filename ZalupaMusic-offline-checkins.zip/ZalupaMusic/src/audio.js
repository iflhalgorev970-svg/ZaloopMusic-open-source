// Аудио-движок: два "дека" + кроссфейд (бесшовный переход) + 10-полосный эквалайзер.
const EQ_FREQS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];

class Engine {
  constructor() {
    this.ctx = null;
    this.decks = [];
    this.active = 0;
    this.advanced = false;
    this.xfade = 4;
    this.volume = 0.8;
    this.gains = new Array(10).fill(0);
    // колбэки, задаются приложением
    this.onAdvance = () => false;
    this.onTime = () => {};
    this.onState = () => {};
    this.onStop = () => {};
  }

  init() {
    if (this.ctx) return;
    this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    this.master = this.ctx.createGain();
    this.master.gain.value = this.volume;

    // цепочка эквалайзера
    this.eqIn = this.ctx.createGain();
    let prev = this.eqIn;
    this.filters = EQ_FREQS.map((f, i) => {
      const bq = this.ctx.createBiquadFilter();
      bq.type = i === 0 ? "lowshelf" : i === EQ_FREQS.length - 1 ? "highshelf" : "peaking";
      bq.frequency.value = f;
      bq.Q.value = 1.1;
      bq.gain.value = this.gains[i];
      prev.connect(bq);
      prev = bq;
      return bq;
    });
    prev.connect(this.master);
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 128;
    this.analyser.smoothingTimeConstant = 0.82;
    this.master.connect(this.analyser);
    this.analyser.connect(this.ctx.destination);

    this.decks = [this._mkDeck(), this._mkDeck()];
    setInterval(() => this._tick(), 100);
  }

  _mkDeck() {
    const el = new Audio();
    el.crossOrigin = "anonymous";
    el.preload = "auto";
    const src = this.ctx.createMediaElementSource(el);
    const g = this.ctx.createGain();
    src.connect(g);
    g.connect(this.eqIn);
    const deck = { el, g };
    el.addEventListener("play", () => this._emitState());
    el.addEventListener("pause", () => this._emitState());
    el.addEventListener("ended", () => {
      if (deck !== this.decks[this.active]) return;
      if (!this.advanced) {
        this.advanced = true;
        if (!this.onAdvance(0.15)) this.onStop();
      }
    });
    return deck;
  }

  _emitState() {
    const d = this.decks[this.active];
    this.onState(!!d && !d.el.paused);
  }

  _ramp(gainNode, to, seconds) {
    const t = this.ctx.currentTime;
    gainNode.gain.cancelScheduledValues(t);
    gainNode.gain.setValueAtTime(gainNode.gain.value, t);
    gainNode.gain.linearRampToValueAtTime(to, t + Math.max(seconds, 0.01));
  }

  /** Запустить трек на свободном деке с плавным переходом от текущего. */
  async play(url, fade = 0.3) {
    this.init();
    if (this.ctx.state === "suspended") await this.ctx.resume();
    const old = this.decks[this.active];
    const nxt = this.decks[1 - this.active];

    nxt.el.src = url;
    nxt.g.gain.cancelScheduledValues(this.ctx.currentTime);
    nxt.g.gain.value = 0;
    try {
      await nxt.el.play();
    } catch (e) {
      console.error("play failed", e);
      return;
    }
    this._ramp(nxt.g, 1, fade);

    if (old.el.src && !old.el.paused) {
      this._ramp(old.g, 0, fade);
      setTimeout(() => {
        if (old !== this.decks[this.active]) old.el.pause();
      }, fade * 1000 + 60);
    }
    this.active = 1 - this.active;
    this.advanced = false;
    this._emitState();
  }

  toggle() {
    if (!this.ctx) return;
    const d = this.decks[this.active];
    if (!d.el.src) return;
    if (d.el.paused) {
      this.ctx.resume();
      d.el.play();
    } else {
      d.el.pause();
    }
  }

  stop() {
    this.decks.forEach((d) => d.el.pause());
  }

  seek(frac) {
    if (!this.ctx) return;
    const el = this.decks[this.active].el;
    if (isFinite(el.duration)) el.currentTime = frac * el.duration;
  }

  setVolume(v) {
    this.volume = v;
    if (this.master) this.master.gain.value = v;
  }

  setBand(i, db) {
    this.gains[i] = db;
    if (this.filters) this.filters[i].gain.value = db;
  }

  setGains(arr) {
    arr.forEach((g, i) => this.setBand(i, g));
  }

  _tick() {
    if (!this.ctx) return;
    const el = this.decks[this.active].el;
    if (!el.src) return;
    const dur = el.duration;
    this.onTime(el.currentTime, isFinite(dur) ? dur : 0);
    if (el.paused || this.advanced || !isFinite(dur) || dur <= 0) return;
    const fade = Math.max(Math.min(this.xfade, dur / 3), 0.15);
    if (dur - el.currentTime <= fade) {
      this.advanced = true;
      if (!this.onAdvance(fade)) this.onStop();
    }
  }
}

window.engine = new Engine();
