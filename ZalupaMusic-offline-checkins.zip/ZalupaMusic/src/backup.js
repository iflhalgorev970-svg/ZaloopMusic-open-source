const desktopMoments = {
  profile: async () => {
    await flushState();
    return TAURI.core.invoke("checkin_profile");
  },
  media: async (path) => TAURI.core.convertFileSrc(await TAURI.core.invoke("checkin_media", { path }))
};

const backupLayers = {
  profile: "Профиль", library: "Библиотека", checkins: "Чек-ины",
  media: "Медиа", settings: "Настройки", audio: "Аудио"
};
let desktopSettingsPanel = "visual";
let backupPoll;
function showSettingsPanel(root, active) {
  desktopSettingsPanel = active;
  for (const button of root.querySelectorAll("[data-settings]")) {
    button.setAttribute("aria-pressed", button.dataset.settings === active);
    button.onclick = () => showSettingsPanel(root, button.dataset.settings);
  }
  for (const panel of root.querySelectorAll("[data-settings-panel]")) {
    panel.hidden = panel.dataset.settingsPanel !== active;
  }
}
let backupBusy = false;

function showBackups() {
  const list = $("backupLayers");
  const status = $("backupStatus");
  if (!TAURI) {
    $("backupCreate").disabled = $("backupRestore").disabled = true;
    status.textContent = "Бэкапы доступны в приложении для ПК.";
    return;
  }
  const sizes = {};
  list.replaceChildren();
  for (const [key, name] of Object.entries(backupLayers)) {
    const label = document.createElement("label");
    const checkbox = document.createElement("input");
    const caption = document.createElement("span");
    const size = document.createElement("small");
    checkbox.type = "checkbox";
    checkbox.value = key;
    checkbox.checked = state.settings.backup.layers.includes(key);
    checkbox.onchange = () => {
      state.settings.backup.layers = [...list.querySelectorAll(":checked")].map(item => item.value);
      saveState();
      $("backupCreate").disabled = !state.settings.backup.layers.length;
    };
    caption.textContent = name;
    size.textContent = "…";
    sizes[key] = size;
    label.append(checkbox, caption, size);
    list.append(label);
  }
  const refresh = async () => {
    try {
      const data = await TAURI.core.invoke("backup_sizes");
      for (const [key, value] of Object.entries(data)) {
        sizes[key].textContent = value < 1024 ? value + " Б" :
          value < 1048576 ? (value / 1024).toFixed(1) + " КБ" : (value / 1048576).toFixed(1) + " МБ";
      }
    } catch (error) {
      if (!backupBusy) status.textContent = String(error.message || error);
    }
  };
  refresh();
  clearInterval(backupPoll);
  backupPoll = setInterval(refresh, 2000);
  const act = (fn) => async () => {
    if (backupBusy) return;
    backupBusy = true;
    $("backupCreate").disabled = $("backupRestore").disabled = true;
    status.textContent = "";
    try {
      await fn();
    } catch (error) {
      status.textContent = String(error.message || error);
    } finally {
      backupBusy = false;
      $("backupCreate").disabled = !state.settings.backup.layers.length;
      $("backupRestore").disabled = false;
      refresh();
    }
  };
  $("backupCreate").disabled = !state.settings.backup.layers.length;
  $("backupCreate").onclick = act(async () => {
    const selected = [...state.settings.backup.layers];
    const audio = selected.includes("audio");
    const path = await TAURI.dialog.save({
      title: audio ? "Имя новой папки для бэкапа" : "Сохранить капсулу",
      defaultPath: audio ? "ZalupaMusic-backup" : "ZalupaMusic.zmb",
      ...(audio ? {} : { filters: [{ name: "Капсула ZalupaMusic", extensions: ["zmb"] }] })
    });
    if (!path) return;
    const destination = path;
    status.textContent = "Создаём бэкап…";
    await flushState();
    await TAURI.core.invoke("create_backup", { path: destination, selected });
    status.textContent = "Бэкап создан.";
  });
  $("backupRestore").onclick = act(async () => {
    const path = await TAURI.dialog.open({
      title: "Выберите капсулу или backup.json из папки с аудио",
      filters: [{ name: "Бэкап ZalupaMusic", extensions: ["zmb", "json"] }]
    });
    if (!path) return;
    status.textContent = "Восстанавливаем…";
    await flushState();
    suspendSaves = true;
    try {
      await TAURI.core.invoke("restore_backup", { path });
      sessionStorage.setItem("zm-restored", "1");
      location.reload();
    } catch (error) {
      suspendSaves = false;
      throw error;
    }
  });
  if (sessionStorage.getItem("zm-restored")) {
    sessionStorage.removeItem("zm-restored");
    status.textContent = "Бэкап восстановлен.";
  }
}
