// Состояние приложения, сохранение и общие утилиты.
const TAURI = window.__TAURI__ || null;
const $ = (id) => document.getElementById(id);

const TAG_GROUPS = {
  "Настроение": ["Грустный", "Весёлый", "Спокойный", "Энергичный", "Романтичный", "Мрачный", "Мечтательный"],
  "Занятие": ["Фокус", "Спорт", "Ночь", "Дорога", "Вечеринка", "Сон"],
  "Жанр": ["Рок", "Поп", "Хип-хоп", "Электроника", "Джаз", "Классика", "Лоу-фай"],
};
const ALL_TAGS = Object.values(TAG_GROUPS).flat();
const MOOD_TAGS = [...TAG_GROUPS["Настроение"], ...TAG_GROUPS["Занятие"]];

const EQ_PRESETS = {
  "Плоский":      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  "Бас":          [6, 5, 4, 2, 0, 0, 0, 0, 0, 0],
  "Вокал":        [-2, -1, 0, 2, 4, 4, 3, 1, 0, -1],
  "Высокие":      [0, 0, 0, 0, 0, 1, 3, 4, 5, 6],
  "Рок":          [4, 3, 1, -1, -2, 0, 2, 3, 4, 4],
  "Поп":          [-1, 1, 3, 4, 3, 0, -1, -1, 1, 2],
  "Электроника":  [5, 4, 1, 0, -2, 1, 0, 2, 4, 5],
};

const state = {
  profile: null,          // { name, avatar }
  checkins: [],
  settings: { backup: { layers: ["profile", "library", "checkins", "media", "settings"] } },
  theme: null,            // "dark" | "light"
  tracks: [],             // { id, path, title, artist, tags[] }
  playlists: [],          // { id, name, trackIds[] }
  eq: { preset: "Плоский", gains: new Array(10).fill(0) },
  xfade: 4,
  volume: 80,
  perf: "auto",           // "auto" | "full" | "lite"
  stats: { plays: {}, secs: {} },
};

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const trackById = (id) => state.tracks.find((t) => t.id === id);
const urlFor = (t) => (TAURI && !t.path.startsWith("blob:") ? TAURI.core.convertFileSrc(t.path) : t.path);

// URL обложки трека (картинка из тегов файла) или null
const coverUrl = (t) => (TAURI && t && t.cover ? TAURI.core.convertFileSrc(t.cover) : null);

/** Читает теги файлов (название, артист, обложка). Без Tauri возвращает пустые данные. */
async function readMetas(paths) {
  if (!TAURI) return paths.map(() => ({}));
  try {
    return await TAURI.core.invoke("read_metas", { paths });
  } catch (e) {
    console.error("read_metas failed", e);
    return paths.map(() => ({}));
  }
}

function fmtTime(s) {
  if (!isFinite(s)) return "0:00";
  s = Math.floor(s);
  return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function hashStr(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

// Монохромный «глянцевый» градиент обложки по названию трека
function gradientFor(title) {
  const h = hashStr(title);
  const a = 18 + (h % 40);
  const b = 55 + ((h >> 3) % 35);
  return `linear-gradient(${(h % 360)}deg, hsl(0 0% ${a}%), hsl(0 0% ${b}%))`;
}

function avatarSrc() {
  if (state.profile && state.profile.avatar) return state.profile.avatar;
  const letter = esc(((state.profile && state.profile.name) || "?").charAt(0).toUpperCase());
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128"><rect width="128" height="128" fill="#555"/><text x="50%" y="56%" font-size="64" font-family="sans-serif" fill="#fff" text-anchor="middle" dominant-baseline="middle">${letter}</text></svg>`;
  return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
}

function resizeImage(file, size = 256) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onerror = reject;
    fr.onload = () => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        const c = document.createElement("canvas");
        c.width = c.height = size;
        const side = Math.min(img.width, img.height);
        c.getContext("2d").drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, size, size);
        resolve(c.toDataURL("image/jpeg", 0.85));
      };
      img.src = fr.result;
    };
    fr.readAsDataURL(file);
  });
}

// ---------- Сохранение ----------
let saveTimer;
let pendingSave = Promise.resolve();
let suspendSaves = false;

function flushState() {
  clearTimeout(saveTimer);
  if (suspendSaves) return pendingSave;
  const json = JSON.stringify(state);
  pendingSave = pendingSave.catch(() => {}).then(() => {
    if (TAURI) return TAURI.core.invoke("save_state", { json });
    localStorage.setItem("zalupamusic", json);
  });
  return pendingSave;
}

function saveState() {
  if (suspendSaves) return;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => flushState().catch(error => console.error("save failed", error)), 250);
}

async function loadState() {
  let raw = "";
  try {
    raw = TAURI ? await TAURI.core.invoke("load_state") : localStorage.getItem("zalupamusic") || "";
  } catch (e) {
    console.error("load failed", e);
  }
  if (raw) {
    try {
      Object.assign(state, JSON.parse(raw));
    } catch (e) {
      console.error("bad state", e);
    }
  }
  state.settings ||= {};
  state.settings.backup ||= {};
  if (!Array.isArray(state.settings.backup.layers)) {
    state.settings.backup.layers = ["profile", "library", "checkins", "media", "settings"];
  }
  if (!state.theme) state.theme = matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
}

// ---------- Выбор и импорт файлов ----------
const AUDIO_EXT = ["mp3", "flac", "wav", "ogg", "m4a", "aac", "opus"];

/** Возвращает [{ src, name }] — выбранные пользователем аудиофайлы. */
async function pickAudioFiles() {
  if (TAURI) {
    const sel = await TAURI.dialog.open({
      multiple: true,
      filters: [{ name: "Аудио", extensions: AUDIO_EXT }],
    });
    if (!sel) return [];
    const list = Array.isArray(sel) ? sel : [sel];
    return list.map((p) => ({ src: typeof p === "string" ? p : p.path, name: (typeof p === "string" ? p : p.path).split(/[\\/]/).pop() }));
  }
  // Запасной вариант для запуска в обычном браузере (без сохранения файлов)
  return new Promise((resolve) => {
    const inp = document.createElement("input");
    inp.type = "file";
    inp.multiple = true;
    inp.accept = "audio/*";
    inp.onchange = () => resolve([...inp.files].map((f) => ({ src: URL.createObjectURL(f), name: f.name })));
    inp.click();
  });
}

async function importFiles(srcs) {
  if (!TAURI) return srcs;
  return await TAURI.core.invoke("import_tracks", { paths: srcs });
}

function draftFromName(name) {
  const base = name.replace(/\.[^.]+$/, "").replace(/_/g, " ");
  const m = base.split(/\s+-\s+/);
  return m.length > 1 ? { artist: m[0].trim(), title: m.slice(1).join(" - ").trim() } : { artist: "Неизвестный артист", title: base.trim() };
}

// Мягкая подсветка фона цветом обложки (если картинку нельзя прочитать — остаётся нейтральный фон)
let tintSeq = 0;
function tintFromCover(url) {
  const seq = ++tintSeq;
  const root = document.documentElement.style;
  const reset = () => ["--orb1", "--orb2", "--orb3"].forEach((v) => root.removeProperty(v));
  if (!url) return reset();
  const img = new Image();
  img.crossOrigin = "anonymous";
  img.onload = () => {
    if (seq !== tintSeq) return;
    try {
      const c = document.createElement("canvas");
      c.width = c.height = 16;
      const x = c.getContext("2d");
      x.drawImage(img, 0, 0, 16, 16);
      const d = x.getImageData(0, 0, 16, 16).data;
      let r = 0, g = 0, b = 0, n = 0;
      for (let i = 0; i < d.length; i += 4) { r += d[i]; g += d[i + 1]; b += d[i + 2]; n++; }
      r /= n; g /= n; b /= n;
      const mx = Math.max(r, g, b) / 255, mn = Math.min(r, g, b) / 255;
      let h = 0;
      if (mx !== mn) {
        const dd = mx - mn;
        h = mx === r / 255 ? ((g - b) / 255 / dd) % 6 : mx === g / 255 ? (b - r) / 255 / dd + 2 : (r - g) / 255 / dd + 4;
        h = Math.round(h * 60 + 360) % 360;
      }
      const light = document.documentElement.dataset.theme === "light";
      root.setProperty("--orb1", `hsl(${h} 42% ${light ? 80 : 34}%)`);
      root.setProperty("--orb2", `hsl(${(h + 40) % 360} 36% ${light ? 72 : 24}%)`);
      root.setProperty("--orb3", `hsl(${(h + 320) % 360} 38% ${light ? 76 : 42}%)`);
    } catch (e) { reset(); }
  };
  img.onerror = reset;
  img.src = url;
}
