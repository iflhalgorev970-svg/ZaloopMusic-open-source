// Автоподбор тегов: анализ звука (темп, энергичность, яркость) + жанр из тегов файла.
// Это эвристика: она хорошо ловит «быстрое/медленное», «громкое/тихое», «яркое/глухое»,
// но не понимает смысла песни, поэтому результат всегда можно поправить вручную.

let _anCtx = null;

function srcUrl(src) {
  return TAURI && src && !src.startsWith("blob:") ? TAURI.core.convertFileSrc(src) : src;
}

/** Возвращает { bpm, energy, bright } или null, если файл не удалось декодировать. */
async function analyzeTrack(url) {
  try {
    if (!_anCtx) _anCtx = new OfflineAudioContext(1, 1, 22050); // декодируем сразу в 22 кГц — быстро и экономно по памяти
    const res = await fetch(url);
    const arr = await res.arrayBuffer();
    const buf = await _anCtx.decodeAudioData(arr);
    const sr = buf.sampleRate;
    const full = buf.getChannelData(0);

    // берём 45 секунд из середины-начала трека
    const segLen = Math.min(full.length, Math.floor(45 * sr));
    const start = Math.max(0, Math.min(Math.floor(full.length * 0.25), full.length - segLen));
    const x = full.subarray(start, start + segLen);

    const win = 512, hop = 256;
    const n = Math.floor((x.length - win) / hop);
    if (n < 200) return null;
    const env = new Float32Array(n);
    let zSum = 0, eSum = 0;
    for (let f = 0; f < n; f++) {
      let s = 0, z = 0, prev = 0;
      const o = f * hop;
      for (let i = 0; i < win; i++) {
        const v = x[o + i];
        s += v * v;
        if (i && (v >= 0) !== (prev >= 0)) z++;
        prev = v;
      }
      env[f] = Math.sqrt(s / win);
      eSum += env[f];
      zSum += z / win;
    }
    const energy = eSum / n;
    const bright = zSum / n;

    // темп: автокорреляция огибающей атак
    const onset = new Float32Array(n);
    let mean = 0;
    for (let i = 1; i < n; i++) {
      onset[i] = Math.max(0, env[i] - env[i - 1]);
      mean += onset[i];
    }
    mean /= n;
    for (let i = 0; i < n; i++) onset[i] -= mean;
    const fps = sr / hop;
    const minLag = Math.floor((fps * 60) / 180);
    const maxLag = Math.ceil((fps * 60) / 60);
    let best = 0, bestLag = minLag;
    for (let L = minLag; L <= maxLag; L++) {
      let r = 0;
      for (let i = 0; i + L < n; i++) r += onset[i] * onset[i + L];
      if (r > best) { best = r; bestLag = L; }
    }
    let bpm = (60 * fps) / bestLag;
    while (bpm < 80) bpm *= 2;
    while (bpm > 170) bpm /= 2;
    return { bpm, energy, bright };
  } catch (e) {
    console.error("analyze failed", e);
    return null;
  }
}

function tagsFromFeatures(f) {
  if (!f) return [];
  const hi = f.energy > 0.16, lo = f.energy < 0.08;
  const fast = f.bpm >= 122, slow = f.bpm < 95;
  const br = f.bright > 0.10, dk = f.bright < 0.05;
  const t = [];
  if (hi && fast) {
    t.push("Энергичный", "Спорт");
    if (br) t.push("Вечеринка");
  } else if (hi) {
    t.push(dk ? "Мрачный" : "Энергичный");
    if (!dk) t.push("Дорога");
  } else if (lo && slow) {
    t.push("Спокойный", dk ? "Грустный" : "Мечтательный", "Сон");
  } else if (lo) {
    t.push("Спокойный", "Фокус");
    if (dk) t.push("Ночь");
  } else if (slow) {
    t.push(dk ? "Грустный" : "Романтичный");
    if (dk) t.push("Ночь");
  } else {
    t.push(br ? "Весёлый" : "Спокойный", fast ? "Дорога" : "Фокус");
  }
  return t;
}

function tagsFromGenre(g) {
  if (!g) return [];
  const s = String(g).toLowerCase();
  const out = [];
  if (/hip.?hop|rap|trap|рэп|хип/.test(s)) out.push("Хип-хоп");
  if (/rock|metal|punk|grunge|рок|метал/.test(s)) out.push("Рок");
  if (/electro|dance|house|techno|trance|edm|dubstep|synth|электро|танц/.test(s)) out.push("Электроника");
  if (/jazz|blues|swing|джаз|блюз/.test(s)) out.push("Джаз");
  if (/classic|orchestr|symphon|opera|баро|классик/.test(s)) out.push("Классика");
  if (/lo.?fi|chill|ambient|лоу/.test(s)) out.push("Лоу-фай");
  if (/pop|поп/.test(s)) out.push("Поп");
  return out;
}

function mergeTags(...lists) {
  return [...new Set(lists.flat())].filter((x) => ALL_TAGS.includes(x));
}
