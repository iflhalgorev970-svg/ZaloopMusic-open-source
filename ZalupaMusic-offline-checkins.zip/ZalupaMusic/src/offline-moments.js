(() => {
  function offline(remote, library) {
    let database;
    const db = () => database ||= new Promise((resolve, reject) => {
      const request = indexedDB.open("zm-moments", 1);
      request.onupgradeneeded = () => request.result.createObjectStore("records", { keyPath: "key" });
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => { database = null; reject(request.error); };
    });
    async function operation(mode, action) {
      const transaction = (await db()).transaction("records", mode);
      const request = action(transaction.objectStore("records"));
      return new Promise((resolve, reject) => {
        transaction.oncomplete = () => resolve(request.result);
        transaction.onabort = () => reject(transaction.error);
      });
    }
    const all = () => operation("readonly", store => store.getAll());
    const put = record => operation("readwrite", store => store.put(record));
    const get = key => operation("readonly", store => store.get(key));

    let running;
    async function syncNow(send) {
      const server = await remote.profile();
      const local = await all();
      const snapshot = { ...server, checkins: [] };
      let changed = JSON.stringify(snapshot) !== JSON.stringify(local.find(record => record.key === "server")?.data);
      if (changed) await put({ key: "server", data: snapshot });
      const profile = local.find(record => record.key === "profile");
      let sentAll = true;
      if (send && profile?.queued) {
        try {
          await remote.saveProfile(profile.data);
          changed = true;
          await operation("readwrite", store => {
            const request = store.get("profile");
            request.onsuccess = () => {
              if (request.result?.revision === profile.revision) store.put({ ...profile, queued: false });
            };
            return request;
          });
        } catch { sentAll = false; }
      }
      for (const record of local.filter(record => send && record.queued && record.entry)) {
        try {
          const entry = await remote.add({ entry: record.entry, ext: record.ext, data: record.data });
          await put({ ...record, queued: false, entry });
          changed = true;
        } catch {
          sentAll = false;
          // Оставляем запись в очереди до следующего соединения.
        }
      }
      for (const entry of server.checkins || []) {
        const key = "entry:" + entry.id;
        const previous = await get(key);
        if (previous?.queued || previous?.data || previous?.blob) continue;
        try {
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), 15000);
          const response = await fetch(remote.media(entry.media), { signal: controller.signal })
            .then(async response => response.ok ? await response.blob() : null)
            .finally(() => clearTimeout(timer));
          if (response) {
            await put({ key, entry, blob: response });
            changed = true;
            continue;
          }
        } catch {
          // Метаданные остаются доступны даже при сбое загрузки файла.
        }
        if (!previous) {
          await put({ key, entry });
          changed = true;
        }
      }
      return { ok: sentAll, changed };
    }
    async function sync(send = true) {
      if (running) {
        if (!send || running.send) return running.promise;
        await running.promise;
        return sync(send);
      }
      const promise = syncNow(send).catch(() => ({ ok: false, changed: false })).finally(() => { running = null; });
      running = { send, promise };
      return promise;
    }
    return {
      sync,
      async profile() {
        const records = await all();
        const data = records.find(item => item.key === "server")?.data || {};
        const local = library() || {};
        const tracks = [...new Map([...(data.tracks || []), ...(local.tracks || [])].map(t => [t.id, t])).values()];
        const entries = records.filter(item => item.entry);
        return {
          ...data, tracks, playlistCount: local.playlistCount ?? data.playlistCount ?? 0,
          profile: records.find(item => item.key === "profile")?.data || data.profile || local.profile,
          checkins: entries.map(item => ({ ...item.entry, pending: item.queued })),
          pendingCount: entries.filter(item => item.queued).length
        };
      },
      async saveProfile(data) {
        await put({ key: "profile", data, queued: true, revision: Date.now() + Math.random() });

      },
      async add({ entry, ext, data }) {
        const key = "entry:" + entry.id;
        await put({ key, entry: { ...entry, media: "checkins/" + entry.id + "." + ext }, ext, data, queued: true });
      },
      async media(path) {
        const id = path.split("/").pop().split(".")[0];
        const record = await get("entry:" + id);
        if (record?.blob) return URL.createObjectURL(record.blob);
        if (record?.data) {
          const mime = { jpg: "image/jpeg", mp4: "video/mp4", webm: "video/webm" }[record.ext];
          const response = await fetch("data:" + mime + ";base64," + record.data);
          return URL.createObjectURL(await response.blob());
        }
        return remote.media(path);
      }
    };
  }
  window.ZmOfflineMoments = offline;
})();
