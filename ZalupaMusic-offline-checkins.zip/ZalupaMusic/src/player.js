// Плеер: очередь, 3D-карусель, ВОЛНА, управление, мини-плеер, статистика прослушиваний.
const player = {
  source: "playlist",     // "playlist" | "wave"
  playlistId: "all",
  queue: [],              // массив id треков
  qi: -1,
  shuffle: false,
  repeat: 0,              // 0 выкл, 1 все, 2 один
  waveTags: new Set(),
  playing: false,
  recent: [],
  dirty: true,            // очередь поменялась -> карусель надо собрать заново
};

// учёт прослушиваний: трек засчитывается после 30 с (или половины, если он короче)
const listen = { id: null, sec: 0, counted: false, last: performance.now(), saveAt: 0 };

function currentTrack() {
  return player.qi >= 0 ? trackById(player.queue[player.qi]) : null;
}

function shuffled(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ---------- Источники ----------
function sourceTrackIds() {
  if (player.playlistId === "all") return state.tracks.filter(t => t.path).map(t => t.id);
  const pl = state.playlists.find((p) => p.id === player.playlistId);
  return pl ? pl.trackIds.filter((id) => trackById(id)?.path) : [];
}

/** ВОЛНА: подбор по выбранным тегам; чем больше совпадений — тем выше шанс. */
function buildWave() {
  const tags = [...player.waveTags];
  let pool = state.tracks.filter(t => t.path);
  if (tags.length) {
    pool = pool
      .map((t) => ({ t, score: t.tags.filter((x) => tags.includes(x)).length }))
      .filter((x) => x.score > 0)
      .map((x) => ({ id: x.t.id, key: x.score + Math.random() * 1.4 - (player.recent.includes(x.t.id) ? 0.8 : 0) }))
      .sort((a, b) => b.key - a.key)
      .map((x) => x.id);
  } else {
    pool = shuffled(pool.map((t) => t.id));
  }
  return pool.slice(0, 50);
}

function startQueue(ids, startIndex = 0) {
  player.dirty = true;
  if (!ids.length) {
    player.queue = [];
    player.qi = -1;
    renderCarousel();
    renderNowPlaying();
    return;
  }
  const firstId = ids[startIndex];
  let q = ids.filter(id => trackById(id)?.path);
  if (!q.length || !trackById(firstId)?.path) return;
  startIndex = q.indexOf(firstId);
  if (player.shuffle && player.source === "playlist") {
    const first = q[startIndex];
    q = shuffled(q.filter((x) => x !== first));
    q.unshift(first);
    startIndex = 0;
  }
  player.queue = q;
  playIndex(startIndex);
}

function playIndex(i, fade = 0.3) {
  if (i < 0 || i >= player.queue.length) return;
  player.qi = i;
  const t = currentTrack();
  if (!t) return;
  player.recent.push(t.id);
  if (player.recent.length > 12) player.recent.shift();
  listen.id = t.id;
  listen.sec = 0;
  listen.counted = false;
  engine.play(urlFor(t), fade);
  if (player.dirty) {
    player.dirty = false;
    renderCarousel();
  }
  renderNowPlaying();
  highlightPlaying();
}

function nextIndex(manual) {
  if (!player.queue.length) return -1;
  if (player.repeat === 2 && !manual) return player.qi;
  const n = player.qi + 1;
  if (n < player.queue.length) return n;
  if (player.source === "wave") {
    const q = buildWave();
    if (!q.length) return -1;
    player.queue = q;
    player.dirty = true;
    return 0;
  }
  return player.repeat === 1 || manual ? 0 : -1;
}

function next() {
  const n = nextIndex(true);
  if (n >= 0) playIndex(n);
}

function prev() {
  if (!player.queue.length) return;
  const el = engine.decks[engine.active] && engine.decks[engine.active].el;
  if (el && el.currentTime > 3) {
    engine.seek(0);
    return;
  }
  playIndex(player.qi > 0 ? player.qi - 1 : player.queue.length - 1);
}

// Автопереход (бесшовный): вызывается движком за N секунд до конца
engine.onAdvance = (fade) => {
  const n = nextIndex(false);
  if (n < 0) return false;
  playIndex(n, fade);
  return true;
};
engine.onState = (playing) => {
  player.playing = playing;
  $("btnPlay").textContent = playing ? "⏸" : "▶";
  $("mPlay").textContent = playing ? "⏸" : "▶";
  document.body.classList.toggle("is-playing", playing);
  if ("mediaSession" in navigator) navigator.mediaSession.playbackState = playing ? "playing" : "paused";
};
engine.onStop = () => {
  player.playing = false;
  $("btnPlay").textContent = "▶";
  $("mPlay").textContent = "▶";
  document.body.classList.remove("is-playing");
};

function setFill(input) {
  const pct = ((input.value - input.min) / (input.max - input.min)) * 100;
  input.style.setProperty("--p", pct + "%");
}

let seeking = false;
let lastSecShown = -1;
engine.onTime = (cur, dur) => {
  const now = performance.now();
  const dt = Math.min((now - listen.last) / 1000, 2);
  listen.last = now;

  // статистика прослушиваний
  if (player.playing && listen.id) {
    listen.sec += dt;
    const secs = state.stats.secs;
    secs[listen.id] = (secs[listen.id] || 0) + dt;
    if (!listen.counted && listen.sec >= Math.min(30, dur ? dur * 0.5 : 30)) {
      listen.counted = true;
      state.stats.plays[listen.id] = (state.stats.plays[listen.id] || 0) + 1;
      saveState();
    } else if (now - listen.saveAt > 20000) {
      listen.saveAt = now;
      saveState();
    }
  }

  // обновляем интерфейс только когда меняется секунда (меньше работы для слабых ПК)
  const sec = Math.floor(cur);
  if (sec === lastSecShown && !seeking) return;
  lastSecShown = sec;
  $("tCur").textContent = fmtTime(cur);
  $("tDur").textContent = fmtTime(dur);
  if (dur) {
    if (!seeking) {
      $("seek").value = Math.round((cur / dur) * 1000);
      setFill($("seek"));
    }
    $("miniBar").style.width = (cur / dur) * 100 + "%";
  }
};

// ---------- Визуализатор (под ползунком времени) ----------
let vizLast = 0, vizIdle = false;
function drawViz(ts) {
  requestAnimationFrame(drawViz);
  if (ts - vizLast < 33) return; // ~30 кадров/с — достаточно и дешевле
  vizLast = ts;
  const cv = $("viz");
  if (!cv || !document.getElementById("view-player").classList.contains("active")) return;
  if (!player.playing) {
    if (vizIdle) return;
    vizIdle = true;
  } else {
    vizIdle = false;
  }
  const g = cv.getContext("2d");
  g.clearRect(0, 0, cv.width, cv.height);
  const bars = 36;
  const data = new Uint8Array(engine.analyser ? engine.analyser.frequencyBinCount : 64);
  if (engine.analyser && player.playing) engine.analyser.getByteFrequencyData(data);
  g.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--fg").trim() || "#fff";
  const w = cv.width / bars;
  for (let i = 0; i < bars; i++) {
    const v = data[Math.floor((i / bars) * data.length * 0.8)] / 255;
    const h = Math.max(4, v * cv.height);
    g.globalAlpha = 0.25 + v * 0.65;
    const x = i * w + w * 0.2, bw = w * 0.6, y = (cv.height - h) / 2;
    g.beginPath();
    g.roundRect(x, y, bw, h, bw / 2);
    g.fill();
  }
  g.globalAlpha = 1;
}

// ---------- 3D-карусель (рисуем только ближайшие обложки — так не лагает на больших плейлистах) ----------
const carEls = new Map(); // индекс в очереди -> элемент
const CAR_R = 4;

function renderCarousel() {
  $("carousel").innerHTML = "";
  carEls.clear();
  layoutCarousel();
}

function makeCover(i, t) {
  const el = document.createElement("div");
  el.className = "cover";
  const cu = coverUrl(t);
  if (cu) {
    el.style.background = `url("${cu}") center/cover`;
    el.innerHTML = `<span class="cap">${esc(t.title)}</span>`;
  } else {
    el.style.background = gradientFor(t.title);
    el.innerHTML = `<span class="glyph">${esc(t.title.charAt(0).toUpperCase())}</span><span class="cap">${esc(t.title)}</span>`;
  }
  el.onclick = () => (i === player.qi ? engine.toggle() : playIndex(i));
  return el;
}

function posCover(el, off) {
  const a = Math.abs(off);
  el.classList.toggle("center", a === 0);
  if (a > 3) {
    el.style.opacity = 0;
    el.style.pointerEvents = "none";
    el.style.transform = `translateX(${Math.sign(off) * 520}px) translateZ(-420px) rotateY(${-Math.sign(off) * 60}deg)`;
    return;
  }
  el.style.opacity = a === 0 ? 1 : 0.85 - a * 0.18;
  el.style.pointerEvents = "auto";
  el.style.filter = a === 0 ? "none" : `brightness(${1 - a * 0.12})`;
  el.style.zIndex = 10 - a;
  el.style.transform = `translateX(${off * 150}px) translateZ(${-a * 130}px) rotateY(${-off * 38}deg) scale(${a === 0 ? 1.08 : 1})`;
}

function layoutCarousel() {
  const box = $("carousel");
  const c = Math.max(player.qi, 0);
  const lo = Math.max(0, c - CAR_R);
  const hi = Math.min(player.queue.length - 1, c + CAR_R);
  for (const [i, el] of carEls) {
    if (i < lo || i > hi) {
      el.remove();
      carEls.delete(i);
    }
  }
  for (let i = lo; i <= hi; i++) {
    let el = carEls.get(i);
    if (!el) {
      const t = trackById(player.queue[i]);
      if (!t) continue;
      el = makeCover(i, t);
      el.style.transition = "none"; // новая обложка появляется сразу на своём месте
      box.appendChild(el);
      carEls.set(i, el);
      posCover(el, i - c);
      void el.offsetWidth;
      el.style.transition = "";
      continue;
    }
    posCover(el, i - c);
  }
}

// ---------- Подпись «сейчас играет» + мини-плеер ----------
let miniShownId = null;

function updateMini() {
  const t = currentTrack();
  const show = !!t && currentView !== "player";
  $("miniPlayer").classList.toggle("hidden", !show);
  if (!t || t.id === miniShownId) return;
  miniShownId = t.id;
  $("miniTitle").textContent = t.title;
  $("miniArtist").textContent = t.artist;
  const cu = coverUrl(t);
  const cv = $("miniCover");
  if (cu) {
    cv.style.background = `url("${cu}") center/cover`;
    cv.textContent = "";
  } else {
    cv.style.background = "";
    cv.textContent = t.title.charAt(0).toUpperCase();
  }
}

let npShownId = null;
function renderNowPlaying() {
  const t = currentTrack();
  $("npTitle").textContent = t ? t.title : "Ничего не играет";
  $("npArtist").textContent = t ? t.artist : "Добавь треки в Библиотеке";
  $("npTags").innerHTML = t ? t.tags.map((x) => `<span class="tag">${esc(x)}</span>`).join("") : "";
  const nid = t ? t.id : "";
  if (nid !== npShownId) {
    npShownId = nid;
    tintFromCover(t ? coverUrl(t) : null);
    const now = document.querySelector(".now");
    now.classList.remove("swap");
    void now.offsetWidth;
    now.classList.add("swap");
  }
  layoutCarousel();
  miniShownId = null;
  updateMini();

  // название в системном медиа-оверлее Windows
  if (t && "mediaSession" in navigator) {
    try {
      const cu = coverUrl(t);
      navigator.mediaSession.metadata = new MediaMetadata({
        title: t.title,
        artist: t.artist,
        artwork: cu ? [{ src: cu }] : [],
      });
    } catch (e) { /* не критично */ }
  }
}

function renderSourceBar() {
  const sel = $("srcPlaylistSelect");
  sel.innerHTML =
    `<option value="all">Вся библиотека</option>` +
    state.playlists.map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join("");
  sel.value = state.playlists.some((p) => p.id === player.playlistId) ? player.playlistId : "all";
  player.playlistId = sel.value;

  $("waveMoods").innerHTML = MOOD_TAGS.map(
    (m) => `<span class="tag ${player.waveTags.has(m) ? "sel" : ""}" data-m="${m}" style="cursor:pointer">${m}</span>`
  ).join("");
  $("srcPlaylist").classList.toggle("active", player.source === "playlist");
  $("srcWave").classList.toggle("active", player.source === "wave");
  $("srcPlaylistSelect").classList.toggle("hidden", player.source === "wave");
  $("waveMoods").classList.toggle("hidden", player.source !== "wave");
}

function setSource(src) {
  player.source = src;
  renderSourceBar();
  if (src === "wave") startQueue(buildWave());
  else startQueue(sourceTrackIds());
}

function initPlayerControls() {
  $("btnPlay").onclick = () => {
    if (player.qi < 0) return setSource(player.source);
    engine.toggle();
  };
  $("btnNext").onclick = next;
  $("btnPrev").onclick = prev;
  $("mPlay").onclick = () => $("btnPlay").click();
  $("mNext").onclick = next;
  $("mPrev").onclick = prev;
  $("miniInfo").onclick = $("miniCover").onclick = () => showView("player");
  $("btnShuffle").onclick = () => {
    player.shuffle = !player.shuffle;
    $("btnShuffle").classList.toggle("on", player.shuffle);
  };
  $("btnRepeat").onclick = () => {
    player.repeat = (player.repeat + 1) % 3;
    $("btnRepeat").classList.toggle("on", player.repeat > 0);
    $("btnRepeat").textContent = player.repeat === 2 ? "↻1" : "↻";
  };
  setFill($("vol"));
  requestAnimationFrame(drawViz);
  $("vol").oninput = (e) => {
    setFill(e.target);
    state.volume = Number(e.target.value);
    engine.setVolume(state.volume / 100);
    saveState();
  };
  const seek = $("seek");
  seek.onmousedown = () => (seeking = true);
  seek.onmouseup = () => (seeking = false);
  seek.oninput = (e) => {
    setFill(e.target);
    engine.seek(Number(e.target.value) / 1000);
  };

  $("srcPlaylist").onclick = () => setSource("playlist");
  $("srcWave").onclick = () => setSource("wave");
  $("srcPlaylistSelect").onchange = (e) => {
    player.playlistId = e.target.value;
    setSource("playlist");
  };
  $("waveMoods").onclick = (e) => {
    const m = e.target.dataset && e.target.dataset.m;
    if (!m) return;
    player.waveTags.has(m) ? player.waveTags.delete(m) : player.waveTags.add(m);
    renderSourceBar();
    startQueue(buildWave());
  };

  document.addEventListener("keydown", (e) => {
    if (/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName)) return;
    if (e.code === "Space") { e.preventDefault(); $("btnPlay").click(); }
    if (e.code === "ArrowRight") next();
    if (e.code === "ArrowLeft") prev();
    // на случай, если системные медиа-клавиши дошли до самого окна
    if (e.code === "MediaPlayPause") $("btnPlay").click();
    if (e.code === "MediaTrackNext") next();
    if (e.code === "MediaTrackPrevious") prev();
  });
}
