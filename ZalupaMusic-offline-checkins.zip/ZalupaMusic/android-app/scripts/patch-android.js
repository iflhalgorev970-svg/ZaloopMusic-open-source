// Правит сгенерированный Android-проект: HTTP к ПК в локальной сети, фоновое воспроизведение, путь к SDK.
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..", "android");
const manifestPath = path.join(root, "app", "src", "main", "AndroidManifest.xml");

if (!fs.existsSync(manifestPath)) {
  console.error("AndroidManifest.xml не найден — сначала выполни: npx cap add android");
  process.exit(1);
}

let m = fs.readFileSync(manifestPath, "utf8");

if (!/usesCleartextTraffic/.test(m)) {
  m = m.replace("<application", '<application\n        android:usesCleartextTraffic="true"');
}

const perms = [
  "android.permission.INTERNET",
  "android.permission.ACCESS_NETWORK_STATE",
  "android.permission.WAKE_LOCK",
  "android.permission.FOREGROUND_SERVICE",
  "android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK",
  "android.permission.POST_NOTIFICATIONS",
  "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS",
];
let add = "";
for (const p of perms) {
  if (!m.includes(`"${p}"`)) add += `    <uses-permission android:name="${p}" />\n`;
}
if (add) m = m.replace("</manifest>", add + "</manifest>");

// служба уведомления-плеера (нативный код лежит в android-app/native)
if (!m.includes("ZmPlayerService")) {
  m = m.replace("</application>", '    <service android:name=".ZmPlayerService" android:exported="false" android:foregroundServiceType="mediaPlayback" />\n    </application>');
}
fs.writeFileSync(manifestPath, m);

const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "capacitor.config.json"), "utf8"));
const pkgDir = path.join(root, "app", "src", "main", "java", ...cfg.appId.split("."));
fs.mkdirSync(pkgDir, { recursive: true });
const nativeDir = path.join(__dirname, "..", "native");
for (const f of fs.readdirSync(nativeDir)) {
  if (f.endsWith(".java")) {
    let src = fs.readFileSync(path.join(nativeDir, f), "utf8");
    src = src.replace(/^package .*;/m, "package " + cfg.appId + ";");
    fs.writeFileSync(path.join(pkgDir, f), src);
    console.log("native:", f);
  }
}
// иконка уведомления (монохромная)
const drawDir = path.join(root, "app", "src", "main", "res", "drawable");
fs.mkdirSync(drawDir, { recursive: true });
fs.writeFileSync(
  path.join(drawDir, "ic_zm_notify.xml"),
  '<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">' +
    '<path android:fillColor="#FFFFFFFF" android:pathData="M9,18V6l10,-2v12h-2V7.6L11,8.8V18c0,1.66 -1.57,3 -3.5,3S4,19.66 4,18s1.57,-3 3.5,-3c0.54,0 1.04,0.1 1.5,0.28V18z"/>' +
    "</vector>\n"
);
console.log("manifest patched");

// путь к Android SDK
const lp = path.join(root, "local.properties");
const sdk =
  process.env.ANDROID_HOME ||
  process.env.ANDROID_SDK_ROOT ||
  (process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, "Android", "Sdk") : "");
if (sdk && fs.existsSync(sdk)) {
  fs.writeFileSync(lp, "sdk.dir=" + sdk.replace(/\\/g, "\\\\").replace(/:/g, "\\:") + "\n");
  console.log("sdk.dir =", sdk);
} else if (!fs.existsSync(lp)) {
  console.warn("Android SDK не найден. Установи Android Studio (см. README) и запусти скрипт снова.");
}
