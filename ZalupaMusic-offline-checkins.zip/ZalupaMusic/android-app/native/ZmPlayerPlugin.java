package com.zalupamusic.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Мост JS ↔ нативная служба уведомления-плеера. */
@CapacitorPlugin(name = "ZmPlayer")
public class ZmPlayerPlugin extends Plugin {

    @Override
    public void load() {
        ZmPlayerService.listener = (action, posMs) -> {
            JSObject o = new JSObject();
            o.put("action", action);
            if (posMs >= 0) o.put("position", posMs / 1000.0);
            notifyListeners("action", o);
        };
    }

    @Override
    protected void handleOnDestroy() {
        ZmPlayerService.listener = null;
        super.handleOnDestroy();
    }

    @PluginMethod
    public void update(PluginCall call) {
        synchronized (ZmPlayerService.LOCK) {
            if (call.hasOption("title")) ZmPlayerService.title = call.getString("title", "");
            if (call.hasOption("artist")) ZmPlayerService.artist = call.getString("artist", "");
            if (call.hasOption("playing")) ZmPlayerService.playing = Boolean.TRUE.equals(call.getBoolean("playing", false));
            if (call.hasOption("position")) {
                Double d = call.getDouble("position", 0.0);
                ZmPlayerService.posMs = d == null ? 0 : (long) (d * 1000);
            }
            if (call.hasOption("duration")) {
                Double d = call.getDouble("duration", 0.0);
                ZmPlayerService.durMs = d == null ? 0 : (long) (d * 1000);
            }
            if (call.hasOption("artwork")) {
                String a = call.getString("artwork", "");
                ZmPlayerService.art = decode(a);
            }
        }
        ZmPlayerService.push(getContext());
        call.resolve();
    }

    private static Bitmap decode(String data) {
        try {
            if (data == null || data.isEmpty()) return null;
            int comma = data.indexOf(',');
            if (data.startsWith("data:") && comma >= 0) data = data.substring(comma + 1);
            byte[] b = Base64.decode(data, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(b, 0, b.length);
        } catch (Exception e) {
            return null;
        }
    }

    @PluginMethod
    public void stop(PluginCall call) {
        synchronized (ZmPlayerService.LOCK) { ZmPlayerService.playing = false; }
        ZmPlayerService.shutdown(getContext());
        call.resolve();
    }

    @PluginMethod
    public void batteryStatus(PluginCall call) {
        JSObject o = new JSObject();
        boolean ok = true;
        if (Build.VERSION.SDK_INT >= 23) {
            PowerManager pm = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
            ok = pm != null && pm.isIgnoringBatteryOptimizations(getContext().getPackageName());
        }
        o.put("unrestricted", ok);
        call.resolve(o);
    }

    @PluginMethod
    public void batteryExempt(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getContext().getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Exception e) {
            try {
                Intent i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            } catch (Exception e2) { /* нечего открывать */ }
        }
        call.resolve();
    }
}
