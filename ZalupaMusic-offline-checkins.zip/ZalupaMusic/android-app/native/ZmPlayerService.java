package com.zalupamusic.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;

/**
 * Служба переднего плана: системное уведомление-плеер (шторка и экран блокировки),
 * MediaSession для гарнитуры/Bluetooth и WakeLock, чтобы воспроизведение не засыпало с выключенным экраном.
 * Сам звук играет WebView (audio-элемент), служба только показывает состояние и пробрасывает кнопки в JS.
 */
public class ZmPlayerService extends Service {
    public interface Listener { void onAction(String action, long positionMs); }

    public static volatile Listener listener;
    public static volatile ZmPlayerService instance;

    // состояние (общее для плагина и службы)
    static final Object LOCK = new Object();
    static String title = "ZalupaMusic";
    static String artist = "";
    static boolean playing = false;
    static long posMs = 0;
    static long durMs = 0;
    static Bitmap art = null;

    static final String CHANNEL = "zm_playback";
    static final int NID = 4711;
    static final String A_PLAY = "zm.PLAY", A_PAUSE = "zm.PAUSE", A_NEXT = "zm.NEXT", A_PREV = "zm.PREV", A_STOP = "zm.STOP";

    private MediaSession session;
    private PowerManager.WakeLock wake;
    private boolean inForeground = false;
    private boolean everFg = false;
    private final Handler main = new Handler(Looper.getMainLooper());

    /** Вызывается из плагина: обновить состояние и (если надо) запустить службу. */
    public static void push(Context ctx) {
        ZmPlayerService s = instance;
        if (s != null) {
            s.main.post(s::refresh);
            return;
        }
        boolean p;
        synchronized (LOCK) { p = playing; }
        if (!p) return; // на паузе службу заново не поднимаем
        Intent i = new Intent(ctx, ZmPlayerService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i); else ctx.startService(i);
        } catch (Exception e) { /* приложение в фоне и запуск запрещён — уведомление не покажем */ }
    }

    public static void shutdown(Context ctx) {
        ZmPlayerService s = instance;
        if (s != null) s.main.post(s::stopSelf);
    }

    private static void emit(String action, long pos) {
        Listener l = listener;
        if (l != null) l.onAction(action, pos);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Плеер", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            ch.setSound(null, null);
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(ch);
        }
        session = new MediaSession(this, "ZalupaMusic");
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { emit("play", -1); }
            @Override public void onPause() { emit("pause", -1); }
            @Override public void onSkipToNext() { emit("next", -1); }
            @Override public void onSkipToPrevious() { emit("prev", -1); }
            @Override public void onStop() { emit("pause", -1); }
            @Override public void onSeekTo(long pos) { emit("seekto", pos); }
        });
        session.setActive(true);
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ZalupaMusic:playback");
            wake.setReferenceCounted(false);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? null : intent.getAction();
        if (A_PLAY.equals(a)) emit("play", -1);
        else if (A_PAUSE.equals(a)) emit("pause", -1);
        else if (A_NEXT.equals(a)) emit("next", -1);
        else if (A_PREV.equals(a)) emit("prev", -1);
        else if (A_STOP.equals(a)) { emit("pause", -1); stopSelf(); return START_NOT_STICKY; }
        refresh();
        return START_NOT_STICKY;
    }

    private PendingIntent act(String action, int code) {
        Intent i = new Intent(this, ZmPlayerService.class).setAction(action);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getService(this, code, i, fl);
    }

    private Notification.Action action(int icon, String label, PendingIntent pi) {
        return new Notification.Action.Builder(Icon.createWithResource(this, icon), label, pi).build();
    }

    private void refresh() {
        String t; String ar; boolean p; long pos; long dur; Bitmap bm;
        synchronized (LOCK) { t = title; ar = artist; p = playing; pos = posMs; dur = durMs; bm = art; }

        MediaMetadata.Builder mb = new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, t)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, ar)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, dur > 0 ? dur : -1);
        if (bm != null) {
            mb.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, bm);
            mb.putBitmap(MediaMetadata.METADATA_KEY_ART, bm);
        }
        session.setMetadata(mb.build());

        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS
                | PlaybackState.ACTION_SEEK_TO | PlaybackState.ACTION_STOP;
        PlaybackState ps = new PlaybackState.Builder()
                .setActions(actions)
                .setState(p ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, pos, p ? 1f : 0f, SystemClock.elapsedRealtime())
                .build();
        session.setPlaybackState(ps);

        if (wake != null) {
            try {
                if (p && !wake.isHeld()) wake.acquire(6 * 60 * 60 * 1000L);
                else if (!p && wake.isHeld()) wake.release();
            } catch (Exception e) { /* ignore */ }
        }

        Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        int small = getResources().getIdentifier("ic_zm_notify", "drawable", getPackageName());
        nb.setSmallIcon(small != 0 ? small : android.R.drawable.ic_media_play)
          .setContentTitle(t)
          .setContentText(ar)
          .setOnlyAlertOnce(true)
          .setShowWhen(false)
          .setOngoing(p)
          .setVisibility(Notification.VISIBILITY_PUBLIC)
          .setDeleteIntent(act(A_STOP, 9));
        if (bm != null) nb.setLargeIcon(bm);
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (launch != null) {
            nb.setContentIntent(PendingIntent.getActivity(this, 0, launch,
                    PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0)));
        }
        nb.addAction(action(android.R.drawable.ic_media_previous, "Назад", act(A_PREV, 1)));
        if (p) nb.addAction(action(android.R.drawable.ic_media_pause, "Пауза", act(A_PAUSE, 2)));
        else nb.addAction(action(android.R.drawable.ic_media_play, "Играть", act(A_PLAY, 3)));
        nb.addAction(action(android.R.drawable.ic_media_next, "Вперёд", act(A_NEXT, 4)));
        nb.setStyle(new Notification.MediaStyle()
                .setMediaSession(session.getSessionToken())
                .setShowActionsInCompactView(0, 1, 2));
        Notification n = nb.build();

        if (p || !everFg) {
            // после startForegroundService обязательно нужен startForeground, даже если уже успели нажать паузу
            if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(NID, n);
            inForeground = true;
            everFg = true;
        }
        if (!p) {
            if (inForeground) {
                if (Build.VERSION.SDK_INT >= 24) stopForeground(Service.STOP_FOREGROUND_DETACH);
                else stopForeground(false);
                inForeground = false;
            }
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NID, n);
        }
    }

    @Override
    public void onDestroy() {
        instance = null;
        try { if (wake != null && wake.isHeld()) wake.release(); } catch (Exception e) { /* ignore */ }
        try { session.setActive(false); session.release(); } catch (Exception e) { /* ignore */ }
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(NID);
        } catch (Exception e) { /* ignore */ }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
