// ZalupaMusic Mobile: тот же каталог, что на ПК. Библиотека и аудио приходят с ПК по Wi-Fi.
(() => {
"use strict";
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const MOODS = ["Грустный", "Весёлый", "Спокойный", "Энергичный", "Романтичный", "Мрачный", "Мечтательный", "Фокус", "Спорт", "Ночь", "Дорога", "Вечеринка", "Сон"];
const store = {
  get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* приватный режим */ } },
};

// ---- ключ доступа из QR-ссылки ----
let K = "";
try {
  const u = new URL(location.href);
  const k = u.searchParams.get("k");
  if (k) {
    store.set("zm_k", k);
    u.searchParams.delete("k");
    history.replaceState(null, "", u.pathname + u.search);
  }
} catch (e) { /* ignore */ }
K = store.get("zm_k") || "";

const mediaUrl = (id) => `/media/${id}?k=${K}`;
const coverUrl = (t) => (t && t.cover ? `/cover/${t.id}?k=${K}` : null);

// ---- данные ----
let lib = null;
const phoneMoments = ZmOfflineMoments(ZmMoments.phone(path => path + "?k=" + encodeURIComponent(K)), () => ({
  profile: lib?.profile, tracks: lib?.tracks, playlistCount: lib?.playlists?.length
}));
let byId = new Map();
try { lib = JSON.parse(store.get("zm_lib") || "null"); } catch (e) { lib = null; }
const index = () => { byId = new Map(((lib && lib.tracks) || []).map((t) => [t.id, t])); };
index();
const trackById = (id) => byId.get(id);

const P = { source: "playlist", plId: "all", tags: new Set(), queue: [], qi: -1, shuffle: false, repeat: 0, recent: [], dirty: true };
const A = $("audio");
let curView = "player";
let openedPl = null;

function fmt(s) { if (!isFinite(s)) return "0:00"; s = Math.floor(s); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); }
function hashStr(s) { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); }
function gradientFor(title) { const h = hashStr(title); return `linear-gradient(${h % 360}deg, hsl(0 0% ${18 + (h % 40)}%), hsl(0 0% ${55 + ((h >> 3) % 35)}%))`; }
function setFill(input) { input.style.setProperty("--p", ((input.value - input.min) / (input.max - input.min)) * 100 + "%"); }
const cur = () => (P.qi >= 0 ? trackById(P.queue[P.qi]) : null);
const allIds = () => ((lib && lib.tracks) || []).map((t) => t.id);

// ---- тема ----
function applyTheme() {
  let t = store.get("zm_theme");
  if (!t) t = matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  document.documentElement.dataset.theme = t;
  const m = document.querySelector('meta[name="theme-color"]');
  if (m) m.content = t === "light" ? "#eeeef1" : "#0a0a0c";
}

// ---- экран подключения ----
function gate(title, text) { $("gateTitle").textContent = title; $("gateText").textContent = text; $("gate").classList.remove("hidden"); }
const ungate = () => $("gate").classList.add("hidden");

// ---- загрузка библиотеки с ПК ----
async function loadLibrary(manual) {
  if (!K) { gate("Нужна ссылка с ПК", "Открой ZalupaMusic на компьютере, перейди во вкладку «Телефон» и наведи камеру на QR-код."); return; }
  if (manual) $("syncBtn").classList.add("spin");
  try {
    const r = await fetch(`/api/library?k=${encodeURIComponent(K)}`, { cache: "no-store" });
    if (r.status === 401) { gate("Ссылка устарела", "Доступ был сброшен на ПК. Отсканируй QR-код во вкладке «Телефон» заново."); setDot(false); return; }
    lib = await r.json();
    void refreshMoments();
    store.set("zm_lib", JSON.stringify(lib));
    index();
    ungate();
    setDot(true);
    onLibrary();
  } catch (e) {
    setDot(false);
    if (!lib) gate("Нет связи с ПК", "Проверь, что ZalupaMusic запущен на компьютере и телефон в той же Wi-Fi сети.");
  } finally {
    $("syncBtn").classList.remove("spin");
  }
}
function setDot(on) { $("dot").classList.toggle("on", on); }

function onLibrary() {
  if (!P.queue.length || P.queue.every((id) => !trackById(id))) {
    P.queue = allIds();
    P.qi = -1;
    P.dirty = true;
    // вернуться к последнему треку (без автозапуска)
    const last = store.get("zm_last");
    const i = last ? P.queue.indexOf(last) : -1;
    if (i >= 0) playIndex(i, false);
  }
  renderAll();
}

// ---- рендер ----
function renderAll() { renderSource(); renderCarousel(); renderNow(); renderLibrary(); renderPlaylists(); }

function thumbStyle(t) { const c = coverUrl(t); return c ? `style="background-image:url('${c}')"` : ""; }
function row(t, ids) {
  const el = document.createElement("div");
  el.className = "row";
  el.dataset.id = t.id;
  el.innerHTML = `<div class="thumb" ${thumbStyle(t)}>${t.cover ? "" : esc((t.title || "?").charAt(0).toUpperCase())}</div>
    <div class="info"><b>${esc(t.title)}</b><span>${esc(t.artist)}${t.tags && t.tags.length ? " · " + esc(t.tags.slice(0, 3).join(", ")) : ""}</span></div>`;
  el.onclick = () => { P.source = "playlist"; renderSource(); startQueue(ids, ids.indexOf(t.id)); };
  return el;
}
function fill(box, tracks) {
  box.innerHTML = "";
  if (!tracks.length) { box.innerHTML = `<div class="empty">Здесь пока пусто</div>`; return; }
  const ids = tracks.map((t) => t.id);
  const frag = document.createDocumentFragment();
  tracks.forEach((t) => frag.appendChild(row(t, ids)));
  box.appendChild(frag);
  markPlaying();
}
function markPlaying() {
  const c = cur();
  document.querySelectorAll(".row").forEach((r) => r.classList.toggle("playing", !!c && r.dataset.id === c.id));
}
function renderLibrary() {
  const q = $("q").value.trim().toLowerCase();
  let tracks = (lib && lib.tracks) || [];
  if (q) tracks = tracks.filter((t) => (t.title + " " + t.artist + " " + (t.tags || []).join(" ")).toLowerCase().includes(q));
  fill($("libList"), tracks);
}
function renderPlaylists() {
  const pls = (lib && lib.playlists) || [];
  if (openedPl && !pls.find((p) => p.id === openedPl)) openedPl = null;
  if (openedPl) {
    const pl = pls.find((p) => p.id === openedPl);
    $("plGrid").classList.add("hidden");
    $("plDetail").classList.remove("hidden");
    $("plTitle").textContent = pl.name;
    fill($("plList"), pl.trackIds.map(trackById).filter(Boolean));
    return;
  }
  $("plDetail").classList.add("hidden");
  $("plGrid").classList.remove("hidden");
  $("plGrid").innerHTML = pls.length ? "" : `<div class="empty" style="grid-column:1/-1">Плейлистов пока нет. Создай их в приложении на ПК.</div>`;
  pls.forEach((p) => {
    const c = document.createElement("div");
    c.className = "plcard";
    c.innerHTML = `<div class="big">${esc((p.name || "?").charAt(0).toUpperCase())}</div><b>${esc(p.name)}</b><span class="muted">${p.trackIds.length} треков</span>`;
    c.onclick = () => { openedPl = p.id; renderPlaylists(); };
    $("plGrid").appendChild(c);
  });
}

// ---- источник: плейлист / ВОЛНА ----
function renderSource() {
  const pls = (lib && lib.playlists) || [];
  const sel = $("plSelect");
  sel.innerHTML = `<option value="all">Вся библиотека</option>` + pls.map((p) => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join("");
  sel.value = pls.some((p) => p.id === P.plId) ? P.plId : "all";
  P.plId = sel.value;
  $("moods").innerHTML = MOODS.map((m) => `<span class="tag ${P.tags.has(m) ? "sel" : ""}" data-m="${m}">${m}</span>`).join("");
  $("srcPl").classList.toggle("active", P.source === "playlist");
  $("srcWave").classList.toggle("active", P.source === "wave");
  sel.classList.toggle("hidden", P.source === "wave");
  $("moods").classList.toggle("hidden", P.source !== "wave");
}
function sourceIds() {
  if (P.plId === "all") return allIds();
  const pl = ((lib && lib.playlists) || []).find((p) => p.id === P.plId);
  return pl ? pl.trackIds.filter((id) => trackById(id)) : [];
}
function shuffled(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
function buildWave() {
  const tags = [...P.tags];
  let pool = ((lib && lib.tracks) || []).slice();
  if (tags.length) {
    pool = pool
      .map((t) => ({ id: t.id, score: (t.tags || []).filter((x) => tags.includes(x)).length }))
      .filter((x) => x.score > 0)
      .map((x) => ({ id: x.id, key: x.score + Math.random() * 1.4 - (P.recent.includes(x.id) ? 0.8 : 0) }))
      .sort((a, b) => b.key - a.key)
      .map((x) => x.id);
  } else {
    pool = shuffled(pool.map((t) => t.id));
  }
  return pool.slice(0, 50);
}
function setSource(src) { P.source = src; renderSource(); startQueue(src === "wave" ? buildWave() : sourceIds()); }

// ---- очередь и воспроизведение ----
function startQueue(ids, start = 0) {
  P.dirty = true;
  if (!ids.length) { P.queue = []; P.qi = -1; renderCarousel(); renderNow(); return; }
  let q = ids.slice();
  if (P.shuffle && P.source === "playlist") {
    const first = q[start];
    q = shuffled(q.filter((x) => x !== first));
    q.unshift(first);
    start = 0;
  }
  P.queue = q;
  playIndex(start, true);
}
function playIndex(i, autoplay = true) {
  if (i < 0 || i >= P.queue.length) return;
  P.qi = i;
  const t = cur();
  if (!t) return;
  P.recent.push(t.id);
  if (P.recent.length > 12) P.recent.shift();
  store.set("zm_last", t.id);
  A.src = mediaUrl(t.id);
  if (autoplay) A.play().catch(() => {}); else A.load();
  if (P.dirty) { P.dirty = false; renderCarousel(); }
  renderNow();
  markPlaying();
}
function nextIndex(manual) {
  if (!P.queue.length) return -1;
  if (P.repeat === 2 && !manual) return P.qi;
  const n = P.qi + 1;
  if (n < P.queue.length) return n;
  if (P.source === "wave") { const q = buildWave(); if (!q.length) return -1; P.queue = q; P.dirty = true; return 0; }
  return P.repeat === 1 || manual ? 0 : -1;
}
function next() { const n = nextIndex(true); if (n >= 0) playIndex(n); }
function prev() {
  if (!P.queue.length) return;
  if (A.currentTime > 3) { A.currentTime = 0; return; }
  playIndex(P.qi > 0 ? P.qi - 1 : P.queue.length - 1);
}
function toggle() {
  if (!A.src) { setSource(P.source); return; }
  if (A.paused) A.play().catch(() => {}); else A.pause();
}

// ---- 3D-карусель (только ближайшие обложки) ----
const carEls = new Map();
const R = 3;
function renderCarousel() { $("carousel").innerHTML = ""; carEls.clear(); layoutCarousel(); }
function makeCover(i, t) {
  const el = document.createElement("div");
  el.className = "cover";
  const c = coverUrl(t);
  if (c) { el.style.background = `url("${c}") center/cover`; el.innerHTML = `<span class="cap">${esc(t.title)}</span>`; }
  else { el.style.background = gradientFor(t.title || "?"); el.innerHTML = `<span class="glyph">${esc((t.title || "?").charAt(0).toUpperCase())}</span><span class="cap">${esc(t.title)}</span>`; }
  el.onclick = () => (i === P.qi ? toggle() : playIndex(i));
  return el;
}
function posCover(el, off, cs) {
  const a = Math.abs(off);
  el.classList.toggle("center", a === 0);
  if (a > 2) {
    el.style.opacity = 0;
    el.style.pointerEvents = "none";
    el.style.transform = `translateX(${Math.sign(off) * cs * 1.2}px) translateZ(-${cs * 1.4}px) rotateY(${-Math.sign(off) * 60}deg)`;
    return;
  }
  el.style.opacity = a === 0 ? 1 : 0.85 - a * 0.22;
  el.style.pointerEvents = "auto";
  el.style.filter = a === 0 ? "none" : `brightness(${1 - a * 0.15})`;
  el.style.zIndex = 10 - a;
  el.style.transform = `translateX(${off * cs * 0.56}px) translateZ(${-a * cs * 0.5}px) rotateY(${-off * 38}deg) scale(${a === 0 ? 1.06 : 1})`;
}
function layoutCarousel() {
  const box = $("carousel");
  const cs = box.offsetWidth || 200;
  const c = Math.max(P.qi, 0);
  const lo = Math.max(0, c - R), hi = Math.min(P.queue.length - 1, c + R);
  for (const [i, el] of carEls) if (i < lo || i > hi) { el.remove(); carEls.delete(i); }
  for (let i = lo; i <= hi; i++) {
    let el = carEls.get(i);
    if (!el) {
      const t = trackById(P.queue[i]);
      if (!t) continue;
      el = makeCover(i, t);
      el.style.transition = "none";
      box.appendChild(el);
      carEls.set(i, el);
      posCover(el, i - c, cs);
      void el.offsetWidth;
      el.style.transition = "";
    } else posCover(el, i - c, cs);
  }
}
// свайп по карусели
(function swipe() {
  const w = document.querySelector(".carousel-wrap");
  let x0 = null, y0 = 0;
  w.addEventListener("pointerdown", (e) => { x0 = e.clientX; y0 = e.clientY; });
  w.addEventListener("pointerup", (e) => {
    if (x0 === null) return;
    const dx = e.clientX - x0, dy = e.clientY - y0;
    x0 = null;
    if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.4) { dx < 0 ? next() : prev(); }
  });
  w.addEventListener("pointercancel", () => (x0 = null));
})();

// ---- подписи, мини-плеер, экран блокировки ----
let miniId = null;
function updateMini() {
  const t = cur();
  $("mini").classList.toggle("hidden", !(t && curView !== "player"));
  if (!t || t.id === miniId) return;
  miniId = t.id;
  $("miniTitle").textContent = t.title;
  $("miniArtist").textContent = t.artist;
  const c = coverUrl(t), cv = $("miniCover");
  cv.style.backgroundImage = c ? `url('${c}')` : "";
  cv.textContent = c ? "" : (t.title || "?").charAt(0).toUpperCase();
}
function renderNow() {
  const t = cur();
  $("npTitle").textContent = t ? t.title : "Ничего не играет";
  $("npArtist").textContent = t ? t.artist : "Выбери трек в библиотеке";
  $("npTags").innerHTML = t && t.tags ? t.tags.map((x) => `<span class="tag">${esc(x)}</span>`).join("") : "";
  const n = document.querySelector(".now");
  n.classList.remove("swap"); void n.offsetWidth; n.classList.add("swap");
  layoutCarousel();
  miniId = null;
  updateMini();
  if (t && "mediaSession" in navigator) {
    try {
      const c = coverUrl(t);
      navigator.mediaSession.metadata = new MediaMetadata({ title: t.title, artist: t.artist, artwork: c ? [{ src: c, sizes: "400x400", type: "image/jpeg" }] : [] });
    } catch (e) { /* не критично */ }
  }
}
function initMediaSession() {
  if (!("mediaSession" in navigator)) return;
  const set = (a, f) => { try { navigator.mediaSession.setActionHandler(a, f); } catch (e) { /* не поддерживается */ } };
  set("play", () => A.play().catch(() => {}));
  set("pause", () => A.pause());
  set("previoustrack", prev);
  set("nexttrack", next);
  set("seekto", (d) => { if (d.seekTime != null) A.currentTime = d.seekTime; });
}

// ---- события аудио ----
let seeking = false, lastSec = -1;
A.addEventListener("play", () => syncPlay(true));
A.addEventListener("pause", () => syncPlay(false));
A.addEventListener("ended", () => { const n = nextIndex(false); if (n >= 0) playIndex(n); else syncPlay(false); });
A.addEventListener("error", () => { if (A.src) setDot(false); });
A.addEventListener("timeupdate", () => {
  const sec = Math.floor(A.currentTime);
  if (sec === lastSec && !seeking) return;
  lastSec = sec;
  const d = A.duration;
  $("tCur").textContent = fmt(A.currentTime);
  $("tDur").textContent = fmt(d);
  if (d && isFinite(d)) {
    if (!seeking) { $("seek").value = Math.round((A.currentTime / d) * 1000); setFill($("seek")); }
    $("miniBar").style.width = (A.currentTime / d) * 100 + "%";
    if ("mediaSession" in navigator && navigator.mediaSession.setPositionState) {
      try { navigator.mediaSession.setPositionState({ duration: d, position: Math.min(A.currentTime, d), playbackRate: A.playbackRate }); } catch (e) { /* ignore */ }
    }
  }
});
function syncPlay(p) {
  document.body.classList.toggle("playing", p);
  $("bPlay").textContent = p ? "⏸" : "▶";
  $("mPlay").textContent = p ? "⏸" : "▶";
  if ("mediaSession" in navigator) navigator.mediaSession.playbackState = p ? "playing" : "paused";
}

// ---- навигация ----
function show(v) {
  curView = v;
  if (v === "profile") { ZmMoments.render($("v-profile"), phoneMoments, true); void refreshMoments(); }
  document.querySelectorAll(".view").forEach((s) => s.classList.toggle("active", s.id === "v-" + v));
  document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t.dataset.v === v));
  if (v === "player") layoutCarousel();
  updateMini();
}

async function refreshMoments() {
  if (!K) return;
  const synced = await phoneMoments.sync();
  const root = $("v-profile");
  if (synced.changed && curView === "profile" && !root.querySelector("form:not([hidden])")) {
    await ZmMoments.render(root, phoneMoments, true);
  }
}

function init() {
  setInterval(() => { if (!document.hidden) void refreshMoments(); }, 12000);
  applyTheme();
  document.querySelectorAll(".tab").forEach((t) => (t.onclick = () => show(t.dataset.v)));
  $("themeBtn").onclick = () => {
    const t = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
    store.set("zm_theme", t);
    applyTheme();
  };
  $("syncBtn").onclick = () => loadLibrary(true);
  $("gateRetry").onclick = () => loadLibrary(true);
  $("bPlay").onclick = toggle; $("mPlay").onclick = toggle;
  $("bNext").onclick = next; $("mNext").onclick = next;
  $("bPrev").onclick = prev;
  $("miniInfo").onclick = $("miniCover").onclick = () => show("player");
  $("bShuffle").onclick = () => { P.shuffle = !P.shuffle; $("bShuffle").classList.toggle("on", P.shuffle); };
  $("bRepeat").onclick = () => { P.repeat = (P.repeat + 1) % 3; $("bRepeat").classList.toggle("on", P.repeat > 0); $("bRepeat").textContent = P.repeat === 2 ? "↻1" : "↻"; };
  const seek = $("seek");
  seek.addEventListener("pointerdown", () => (seeking = true));
  seek.addEventListener("pointerup", () => (seeking = false));
  seek.addEventListener("input", (e) => { setFill(e.target); if (A.duration) A.currentTime = (e.target.value / 1000) * A.duration; });
  setFill(seek);
  $("srcPl").onclick = () => setSource("playlist");
  $("srcWave").onclick = () => setSource("wave");
  $("plSelect").onchange = (e) => { P.plId = e.target.value; setSource("playlist"); };
  $("moods").onclick = (e) => {
    const m = e.target.dataset && e.target.dataset.m;
    if (!m) return;
    P.tags.has(m) ? P.tags.delete(m) : P.tags.add(m);
    renderSource();
    startQueue(buildWave());
  };
  $("q").oninput = renderLibrary;
  $("plBack").onclick = () => { openedPl = null; renderPlaylists(); };
  $("plPlay").onclick = () => {
    if (!openedPl) return;
    P.plId = openedPl; P.source = "playlist";
    renderSource(); startQueue(sourceIds()); show("player");
  };
  initMediaSession();
  window.addEventListener("resize", layoutCarousel);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) loadLibrary(false); });

  if (lib) onLibrary();
  loadLibrary(false);
}
init();
})();
