@echo off
cd /d "%~dp0"
echo ===== ZalupaMusic: building exe =====

echo [1/4] Installing dependencies...
call npm install
if errorlevel 1 goto fail

if exist "src-tauri\icons\icon.ico" goto icons_ok
echo [2/4] Generating icons...
call npm run tauri -- icon app-icon.png
if errorlevel 1 goto fail
goto step3
:icons_ok
echo [2/4] Icons already exist

:step3
echo [3/4] Building release exe - first build takes 5-15 minutes...
call npm run build:exe
if errorlevel 1 goto fail

echo [4/4] Packing...
if exist dist rmdir /s /q dist
mkdir dist
copy /y "src-tauri\target\release\zalupamusic.exe" "dist\ZalupaMusic.exe" >nul
if errorlevel 1 goto fail
powershell -NoProfile -Command "Compress-Archive -Force -Path 'dist\ZalupaMusic.exe' -DestinationPath 'dist\ZalupaMusic.zip'"

echo.
echo DONE. Files are in the dist folder:
echo    dist\ZalupaMusic.exe  - double-click to run
echo    dist\ZalupaMusic.zip  - send this to friends
explorer dist
pause
exit /b 0

:fail
echo.
echo ERROR. Copy the text above and send it to me.
pause
exit /b 1
