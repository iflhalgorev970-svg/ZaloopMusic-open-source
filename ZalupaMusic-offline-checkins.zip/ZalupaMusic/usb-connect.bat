@echo off
cd /d "%~dp0"
echo ===== ZalupaMusic: USB connection to phone / emulator =====

set "ADB="
where adb >nul 2>nul
if not errorlevel 1 set "ADB=adb"
if not defined ADB if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
if not defined ADB if defined ANDROID_HOME if exist "%ANDROID_HOME%\platform-tools\adb.exe" set "ADB=%ANDROID_HOME%\platform-tools\adb.exe"
if defined ADB goto have_adb
echo [!] adb not found. Install "Android SDK Platform-Tools" in Android Studio - SDK Manager - SDK Tools.
goto fail
:have_adb

echo.
echo Connected devices:
"%ADB%" devices
echo.
echo If the list is empty: enable USB debugging on the phone and allow this computer on the phone screen.
echo If there are two devices (phone + emulator), unplug or close one of them.
echo.

if not exist "dist\ZalupaMusic.apk" goto skip_install
echo [1/3] Installing app (dist\ZalupaMusic.apk)...
"%ADB%" install -r "dist\ZalupaMusic.apk"
if errorlevel 1 goto fail
:skip_install

set "PORT="
set "LINK="
for /f "tokens=1,2" %%A in ('powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\usb-link.ps1"') do set "PORT=%%A" & set "LINK=%%B"
if defined PORT goto have_port
echo [!] Start ZalupaMusic on the PC first (it creates the access key), then run this script again.
goto fail
:have_port

echo [2/3] Forwarding port %PORT% over USB...
"%ADB%" reverse tcp:%PORT% tcp:%PORT%
if errorlevel 1 goto fail

echo [3/3] Link copied to clipboard:
echo       %LINK%
echo.
echo On the phone: open ZalupaMusic - Sync tab - Paste - Connect.
echo (this link works over the cable, no Wi-Fi needed; run this script again after re-plugging the cable)
pause
exit /b 0

:fail
echo.
echo ERROR. Copy the text above and send it to me.
pause
exit /b 1
