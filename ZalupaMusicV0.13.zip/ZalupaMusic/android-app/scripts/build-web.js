// Собирает веб-часть приложения в папку www (её потом упаковывает Capacitor в APK).
const esbuild = require("esbuild");
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const out = path.join(root, "www");
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

esbuild.buildSync({
  entryPoints: [path.join(root, "src", "main.js")],
  bundle: true,
  minify: true,
  format: "iife",
  target: ["chrome90"],
  outfile: path.join(out, "app.js"),
});
for (const f of ["index.html", "app.css"]) {
  fs.copyFileSync(path.join(root, "src", f), path.join(out, f));
}
console.log("web build ok -> www/");
