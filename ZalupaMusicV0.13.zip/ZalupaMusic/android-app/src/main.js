// ZalupaMusic для Android: библиотека синхронизируется с ПК, треки скачиваются на телефон и играют офлайн.
import { Capacitor, CapacitorHttp, registerPlugin } from "@capacitor/core";
import { Filesystem, Directory, Encoding } from "@capacitor/filesystem";
import { Network } from "@capacitor/network";
import { LocalNotifications } from "@capacitor/local-notifications";
// собственный нативный плагин (android-app/native): уведомление-плеер, экран блокировки, фоновая служба
const ZmPlayer = registerPlugin("ZmPlayer");

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const MOODS = ["Грустный", "Весёлый", "Спокойный", "Энергичный", "Романтичный", "Мрачный", "Мечтательный", "Фокус", "Спорт", "Ночь", "Дорога", "Вечеринка", "Сон"];

const store = {
  get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* ignore */ } },
};
const jget = (k, d) => { try { const v = store.get(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
const jset = (k, v) => store.set(k, JSON.stringify(v));

const DIR = Directory.Data;
// Нативная загрузка на некоторых телефонах не резолвит "localhost" — всегда используем 127.0.0.1
const normUrl = (u) => String(u || "").replace(/\/\/localhost\b/i, "//127.0.0.1");
let SERVER = normUrl(store.get("zm_server") || "");
let K = store.get("zm_k") || "";
let libRaw = store.get("zm_lib") || "";
let lib = jget("zm_lib", null);
let dl = jget("zm_dl", {});                 // id -> { ext, size, cover }  (что реально скачано на телефон)
const settings = Object.assign({ auto: true, wifiOnly: true, cleanup: false }, jget("zm_set", {}));
let connected = false;
let musicBase = "", coverBase = "";
let own = jget("zm_own", []);               // треки, скачанные прямо на телефон из интернета (вкладка «Поиск»)
const saveOwn = () => jset("zm_own", own);
const allTracks = () => [...((lib && lib.tracks) || []), ...own];
let byId = new Map();
const reindex = () => { byId = new Map(allTracks().map((t) => [t.id, t])); };
reindex();
const trackById = (id) => byId.get(id);
const allIds = () => allTracks().map((t) => t.id);
const saveDl = () => jset("zm_dl", dl);
const saveSettings = () => jset("zm_set", settings);

const remote = (p) => `${SERVER}${p}?k=${K}`;
function localMedia(t) { const d = dl[t.id]; return d && musicBase ? Capacitor.convertFileSrc(`${musicBase}/${t.id}.${d.ext}`) : null; }
function localCover(t) { const d = dl[t.id]; return d && d.cover && coverBase ? Capacitor.convertFileSrc(`${coverBase}/${t.id}.jpg`) : null; }
const coverSrc = (t) => localCover(t) || (connected && t && t.cover ? remote(`/cover/${t.id}`) : null);
const mediaSrc = (t) => localMedia(t) || (connected ? remote(`/media/${t.id}`) : null);

// Мягкая подсветка фона цветом обложки (если картинку нельзя прочитать — остаётся нейтральный фон)
let tintSeq = 0;
function tintFromCover(url) {
  const seq = ++tintSeq;
  const root = document.documentElement.style;
  const reset = () => ["--orb1", "--orb2", "--orb3"].forEach((v) => root.removeProperty(v));
  if (!url) return reset();
  const img = new Image();
  img.crossOrigin = "anonymous";
  img.onload = () => {
    if (seq !== tintSeq) return;
    try {
      const c = document.createElement("canvas");
      c.width = c.height = 16;
      const x = c.getContext("2d");
      x.drawImage(img, 0, 0, 16, 16);
      const d = x.getImageData(0, 0, 16, 16).data;
      let r = 0, g = 0, b = 0, n = 0;
      for (let i = 0; i < d.length; i += 4) { r += d[i]; g += d[i + 1]; b += d[i + 2]; n++; }
      r /= n; g /= n; b /= n;
      const mx = Math.max(r, g, b) / 255, mn = Math.min(r, g, b) / 255;
      let h = 0;
      if (mx !== mn) {
        const dd = mx - mn;
        h = mx === r / 255 ? ((g - b) / 255 / dd) % 6 : mx === g / 255 ? (b - r) / 255 / dd + 2 : (r - g) / 255 / dd + 4;
        h = Math.round(h * 60 + 360) % 360;
      }
      const light = document.documentElement.dataset.theme === "light";
      root.setProperty("--orb1", `hsl(${h} 42% ${light ? 80 : 34}%)`);
      root.setProperty("--orb2", `hsl(${(h + 40) % 360} 36% ${light ? 72 : 24}%)`);
      root.setProperty("--orb3", `hsl(${(h + 320) % 360} 38% ${light ? 76 : 42}%)`);
    } catch (e) { reset(); }
  };
  img.onerror = reset;
  img.src = url;
}

const IC = {
  play: '<svg viewBox="0 0 24 24"><path d="M8 5.2v13.6a.8.8 0 0 0 1.2.7l11-6.8a.8.8 0 0 0 0-1.4l-11-6.8A.8.8 0 0 0 8 5.2z"/></svg>',
  pause: '<svg viewBox="0 0 24 24"><rect x="6" y="5" width="4.2" height="14" rx="1.3"/><rect x="13.8" y="5" width="4.2" height="14" rx="1.3"/></svg>',
  prev: '<svg viewBox="0 0 24 24"><rect x="4.5" y="5" width="2.6" height="14" rx="1.1"/><path d="M19.5 5.6v12.8a.7.7 0 0 1-1.1.6L9 12.6a.7.7 0 0 1 0-1.2L18.4 5a.7.7 0 0 1 1.1.6z"/></svg>',
  next: '<svg viewBox="0 0 24 24"><rect x="16.9" y="5" width="2.6" height="14" rx="1.1"/><path d="M4.5 5.6v12.8a.7.7 0 0 0 1.1.6L15 12.6a.7.7 0 0 0 0-1.2L5.6 5a.7.7 0 0 0-1.1.6z"/></svg>',
  shuffle: '<svg class="st" viewBox="0 0 24 24"><path d="M3 7h3.5c2 0 3.2 1 4.3 2.7l2.4 3.6c1.1 1.7 2.3 2.7 4.3 2.7H21M3 17h3.5c2 0 3.2-1 4.3-2.7M13.2 8.7c1.1-1.7 2.3-2.7 4.3-2.7H21M18.5 3.5 21 6l-2.5 2.5M18.5 12.5 21 15l-2.5 2.5"/></svg>',
  repeat: '<svg class="st" viewBox="0 0 24 24"><path d="M4 11V9.5A3.5 3.5 0 0 1 7.5 6H20M17 3l3 3-3 3M20 13v1.5a3.5 3.5 0 0 1-3.5 3.5H4M7 21l-3-3 3-3"/></svg>',
  down: '<svg class="st" viewBox="0 0 24 24"><path d="M12 4v11M7 11l5 5 5-5M5 20h14"/></svg>',
  check: '<svg class="st" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  eq: '<svg class="st" viewBox="0 0 24 24"><path d="M5 4v16M12 4v16M19 4v16"/><circle cx="5" cy="14" r="2.3" fill="currentColor"/><circle cx="12" cy="8" r="2.3" fill="currentColor"/><circle cx="19" cy="15" r="2.3" fill="currentColor"/></svg>',
  refresh: '<svg class="st" viewBox="0 0 24 24"><path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/></svg>',
  theme: '<svg class="st" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M12 4a8 8 0 0 1 0 16z" fill="currentColor"/></svg>',
  search: '<svg class="st" viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/></svg>',
  note: '<svg class="st" viewBox="0 0 24 24"><path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/></svg>',
  list: '<svg class="st" viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h10"/></svg>',
  grid: '<svg class="st" viewBox="0 0 24 24"><rect x="4" y="4" width="7" height="7" rx="2"/><rect x="13" y="4" width="7" height="7" rx="2"/><rect x="4" y="13" width="7" height="7" rx="2"/><rect x="13" y="13" width="7" height="7" rx="2"/></svg>',
  sync: '<svg class="st" viewBox="0 0 24 24"><path d="M7 4v13M3.5 8 7 4l3.5 4M17 20V7M13.5 16 17 20l3.5-4"/></svg>',
};

// ---------- утилиты ----------
function fmt(s) { if (!isFinite(s)) return "0:00"; s = Math.floor(s); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); }
function fmtBytes(n) { if (n >= 1073741824) return (n / 1073741824).toFixed(1) + " ГБ"; if (n >= 1048576) return Math.round(n / 1048576) + " МБ"; return Math.round(n / 1024) + " КБ"; }
function hashStr(s) { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); }
function gradientFor(title) { const h = hashStr(title); return `linear-gradient(${h % 360}deg, hsl(0 0% ${18 + (h % 40)}%), hsl(0 0% ${55 + ((h >> 3) % 35)}%))`; }
function setFill(input) { input.style.setProperty("--p", ((input.value - input.min) / (input.max - input.min)) * 100 + "%"); }
let toastT;
function toast(m) { const el = $("toast"); el.textContent = m; el.classList.add("show"); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove("show"), 3000); }
async function fetchT(url, ms) {
  const c = new AbortController();
  const t = setTimeout(() => c.abort(), ms);
  try { return await fetch(url, { cache: "no-store", signal: c.signal }); } finally { clearTimeout(t); }
}
function applyTheme() {
  let t = store.get("zm_theme");
  if (!t) t = matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  document.documentElement.dataset.theme = t;
}

// ---------- плеер: состояние ----------
const P = { source: "playlist", plId: "all", tags: new Set(), queue: [], qi: -1, shuffle: false, repeat: 0, recent: [], dirty: true };
const A = $("audio");
let srcKind = "";
let curView = "player";
let openedPl = null;
let onlyLocal = false;
const cur = () => (P.qi >= 0 ? trackById(P.queue[P.qi]) : null);

// ---------- связь с ПК ----------
function setConn(on) {
  connected = on;
  $("dot").classList.toggle("on", on);
  document.body.classList.toggle("offline", !on);
  renderSyncUI();
}

let discovering = false, discoverTried = false;
async function discover() {
  const m = SERVER.match(/^http:\/\/(\d+\.\d+\.\d+)\.\d+:(\d+)/);
  if (!m || !K) return false;
  const prefix = m[1], port = m[2];
  discovering = true;
  let found = null;
  for (let b = 1; b < 255 && !found; b += 48) {
    const batch = [];
    for (let i = b; i < Math.min(b + 48, 255); i++) batch.push(i);
    await Promise.all(batch.map(async (i) => {
      const base = `http://${prefix}.${i}:${port}`;
      try { const r = await fetchT(`${base}/api/library?k=${K}`, 900); if (r.ok && !found) found = base; } catch (e) { /* нет ответа */ }
    }));
  }
  discovering = false;
  if (found) { SERVER = found; store.set("zm_server", found); return true; }
  return false;
}
async function tryDiscover(force) {
  if (discovering || (discoverTried && !force)) return;
  discoverTried = true;
  if (force) toast("Ищу ПК в сети…");
  if (await discover()) { toast("ПК найден"); loadLibrary(false); }
  else if (force) toast("ПК не найден. Проверь, что он включён, а ZalupaMusic запущен");
}

async function loadLibrary(manual) {
  if (!SERVER || !K) { setConn(false); return false; }
  if (manual) $("syncTop").classList.add("spin");
  try {
    const r = await fetchT(remote("/api/library"), 6000);
    if (r.status === 401) { setConn(false); toast("Ключ недействителен. Подключись заново"); return false; }
    if (!r.ok) throw new Error("http " + r.status);
    const txt = await r.text();
    const changed = txt !== libRaw;
    libRaw = txt;
    if (changed || !lib) {
      lib = JSON.parse(txt);
      store.set("zm_lib", txt);
      reindex();
    }
    setConn(true);
    if (changed) onLibrary();
    maybeFirstSync();
    return true;
  } catch (e) {
    setConn(false);
    if (manual) toast("Нет связи с ПК");
    tryDiscover(false);
    return false;
  } finally {
    $("syncTop").classList.remove("spin");
  }
}

function onLibrary() {
  if (!P.queue.length || P.queue.every((id) => !trackById(id))) {
    P.queue = allIds();
    P.qi = -1;
    P.dirty = true;
    const last = store.get("zm_last");
    const i = last ? P.queue.indexOf(last) : -1;
    if (i >= 0) playIndex(i, false);
  }
  renderAll();
}

// ---------- подключение по USB (ПК сам кладёт ключ через adb) ----------
let adbAuto = false, adbBusy = false;
async function readAdbLink() {
  if (adbBusy) return;
  adbBusy = true;
  try {
    const r = await Filesystem.readFile({ path: "zm_connect.json", directory: Directory.External, encoding: Encoding.UTF8 });
    const cfg = JSON.parse(typeof r.data === "string" ? r.data : await r.data.text());
    if (!cfg || !cfg.server || !cfg.k || String(cfg.t) === store.get("zm_adb_t")) return;
    store.set("zm_adb_t", String(cfg.t));
    SERVER = normUrl(cfg.server); K = cfg.k;
    store.set("zm_server", SERVER); store.set("zm_k", K);
    adbAuto = !!cfg.autoSync;
    discoverTried = true;
    toast("Подключено к ПК по USB");
    await loadLibrary(true);
  } catch (e) { /* файла нет — телефон не подключали по кабелю */ }
  finally { adbBusy = false; }
}

// ---------- загрузка треков на телефон ----------
let syncErrs = [];
const sync = { running: false, cancel: false, done: 0, total: 0, bytesDone: 0, bytesTotal: 0, cur: 0 };
const missing = () => allTracks().filter((t) => !t.missing && (!dl[t.id] || (t.size && dl[t.id].size !== t.size)));

// Папки music/ и covers/ надо создать заранее: нативная downloadFile сама их не создаёт (ошибка ENOENT).
async function ensureDirs() {
  for (const d of ["music", "covers"]) {
    try { await Filesystem.mkdir({ path: d, directory: DIR, recursive: true }); } catch (e) { /* уже есть */ }
  }
}
function toB64(bytes) {
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}
// Запасной путь: качаем потоком через fetch и дописываем файл кусками (не держим весь трек в памяти).
async function streamDownload(url, path, track) {
  const r = await fetch(url, { cache: "no-store" });
  if (!r.ok) throw new Error("ПК ответил " + r.status);
  const TH = 786432; // кратно 3, чтобы base64 кусков склеивался без искажений
  let buf = new Uint8Array(0), first = true, got = 0;
  const write = async (bytes) => {
    const data = toB64(bytes);
    if (first) { first = false; await Filesystem.writeFile({ path, directory: DIR, data, recursive: true }); }
    else await Filesystem.appendFile({ path, directory: DIR, data });
  };
  const push = (chunk) => { const n = new Uint8Array(buf.length + chunk.length); n.set(buf); n.set(chunk, buf.length); buf = n; };
  const reader = r.body && r.body.getReader ? r.body.getReader() : null;
  if (!reader) { await write(new Uint8Array(await r.arrayBuffer())); return; }
  for (;;) {
    const { done, value } = await reader.read();
    if (value) { push(value); got += value.length; if (track) { sync.cur = got; if (sync.running) updateProgress(); } }
    while (buf.length >= TH) { await write(buf.subarray(0, TH)); buf = buf.slice(TH); }
    if (done) break;
  }
  if (buf.length || first) await write(buf);
}

async function downloadOne(t) {
  const ext = String(t.ext || "mp3").replace(/[^a-z0-9]/gi, "") || "mp3";
  if (t.missing) throw new Error("файла нет на ПК (удалён или перемещён)");
  const path = `music/${t.id}.${ext}`;
  const url = remote(`/media/${t.id}`);
  const errs = [];
  let ok = false;
  for (let attempt = 0; attempt < 3 && !ok; attempt++) {
    try {
      if (attempt === 0) {
        await ensureDirs();
        await Filesystem.downloadFile({ url, path, directory: DIR, recursive: true, progress: true });
      } else {
        try { await Filesystem.deleteFile({ path, directory: DIR }); } catch (e2) { /* нет файла */ }
        await ensureDirs();
        await streamDownload(url, path, true);
      }
      let size = 0;
      try { size = (await Filesystem.stat({ path, directory: DIR })).size || 0; } catch (e) { /* stat не критичен */ }
      if (t.size && size && Math.abs(size - t.size) > 1024) throw new Error(`размер ${size} вместо ${t.size}`);
      ok = true;
    } catch (e) {
      errs.push((e && (e.message || e.errorMessage)) || String(e));
      try { await Filesystem.deleteFile({ path, directory: DIR }); } catch (e2) { /* ignore */ }
      await new Promise((r) => setTimeout(r, 500 * (attempt + 1)));
    }
  }
  if (!ok) throw new Error(errs.join(" | "));
  let cover = false;
  if (t.cover) {
    const cpath = `covers/${t.id}.jpg`;
    try { await Filesystem.downloadFile({ url: remote(`/cover/${t.id}`), path: cpath, directory: DIR, recursive: true }); cover = true; }
    catch (e) {
      try { await streamDownload(remote(`/cover/${t.id}`), cpath, false); cover = true; } catch (e2) { /* без обложки */ }
    }
  }
  dl[t.id] = { ext, size: t.size || 0, cover };
  saveDl();
}

async function runSync(list) {
  if (sync.running) { toast("Синхронизация уже идёт"); return; }
  if (!connected) { toast("Нет связи с ПК"); return; }
  list = list || missing();
  if (!list.length) { toast("Всё уже скачано"); return; }
  Object.assign(sync, { running: true, cancel: false, done: 0, total: list.length, bytesDone: 0, bytesTotal: list.reduce((s, t) => s + (t.size || 0), 0), cur: 0 });
  renderSyncUI();
  let failed = 0;
  const errs = [];
  for (const t of list) {
    if (sync.cancel) break;
    try { await downloadOne(t); } catch (e) {
      failed++;
      errs.push(`${t.artist ? t.artist + " — " : ""}${t.title}: ${(e && (e.message || e.errorMessage)) || e}`);
      try { const r = await fetchT(`${SERVER}/manifest.webmanifest`, 3000); if (!r.ok) throw new Error(); } catch (e2) { toast("Связь с ПК потеряна"); setConn(false); break; }
    }
    sync.done++;
    sync.bytesDone += t.size || 0;
    sync.cur = 0;
    updateProgress();
    refreshRow(t.id);
  }
  if (!sync.cancel && settings.cleanup) await cleanup();
  const cancelled = sync.cancel;
  sync.running = false;
  syncErrs = errs;
  renderSyncUI();
  renderLibrary();
  toast(cancelled ? "Синхронизация остановлена" : failed ? `Не скачалось: ${failed}. Подробности во вкладке «Синхр.»` : "Синхронизация завершена");
}

async function deleteLocal(id) {
  const d = dl[id];
  if (!d) return;
  try { await Filesystem.deleteFile({ path: `music/${id}.${d.ext}`, directory: DIR }); } catch (e) { /* уже нет */ }
  if (d.cover) { try { await Filesystem.deleteFile({ path: `covers/${id}.jpg`, directory: DIR }); } catch (e) { /* ignore */ } }
  delete dl[id];
  saveDl();
  if (own.some((o) => o.id === id)) { own = own.filter((o) => o.id !== id); saveOwn(); reindex(); renderLibrary(); }
}
async function cleanup() {
  for (const id of Object.keys(dl)) if (!trackById(id)) await deleteLocal(id);
}

async function maybeFirstSync() {
  if (sync.running) return;
  const miss = missing();
  if (!miss.length) return;
  if (adbAuto) { adbAuto = false; store.set("zm_asked", "1"); runSync(miss); return; }
  if (!store.get("zm_asked")) {
    store.set("zm_asked", "1");
    const gb = (miss.reduce((s, t) => s + (t.size || 0), 0) / 1073741824).toFixed(1);
    if (confirm(`Скачать ${miss.length} треков на телефон (≈${gb} ГБ)? Их можно будет слушать без ПК и интернета.`)) runSync(miss);
    else { settings.auto = false; saveSettings(); renderSyncUI(); }
    return;
  }
  if (!settings.auto) return;
  let st = null;
  try { st = await Network.getStatus(); } catch (e) { /* ignore */ }
  if (settings.wifiOnly && st && st.connectionType !== "wifi") return;
  runSync(miss);
}

// ---------- рендер ----------
function renderAll() { renderSource(); renderCarousel(); renderNow(); renderLibrary(); renderPlaylists(); renderSyncUI(); }

function thumbStyle(t) { const c = coverSrc(t); return c ? `style="background-image:url('${c}')"` : ""; }
function dlIcon(t) { return dl[t.id] ? IC.check : IC.down; }
function row(t, ids) {
  const el = document.createElement("div");
  el.className = "row" + (dl[t.id] ? " local" : "");
  el.dataset.id = t.id;
  el.innerHTML = `<div class="thumb" ${thumbStyle(t)}>${coverSrc(t) ? "" : esc((t.title || "?").charAt(0).toUpperCase())}</div>
    <div class="info"><b>${esc(t.title)}</b><span>${esc(t.artist)}${t.tags && t.tags.length ? " · " + esc(t.tags.slice(0, 3).join(", ")) : ""}</span></div>
    <button class="dlb ${dl[t.id] ? "on" : ""}" aria-label="Скачать">${dlIcon(t)}</button>`;
  el.onclick = () => { P.source = "playlist"; renderSource(); startQueue(ids, ids.indexOf(t.id)); };
  el.querySelector(".dlb").onclick = async (e) => {
    e.stopPropagation();
    if (dl[t.id]) {
      if (confirm(`Удалить «${t.title}» с телефона? На ПК трек останется.`)) { await deleteLocal(t.id); refreshRow(t.id); renderSyncUI(); }
    } else runSync([t]);
  };
  return el;
}
function refreshRow(id) {
  const t = trackById(id);
  document.querySelectorAll(`.row[data-id="${id}"]`).forEach((r) => {
    r.classList.toggle("local", !!dl[id]);
    const b = r.querySelector(".dlb");
    if (b && t) { b.innerHTML = dlIcon(t); b.classList.toggle("on", !!dl[id]); }
  });
}
function fill(box, tracks) {
  box.innerHTML = "";
  if (!tracks.length) { box.innerHTML = `<div class="empty">${lib ? "Здесь пока пусто" : "Подключись к ПК во вкладке «Синхр.»"}</div>`; return; }
  const ids = tracks.map((t) => t.id);
  const frag = document.createDocumentFragment();
  tracks.forEach((t) => frag.appendChild(row(t, ids)));
  box.appendChild(frag);
  markPlaying();
}
function markPlaying() {
  const c = cur();
  document.querySelectorAll(".row").forEach((r) => r.classList.toggle("playing", !!c && r.dataset.id === c.id));
}
function renderLibrary() {
  const q = $("q").value.trim().toLowerCase();
  let tracks = allTracks();
  if (onlyLocal) tracks = tracks.filter((t) => dl[t.id]);
  if (q) tracks = tracks.filter((t) => (t.title + " " + t.artist + " " + (t.tags || []).join(" ")).toLowerCase().includes(q));
  fill($("libList"), tracks);
}
function renderPlaylists() {
  const pls = (lib && lib.playlists) || [];
  if (openedPl && !pls.find((p) => p.id === openedPl)) openedPl = null;
  if (openedPl) {
    const pl = pls.find((p) => p.id === openedPl);
    $("plGrid").classList.add("hidden");
    $("plDetail").classList.remove("hidden");
    $("plTitle").textContent = pl.name;
    fill($("plList"), pl.trackIds.map(trackById).filter(Boolean));
    return;
  }
  $("plDetail").classList.add("hidden");
  $("plGrid").classList.remove("hidden");
  $("plGrid").innerHTML = pls.length ? "" : `<div class="empty" style="grid-column:1/-1">Плейлистов пока нет. Создай их в приложении на ПК</div>`;
  pls.forEach((p) => {
    const have = p.trackIds.filter((id) => dl[id]).length;
    const c = document.createElement("div");
    c.className = "plcard";
    c.innerHTML = `<div class="big">${esc((p.name || "?").charAt(0).toUpperCase())}</div><b>${esc(p.name)}</b><span class="muted">${have}/${p.trackIds.length} на телефоне</span>`;
    c.onclick = () => { openedPl = p.id; renderPlaylists(); };
    $("plGrid").appendChild(c);
  });
}

function updateProgress() {
  const pct = sync.bytesTotal ? ((sync.bytesDone + sync.cur) / sync.bytesTotal) * 100 : sync.total ? (sync.done / sync.total) * 100 : 0;
  const w = Math.min(100, pct) + "%";
  $("syncBar").style.width = w;
  $("bannerBar").style.width = w;
  const txt = `Скачано ${sync.done} из ${sync.total}`;
  $("syncText").textContent = txt;
  $("bannerText").textContent = "Синхронизация: " + txt.toLowerCase();
}
function renderSyncUI() {
  $("srvStatus").textContent = !SERVER ? "Не подключено" : connected ? `Подключено · ${SERVER.replace("http://", "")}` : "Нет связи с ПК (треки с телефона играют)";
  $("srvStatus").className = "status" + (connected ? " ok" : "");
  const tr = allTracks();
  const have = tr.filter((t) => dl[t.id]).length;
  const bytes = Object.values(dl).reduce((s, d) => s + (d.size || 0), 0);
  $("syncInfo").textContent = lib ? `На телефоне: ${have} из ${tr.length} треков · ${fmtBytes(bytes)}` : "Библиотека ещё не загружена";
  const miss = missing().length;
  $("syncGo").disabled = sync.running || !connected || (!!lib && !miss);
  $("syncGo").textContent = !lib || miss ? `Синхронизировать${miss ? " (" + miss + ")" : ""}` : "Всё синхронизировано";
  $("flow").classList.toggle("on", connected);
  $("flow").classList.toggle("run", sync.running);
  $("syncCancel").classList.toggle("hidden", !sync.running);
  $("syncBox").classList.toggle("hidden", !sync.running);
  $("syncBanner").classList.toggle("hidden", !sync.running);
  $("syncErr").classList.toggle("hidden", !syncErrs.length || sync.running);
  $("syncErrList").textContent = syncErrs.join("\n");
  $("tAuto").checked = settings.auto;
  $("tWifi").checked = settings.wifiOnly;
  $("tClean").checked = settings.cleanup;
  if (sync.running) updateProgress();
}

// ---------- источник: плейлист / ВОЛНА ----------
function renderSource() {
  const pls = (lib && lib.playlists) || [];
  const sel = $("plSelect");
  sel.innerHTML = `<option value="all">Вся библиотека</option>` + pls.map((p) => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join("");
  sel.value = pls.some((p) => p.id === P.plId) ? P.plId : "all";
  P.plId = sel.value;
  $("moods").innerHTML = MOODS.map((m) => `<span class="tag ${P.tags.has(m) ? "sel" : ""}" data-m="${m}">${m}</span>`).join("");
  $("srcPl").classList.toggle("active", P.source === "playlist");
  $("srcWave").classList.toggle("active", P.source === "wave");
  sel.classList.toggle("hidden", P.source === "wave");
  $("moods").classList.toggle("hidden", P.source !== "wave");
}
function sourceIds() {
  if (P.plId === "all") return allIds();
  const pl = ((lib && lib.playlists) || []).find((p) => p.id === P.plId);
  return pl ? pl.trackIds.filter((id) => trackById(id)) : [];
}
function shuffled(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
function buildWave() {
  const tags = [...P.tags];
  // без связи с ПК ВОЛНА подбирает только из скачанных треков
  let pool = allTracks().filter((t) => connected || dl[t.id]);
  if (tags.length) {
    pool = pool
      .map((t) => ({ id: t.id, score: (t.tags || []).filter((x) => tags.includes(x)).length }))
      .filter((x) => x.score > 0)
      .map((x) => ({ id: x.id, key: x.score + Math.random() * 1.4 - (P.recent.includes(x.id) ? 0.8 : 0) }))
      .sort((a, b) => b.key - a.key)
      .map((x) => x.id);
  } else pool = shuffled(pool.map((t) => t.id));
  return pool.slice(0, 50);
}
function setSource(src) { P.source = src; renderSource(); startQueue(src === "wave" ? buildWave() : sourceIds()); }

// ---------- очередь и воспроизведение ----------
function startQueue(ids, start = 0) {
  P.dirty = true;
  if (!ids.length) { P.queue = []; P.qi = -1; renderCarousel(); renderNow(); return; }
  let q = ids.slice();
  if (P.shuffle && P.source === "playlist") {
    const first = q[start];
    q = shuffled(q.filter((x) => x !== first));
    q.unshift(first);
    start = 0;
  }
  P.queue = q;
  playIndex(start, true, 1);
}
function playIndex(i, autoplay = true, skip = 0, tries = 0) {
  if (i < 0 || i >= P.queue.length) return;
  const t = trackById(P.queue[i]);
  if (!t) return;
  const src = mediaSrc(t);
  if (!src) {
    // трек не скачан и ПК недоступен — пробуем следующий доступный
    if (skip && tries < P.queue.length) return playIndex((i + skip + P.queue.length) % P.queue.length, autoplay, skip, tries + 1);
    toast("Трек не скачан, а связи с ПК нет");
    return;
  }
  P.qi = i;
  P.recent.push(t.id);
  if (P.recent.length > 12) P.recent.shift();
  store.set("zm_last", t.id);
  srcKind = localMedia(t) ? "local" : "remote";
  A.src = src;
  if (autoplay) A.play().catch(() => {}); else A.load();
  if (P.dirty) { P.dirty = false; renderCarousel(); }
  renderNow();
  markPlaying();
}
function nextIndex(manual) {
  if (!P.queue.length) return -1;
  if (P.repeat === 2 && !manual) return P.qi;
  const n = P.qi + 1;
  if (n < P.queue.length) return n;
  if (P.source === "wave") { const q = buildWave(); if (!q.length) return -1; P.queue = q; P.dirty = true; return 0; }
  return P.repeat === 1 || manual ? 0 : -1;
}
function next() { const n = nextIndex(true); if (n >= 0) playIndex(n, true, 1); }
function prev() {
  if (!P.queue.length) return;
  if (A.currentTime > 3) { A.currentTime = 0; return; }
  playIndex(P.qi > 0 ? P.qi - 1 : P.queue.length - 1, true, -1);
}
function toggle() {
  if (!A.src) { setSource(P.source); return; }
  if (A.paused) A.play().catch(() => {}); else A.pause();
}

// ---------- 3D-карусель (рисуем только ближайшие обложки) ----------
const carEls = new Map();
const R = 3;
function renderCarousel() { $("carousel").innerHTML = ""; carEls.clear(); layoutCarousel(); }
function makeCover(i, t) {
  const el = document.createElement("div");
  el.className = "cover";
  const c = coverSrc(t);
  if (c) { el.style.background = `url("${c}") center/cover`; el.innerHTML = `<span class="cap">${esc(t.title)}</span>`; }
  else { el.style.background = gradientFor(t.title || "?"); el.innerHTML = `<span class="glyph">${esc((t.title || "?").charAt(0).toUpperCase())}</span><span class="cap">${esc(t.title)}</span>`; }
  el.onclick = () => (i === P.qi ? toggle() : playIndex(i));
  return el;
}
function posCover(el, off, cs) {
  const a = Math.abs(off);
  el.classList.toggle("center", a === 0);
  if (a > 2) {
    el.style.opacity = 0;
    el.style.pointerEvents = "none";
    el.style.transform = `translateX(${Math.sign(off) * cs * 1.2}px) translateZ(-${cs * 1.4}px) rotateY(${-Math.sign(off) * 60}deg)`;
    return;
  }
  el.style.opacity = a === 0 ? 1 : 0.85 - a * 0.22;
  el.style.pointerEvents = "auto";
  el.style.filter = a === 0 ? "none" : `brightness(${1 - a * 0.15})`;
  el.style.zIndex = 10 - a;
  el.style.transform = `translateX(${off * cs * 0.56}px) translateZ(${-a * cs * 0.5}px) rotateY(${-off * 38}deg) scale(${a === 0 ? 1.06 : 1})`;
}
function layoutCarousel() {
  const box = $("carousel");
  const cs = box.offsetWidth || 200;
  const c = Math.max(P.qi, 0);
  const lo = Math.max(0, c - R), hi = Math.min(P.queue.length - 1, c + R);
  for (const [i, el] of carEls) if (i < lo || i > hi) { el.remove(); carEls.delete(i); }
  for (let i = lo; i <= hi; i++) {
    let el = carEls.get(i);
    if (!el) {
      const t = trackById(P.queue[i]);
      if (!t) continue;
      el = makeCover(i, t);
      el.style.transition = "none";
      box.appendChild(el);
      carEls.set(i, el);
      posCover(el, i - c, cs);
      void el.offsetWidth;
      el.style.transition = "";
    } else posCover(el, i - c, cs);
  }
}
(function swipe() {
  const w = document.querySelector(".carousel-wrap");
  let x0 = null, y0 = 0;
  w.addEventListener("pointerdown", (e) => { x0 = e.clientX; y0 = e.clientY; });
  w.addEventListener("pointerup", (e) => {
    if (x0 === null) return;
    const dx = e.clientX - x0, dy = e.clientY - y0;
    x0 = null;
    if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.4) { dx < 0 ? next() : prev(); }
  });
  w.addEventListener("pointercancel", () => (x0 = null));
})();

// ---------- подписи, мини-плеер, шторка уведомлений ----------
let miniId = null, nowId = null;
function updateMini() {
  const t = cur();
  $("mini").classList.toggle("hidden", !(t && curView !== "player"));
  if (!t || t.id === miniId) return;
  miniId = t.id;
  $("miniTitle").textContent = t.title;
  $("miniArtist").textContent = t.artist;
  const c = coverSrc(t), cv = $("miniCover");
  cv.style.backgroundImage = c ? `url('${c}')` : "";
  cv.textContent = c ? "" : (t.title || "?").charAt(0).toUpperCase();
}
// всплывающие искорки на фоне (только пока играет музыка)
function initSparks() {
  const box = $("sparks");
  if (!box) return;
  for (let i = 0; i < 14; i++) {
    const s = document.createElement("i");
    s.style.cssText = `left:${6 + Math.random() * 88}%;--d:${9 + Math.random() * 10}s;--dl:${-Math.random() * 14}s;--sz:${2 + Math.random() * 3}px;--dx:${(Math.random() - 0.5) * 60}px`;
    box.appendChild(s);
  }
}
function pulseCover() {
  const w = document.querySelector(".carousel-wrap");
  if (!w) return;
  w.classList.remove("pulse"); void w.offsetWidth; w.classList.add("pulse");
}
function renderNow() {
  const t = cur();
  $("npTitle").textContent = t ? t.title : "Ничего не играет";
  $("npArtist").textContent = t ? t.artist : "Выбери трек в библиотеке";
  $("npTags").innerHTML = t && t.tags ? t.tags.map((x) => `<span class="tag">${esc(x)}</span>`).join("") : "";
  const nid = t ? t.id : "";
  if (nid !== nowId) {
    nowId = nid;
    tintFromCover(t ? coverSrc(t) : null);
    const n = document.querySelector(".now");
    n.classList.remove("swap"); void n.offsetWidth; n.classList.add("swap");
    pulseCover();
  }
  layoutCarousel();
  miniId = null;
  updateMini();
  if (t) pushMetadata(t);
}

// ---------- уведомление-плеер (нативная служба ZmPlayer) ----------
let metaFor = null;
const nowState = () => ({ playing: !A.paused, position: A.currentTime || 0, duration: isFinite(A.duration) ? A.duration : 0 });
function pushState() { try { ZmPlayer.update(nowState()).catch(() => {}); } catch (e) { /* нет плагина (браузер) */ } }
async function blobB64(url) {
  const blob = await (await fetch(url)).blob();
  return await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result)); fr.onerror = rej; fr.readAsDataURL(blob); });
}
async function pushMetadata(t) {
  metaFor = t.id;
  try { await ZmPlayer.update({ title: t.title || "", artist: t.artist || "", artwork: "", ...nowState() }); } catch (e) { return; }
  try {
    const url = localCover(t) || (connected && t.cover ? remote(`/cover/${t.id}`) : null);
    if (!url) return;
    const b64 = await blobB64(url);
    if (metaFor === t.id) await ZmPlayer.update({ artwork: b64 });
  } catch (e) { /* без обложки */ }
}
function initMediaSession() {
  try {
    ZmPlayer.addListener("action", (e) => {
      switch (e && e.action) {
        case "play": A.play().catch(() => {}); break;
        case "pause": A.pause(); break;
        case "next": next(); break;
        case "prev": prev(); break;
        case "seekto": if (e.position != null) { A.currentTime = e.position; pushState(); } break;
        default: break;
      }
    });
  } catch (e) { /* нет плагина */ }
  A.addEventListener("seeked", pushState);
  A.addEventListener("durationchange", pushState);
  A.addEventListener("loadedmetadata", pushState);
}
async function checkBattery() {
  try {
    const r = await ZmPlayer.batteryStatus();
    $("battBtn").classList.toggle("hidden", !!r.unrestricted);
  } catch (e) { $("battBtn").classList.add("hidden"); }
}

// ---------- эквалайзер (Web Audio) ----------
const EQ_FREQS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
const EQ_PRESETS = {
  "Плоский": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "Бас": [6, 5, 4, 2, 0, 0, 0, 0, 0, 0], "Вокал": [-2, -1, 0, 2, 4, 4, 3, 1, 0, -1],
  "Высокие": [0, 0, 0, 0, 0, 1, 3, 4, 5, 6], "Рок": [4, 3, 1, -1, -2, 0, 2, 3, 4, 4], "Поп": [-1, 1, 3, 4, 3, 0, -1, -1, 1, 2],
  "Электроника": [5, 4, 1, 0, -2, 1, 0, 2, 4, 5],
};
const eq = Object.assign({ preset: "Плоский", gains: new Array(10).fill(0) }, jget("zm_eq", {}));
let actx = null, eqFilters = [];
function ensureAudioGraph() {
  if (actx) { if (actx.state === "suspended") actx.resume().catch(() => {}); return; }
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    actx = new Ctx();
    const src = actx.createMediaElementSource(A);
    let prevNode = src;
    eqFilters = EQ_FREQS.map((f, i) => {
      const bq = actx.createBiquadFilter();
      bq.type = i === 0 ? "lowshelf" : i === EQ_FREQS.length - 1 ? "highshelf" : "peaking";
      bq.frequency.value = f; bq.Q.value = 1.1; bq.gain.value = eq.gains[i] || 0;
      prevNode.connect(bq); prevNode = bq;
      return bq;
    });
    prevNode.connect(actx.destination);
    if (actx.state === "suspended") actx.resume().catch(() => {});
  } catch (e) { actx = null; toast("Эквалайзер недоступен на этом устройстве"); }
}
function applyEq() { eqFilters.forEach((f, i) => { f.gain.value = eq.gains[i] || 0; }); jset("zm_eq", eq); }
function renderEq() {
  $("eqPreset").innerHTML = ["Свой", ...Object.keys(EQ_PRESETS)].map((p) => `<option${p === eq.preset ? " selected" : ""}>${p}</option>`).join("");
  $("eqBands").innerHTML = EQ_FREQS.map((f, i) => `<div class="band"><span class="gv" id="gv${i}">${eq.gains[i] > 0 ? "+" : ""}${eq.gains[i]}</span><input type="range" min="-12" max="12" step="1" value="${eq.gains[i]}" data-i="${i}" orient="vertical" aria-label="${f} Гц"><span class="fq">${f >= 1000 ? f / 1000 + "k" : f}</span></div>`).join("");
  $("eqBands").querySelectorAll("input").forEach((inp) => {
    setFill(inp);
    inp.oninput = () => {
      const i = +inp.dataset.i;
      eq.gains[i] = +inp.value; eq.preset = "Свой";
      $("gv" + i).textContent = (inp.value > 0 ? "+" : "") + inp.value;
      $("eqPreset").value = "Свой";
      setFill(inp); ensureAudioGraph(); applyEq();
    };
  });
}
function initEq() {
  A.crossOrigin = "anonymous";
  $("eqBtn").onclick = () => { renderEq(); $("eqSheet").classList.add("open"); ensureAudioGraph(); };
  $("eqClose").onclick = () => $("eqSheet").classList.remove("open");
  $("eqSheet").addEventListener("click", (e) => { if (e.target.id === "eqSheet") $("eqSheet").classList.remove("open"); });
  $("eqPreset").onchange = (e) => {
    const n = e.target.value;
    if (EQ_PRESETS[n]) { eq.gains = EQ_PRESETS[n].slice(); eq.preset = n; ensureAudioGraph(); applyEq(); renderEq(); }
  };
  $("eqReset").onclick = () => { eq.gains = new Array(10).fill(0); eq.preset = "Плоский"; applyEq(); renderEq(); };
  if (eq.gains.some((g) => g)) A.addEventListener("play", ensureAudioGraph, { once: true });
}

// ---------- уведомление плеера в шторке ----------
async function notifState() {
  try { return (await LocalNotifications.checkPermissions()).display; } catch (e) { return "unknown"; }
}
async function askNotif(manual) {
  let st = await notifState();
  if (st === "prompt" || st === "prompt-with-rationale") {
    try { st = (await LocalNotifications.requestPermissions()).display; } catch (e) { /* ignore */ }
  }
  if (manual) toast(st === "granted" ? "Уведомления включены" : "Разреши уведомления в настройках Android: Приложения → ZalupaMusic → Уведомления");
  $("notifBtn").classList.toggle("hidden", st === "granted");
}

// ---------- события аудио ----------
let seeking = false, lastSec = -1;
A.addEventListener("play", () => syncPlay(true));
A.addEventListener("pause", () => syncPlay(false));
A.addEventListener("ended", () => { const n = nextIndex(false); if (n >= 0) playIndex(n, true, 1); else syncPlay(false); });
A.addEventListener("error", () => {
  const t = cur();
  if (!t || !A.src) return;
  // локальный файл не открылся — пробуем стримить с ПК
  if (srcKind === "local" && connected) {
    srcKind = "remote";
    const pos = A.currentTime;
    A.src = remote(`/media/${t.id}`);
    A.currentTime = pos || 0;
    A.play().catch(() => {});
  } else toast("Не удалось воспроизвести трек");
});
A.addEventListener("timeupdate", () => {
  const sec = Math.floor(A.currentTime);
  if (sec === lastSec && !seeking) return;
  lastSec = sec;
  const d = A.duration;
  $("tCur").textContent = fmt(A.currentTime);
  $("tDur").textContent = fmt(d);
  if (d && isFinite(d)) {
    if (!seeking) { $("seek").value = Math.round((A.currentTime / d) * 1000); setFill($("seek")); }
    $("miniBar").style.width = (A.currentTime / d) * 100 + "%";
  }
});
function syncPlay(p) {
  document.body.classList.toggle("playing", p);
  $("bPlay").innerHTML = p ? IC.pause : IC.play;
  $("mPlay").innerHTML = p ? IC.pause : IC.play;
  pushState();
}

// ---------- поиск в интернете: только легальные источники ----------
// Jamendo — музыка под лицензиями Creative Commons (можно слушать и скачивать, нужен бесплатный client_id).
// Audius — треки независимых артистов (только слушать онлайн).
const AU = "https://api.audius.co/v1";
const AU_APP = "ZalupaMusic";
const web = { src: store.get("zm_ssrc") || "jamendo", list: [], busy: false, seq: 0, prevKey: null };
const jmKey = () => store.get("zm_jmkey") || "";
const PV = new Audio();           // отдельный плеер для предпрослушивания (без эквалайзера и без CORS)
PV.preload = "none";
async function httpJson(url, params) {
  const r = await CapacitorHttp.get({ url, params, headers: { Accept: "application/json" }, connectTimeout: 12000, readTimeout: 20000 });
  if (r.status >= 400) throw new Error("сервис ответил " + r.status);
  return typeof r.data === "string" ? JSON.parse(r.data) : r.data;
}
async function searchJamendo(q) {
  if (!jmKey()) throw new Error("NOKEY");
  const params = { client_id: jmKey(), format: "json", limit: "40", imagesize: "400", audioformat: "mp32", include: "musicinfo" };
  if (q) params.search = q; else params.order = "popularity_week";
  const d = await httpJson("https://api.jamendo.com/v3.0/tracks/", params);
  if (d.headers && d.headers.status === "failed") throw new Error(d.headers.error_message || "Jamendo вернул ошибку");
  return (d.results || []).map((x) => ({
    src: "jamendo", key: "jm_" + x.id, title: x.name, artist: x.artist_name, duration: x.duration,
    cover: x.image || "", stream: x.audio, download: x.audiodownload_allowed ? x.audiodownload : "",
    tags: ((x.musicinfo && x.musicinfo.tags && x.musicinfo.tags.genres) || []).slice(0, 3),
  }));
}
async function searchAudius(q) {
  const params = { app_name: AU_APP, limit: "40" };
  if (q) params.query = q;
  const d = await httpJson(`${AU}/tracks/${q ? "search" : "trending"}`, params);
  return (d.data || []).filter((x) => !x.access || x.access.stream !== false).map((x) => ({
    src: "audius", key: "au_" + x.id, title: x.title, artist: x.user && x.user.name, duration: x.duration,
    cover: x.artwork ? x.artwork["480x480"] || x.artwork["150x150"] || "" : "",
    stream: `${AU}/tracks/${x.id}/stream?app_name=${AU_APP}`, download: "", tags: [],
  }));
}
async function runWebSearch() {
  const q = $("sq").value.trim();
  const seq = ++web.seq;
  $("sKey").classList.toggle("hidden", web.src !== "jamendo" || !!jmKey());
  if (web.src === "jamendo" && !jmKey()) { $("sList").innerHTML = ""; $("sNote").textContent = ""; return; }
  $("sNote").textContent = web.src === "jamendo"
    ? "Jamendo: свободная музыка (Creative Commons). Можно слушать и сохранять на телефон."
    : "Audius: независимые артисты. Здесь только прослушивание онлайн.";
  $("sList").innerHTML = '<div class="empty">Ищу…</div>';
  try {
    const list = await (web.src === "jamendo" ? searchJamendo(q) : searchAudius(q));
    if (seq !== web.seq) return;
    web.list = list;
    renderWeb();
  } catch (e) {
    if (seq !== web.seq) return;
    $("sList").innerHTML = `<div class="empty">Не получилось: ${esc(e && e.message ? e.message : String(e))}<br>Проверь интернет на телефоне.</div>`;
  }
}
function renderWeb() {
  const box = $("sList");
  box.innerHTML = "";
  if (!web.list.length) { box.innerHTML = '<div class="empty">Ничего не найдено</div>'; return; }
  const frag = document.createDocumentFragment();
  web.list.forEach((r) => {
    const el = document.createElement("div");
    const saved = !!dl[r.key];
    el.className = "row" + (web.prevKey === r.key ? " playing" : "");
    el.dataset.key = r.key;
    el.innerHTML = `<div class="thumb" ${r.cover ? `style="background-image:url('${esc(r.cover)}')"` : ""}>${r.cover ? "" : esc((r.title || "?").charAt(0).toUpperCase())}</div>
      <div class="info"><b>${esc(r.title)}</b><span>${esc(r.artist || "")}${r.duration ? " · " + fmt(r.duration) : ""}</span></div>
      <button class="dlb pv" aria-label="Слушать">${web.prevKey === r.key && !PV.paused ? IC.pause : IC.play}</button>
      ${r.download ? `<button class="dlb sv ${saved ? "on" : ""}" aria-label="Сохранить">${saved ? IC.check : IC.down}</button>` : ""}`;
    el.querySelector(".pv").onclick = (e) => { e.stopPropagation(); previewToggle(r); };
    const sv = el.querySelector(".sv");
    if (sv) sv.onclick = (e) => { e.stopPropagation(); if (!dl[r.key]) saveOnline(r, sv); else toast("Уже на телефоне"); };
    el.onclick = () => previewToggle(r);
    frag.appendChild(el);
  });
  box.appendChild(frag);
}
function previewToggle(r) {
  if (web.prevKey === r.key && !PV.paused) { PV.pause(); renderWeb(); return; }
  if (web.prevKey !== r.key) { web.prevKey = r.key; PV.src = r.stream; }
  A.pause();
  PV.play().catch(() => toast("Не удалось воспроизвести этот трек"));
  renderWeb();
}
PV.addEventListener("pause", () => { if (curView === "search") renderWeb(); });
PV.addEventListener("ended", () => { web.prevKey = null; if (curView === "search") renderWeb(); });
A.addEventListener("play", () => { if (!PV.paused) { PV.pause(); } });
async function saveOnline(r, btn) {
  if (!r.download) { toast("Автор не разрешил скачивание"); return; }
  btn.disabled = true;
  const id = r.key, path = `music/${id}.mp3`;
  try {
    await ensureDirs();
    try { await Filesystem.downloadFile({ url: r.download, path, directory: DIR, recursive: true }); }
    catch (e) { await streamDownload(r.download, path, false); }
    let size = 0;
    try { size = (await Filesystem.stat({ path, directory: DIR })).size || 0; } catch (e) { /* ignore */ }
    if (size && size < 20000) throw new Error("файл получился слишком маленьким");
    let cover = false;
    if (r.cover) { try { await Filesystem.downloadFile({ url: r.cover, path: `covers/${id}.jpg`, directory: DIR, recursive: true }); cover = true; } catch (e) { /* без обложки */ } }
    own = own.filter((o) => o.id !== id);
    own.push({ id, title: r.title, artist: r.artist || "", tags: r.tags || [], ext: "mp3", size, cover: false, web: r.src });
    saveOwn();
    dl[id] = { ext: "mp3", size, cover };
    saveDl();
    reindex();
    renderAll();
    renderWeb();
    toast("Сохранено в библиотеку телефона");
  } catch (e) {
    try { await Filesystem.deleteFile({ path, directory: DIR }); } catch (e2) { /* ignore */ }
    btn.disabled = false;
    toast("Не скачалось: " + ((e && (e.message || e.errorMessage)) || e));
  }
}
function initWebSearch() {
  let timer = null;
  $("sq").oninput = () => { clearTimeout(timer); timer = setTimeout(runWebSearch, 450); };
  const setSrc = (v) => { web.src = v; store.set("zm_ssrc", v); $("sJm").classList.toggle("active", v === "jamendo"); $("sAu").classList.toggle("active", v === "audius"); runWebSearch(); };
  $("sJm").onclick = () => setSrc("jamendo");
  $("sAu").onclick = () => setSrc("audius");
  $("jmSave").onclick = () => {
    const v = $("jmKey").value.trim();
    if (!/^[a-z0-9]{6,}$/i.test(v)) { toast("Это не похоже на client_id"); return; }
    store.set("zm_jmkey", v); runWebSearch();
  };
  $("sJm").classList.toggle("active", web.src === "jamendo");
  $("sAu").classList.toggle("active", web.src === "audius");
}

// ---------- навигация ----------
function show(v) {
  curView = v;
  document.querySelectorAll(".view").forEach((s) => s.classList.toggle("active", s.id === "v-" + v));
  document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t.dataset.v === v));
  if (v === "player") layoutCarousel();
  if (v === "sync") renderSyncUI();
  if (v === "search" && !web.list.length) runWebSearch();
  if (v !== "search" && !PV.paused) PV.pause();
  updateMini();
}

async function connectFromInput() {
  const raw = $("srvInput").value.trim();
  if (!raw) { toast("Вставь ссылку с ПК"); return; }
  let u;
  try { u = new URL(/^https?:\/\//i.test(raw) ? raw : "http://" + raw); } catch (e) { toast("Неверная ссылка"); return; }
  const k = u.searchParams.get("k") || K;
  if (!k) { toast("В ссылке нет ключа (?k=…). Скопируй её на ПК во вкладке «Телефон»"); return; }
  SERVER = normUrl(`http://${u.hostname}:${u.port || "7878"}`);
  K = k;
  store.set("zm_server", SERVER);
  store.set("zm_k", K);
  $("srvInput").value = "";
  discoverTried = false;
  if (await loadLibrary(true)) toast("Подключено");
}

async function init() {
  applyTheme();
  await ensureDirs();
  try {
    musicBase = (await Filesystem.getUri({ path: "music", directory: DIR })).uri;
    coverBase = (await Filesystem.getUri({ path: "covers", directory: DIR })).uri;
  } catch (e) { /* без локальных файлов */ }
  try { Filesystem.addListener("progress", (p) => { sync.cur = p.bytes || 0; if (sync.running) updateProgress(); }); } catch (e) { /* ignore */ }

  document.querySelectorAll(".tab").forEach((t) => (t.onclick = () => show(t.dataset.v)));
  $("themeBtn").onclick = () => { store.set("zm_theme", document.documentElement.dataset.theme === "dark" ? "light" : "dark"); applyTheme(); };
  $("syncTop").onclick = () => loadLibrary(true);
  $("bPlay").onclick = toggle; $("mPlay").onclick = toggle;
  $("bNext").onclick = next; $("mNext").onclick = next;
  $("bPrev").onclick = prev;
  $("miniInfo").onclick = $("miniCover").onclick = () => show("player");
  $("bShuffle").onclick = () => { P.shuffle = !P.shuffle; $("bShuffle").classList.toggle("on", P.shuffle); };
  $("bRepeat").onclick = () => { P.repeat = (P.repeat + 1) % 3; $("bRepeat").classList.toggle("on", P.repeat > 0); $("bRepeat").innerHTML = IC.repeat + (P.repeat === 2 ? "<b class=\"one\">1</b>" : ""); };
  const seek = $("seek");
  seek.addEventListener("pointerdown", () => (seeking = true));
  seek.addEventListener("pointerup", () => (seeking = false));
  seek.addEventListener("input", (e) => { setFill(e.target); if (A.duration) A.currentTime = (e.target.value / 1000) * A.duration; });
  setFill(seek);
  $("srcPl").onclick = () => setSource("playlist");
  $("srcWave").onclick = () => setSource("wave");
  $("plSelect").onchange = (e) => { P.plId = e.target.value; setSource("playlist"); };
  $("moods").onclick = (e) => {
    const m = e.target.dataset && e.target.dataset.m;
    if (!m) return;
    P.tags.has(m) ? P.tags.delete(m) : P.tags.add(m);
    renderSource();
    startQueue(buildWave());
  };
  $("q").oninput = renderLibrary;
  $("fAll").onclick = () => { onlyLocal = false; $("fAll").classList.add("active"); $("fLocal").classList.remove("active"); renderLibrary(); };
  $("fLocal").onclick = () => { onlyLocal = true; $("fLocal").classList.add("active"); $("fAll").classList.remove("active"); renderLibrary(); };
  $("plBack").onclick = () => { openedPl = null; renderPlaylists(); };
  $("plPlay").onclick = () => {
    if (!openedPl) return;
    P.plId = openedPl; P.source = "playlist";
    renderSource(); startQueue(sourceIds()); show("player");
  };
  $("plDl").onclick = () => {
    const pl = ((lib && lib.playlists) || []).find((p) => p.id === openedPl);
    if (!pl) return;
    const list = pl.trackIds.map(trackById).filter((t) => t && !t.missing && (!dl[t.id] || (t.size && dl[t.id].size !== t.size)));
    if (!list.length) { toast("Весь плейлист уже на телефоне"); return; }
    runSync(list);
  };

  // синхронизация и настройки
  $("srvConnect").onclick = connectFromInput;
  $("srvPaste").onclick = async () => { try { $("srvInput").value = await navigator.clipboard.readText(); } catch (e) { toast("Не удалось прочитать буфер. Вставь вручную"); } };
  $("srvFind").onclick = () => { if (!SERVER) { toast("Сначала вставь ссылку с ПК"); return; } tryDiscover(true); };
  $("syncGo").onclick = () => runSync();
  $("syncCancel").onclick = () => { sync.cancel = true; };
  $("tAuto").onchange = (e) => { settings.auto = e.target.checked; saveSettings(); };
  $("tWifi").onchange = (e) => { settings.wifiOnly = e.target.checked; saveSettings(); };
  $("tClean").onchange = (e) => { settings.cleanup = e.target.checked; saveSettings(); };
  $("wipeBtn").onclick = async () => {
    if (!confirm("Удалить все скачанные треки с телефона? На ПК они останутся.")) return;
    for (const dir of ["music", "covers"]) { try { await Filesystem.rmdir({ path: dir, directory: DIR, recursive: true }); } catch (e) { /* пусто */ } }
    dl = {}; saveDl();
    renderAll();
    toast("Загрузки удалены");
  };

  $("bPlay").innerHTML = IC.play; $("mPlay").innerHTML = IC.play;
  $("bPrev").innerHTML = IC.prev; $("bNext").innerHTML = IC.next; $("mNext").innerHTML = IC.next;
  $("bShuffle").innerHTML = IC.shuffle; $("bRepeat").innerHTML = IC.repeat;
  $("eqBtn").innerHTML = IC.eq; $("syncTop").innerHTML = IC.refresh; $("themeBtn").innerHTML = IC.theme;
  $("plDl").innerHTML = IC.down; $("plPlay").innerHTML = IC.play;
  $("tiPlayer").innerHTML = IC.note; $("tiLib").innerHTML = IC.list; $("tiPl").innerHTML = IC.grid; $("tiSync").innerHTML = IC.sync; $("tiSearch").innerHTML = IC.search;
  initSparks();
  initMediaSession();
  initWebSearch();
  $("battBtn").onclick = async () => { try { await ZmPlayer.batteryExempt(); } catch (e) { /* ignore */ } setTimeout(checkBattery, 1500); };
  checkBattery();
  document.addEventListener("visibilitychange", () => { if (!document.hidden) checkBattery(); });
  initEq();
  $("notifBtn").onclick = () => askNotif(true);
  A.addEventListener("play", () => { if (!store.get("zm_np")) { store.set("zm_np", "1"); askNotif(false); } }, { once: true });
  notifState().then((st) => $("notifBtn").classList.toggle("hidden", st === "granted"));
  window.addEventListener("resize", layoutCarousel);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) loadLibrary(false); });
  try { Network.addListener("networkStatusChange", (s) => { if (s.connected) loadLibrary(false); else setConn(false); }); } catch (e) { /* ignore */ }

  setConn(false);
  if (lib) onLibrary(); else renderAll();
  if (!SERVER) show("sync");
  readAdbLink().then(() => { if (!connected) loadLibrary(false); });
  setInterval(() => { if (!document.hidden) readAdbLink(); }, 3000);
}

const splashT0 = performance.now();
function hideSplash() {
  const el = document.getElementById("splash");
  if (!el) return;
  const wait = Math.max(0, 1500 - (performance.now() - splashT0));
  setTimeout(() => { el.classList.add("hide"); setTimeout(() => el.remove(), 700); }, wait);
}

init().finally(hideSplash);
