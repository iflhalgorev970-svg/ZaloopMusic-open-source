// Интерфейс: навигация, библиотека, плейлисты, загрузка с тегами, поиск, эквалайзер, профиль.
let currentView = "player";
let openedPlaylistId = null;

function showView(name) {
  currentView = name;
  if (name !== "phone") clearInterval(phonePoll);
  document.querySelectorAll(".view").forEach((v) => v.classList.toggle("active", v.id === "view-" + name));
  document.querySelectorAll(".nav").forEach((n) => n.classList.toggle("active", n.dataset.view === name));
  if (name === "playlists") renderPlaylists();
  if (name === "library") renderLibrary();
  if (name === "profile") renderProfile();
  if (name === "player") layoutCarousel();
  if (name === "stats") renderStats();
  if (name === "phone") renderPhone();
  closeEqPop();
  updateMini();
}

function applyTheme() {
  document.documentElement.dataset.theme = state.theme;
}

// ---------- Строка трека ----------
function trackRow(t, opts = {}) {
  const row = document.createElement("div");
  row.className = "track";
  row.dataset.id = t.id;
  row.innerHTML = `
    <div class="ico">${esc(t.title.charAt(0).toUpperCase())}</div>
    <div><div class="t">${esc(t.title)}</div><div class="a">${esc(t.artist)}${t.tags.length ? " · " + esc(t.tags.join(", ")) : ""}</div></div>
    <div class="actions"></div><span></span>`;
  const cu = coverUrl(t);
  if (cu) {
    const ico = row.querySelector(".ico");
    ico.textContent = "";
    ico.style.background = `url("${cu}") center/cover`;
  }
  const act = row.querySelector(".actions");
  const mk = (label, fn) => {
    const b = document.createElement("button");
    b.className = "mini";
    b.textContent = label;
    b.onclick = (e) => { e.stopPropagation(); fn(); };
    act.appendChild(b);
  };
  mk("Теги", () => openUploadDialog([{ id: t.id, path: t.path, title: t.title, artist: t.artist, tags: [...t.tags] }], { edit: true }));
  mk("+ в плейлист", () => openAddTo(t.id));
  if (opts.onRemove) mk(opts.removeLabel || "Убрать", opts.onRemove);
  row.onclick = () => {
    player.source = "playlist";
    renderSourceBar();
    startQueue(opts.queue || [t.id], (opts.queue || [t.id]).indexOf(t.id));
  };
  return row;
}

function fillList(box, tracks, optsFor) {
  box.innerHTML = "";
  if (!tracks.length) {
    box.innerHTML = `<div class="empty">Здесь пока пусто</div>`;
    return;
  }
  const ids = tracks.map((t) => t.id);
  tracks.forEach((t, i) => {
    const row = trackRow(t, { queue: ids, ...(optsFor ? optsFor(t) : {}) });
    row.style.setProperty("--i", i);
    box.appendChild(row);
  });
  highlightPlaying();
}

function highlightPlaying() {
  const cur = currentTrack();
  document.querySelectorAll(".track").forEach((r) => r.classList.toggle("playing", !!cur && r.dataset.id === cur.id));
}

// ---------- Библиотека ----------
function renderLibrary() {
  fillList($("libTracks"), state.tracks, (t) => ({
    removeLabel: "Удалить",
    onRemove: () => deleteTrack(t.id),
  }));
}

async function deleteTrack(id) {
  const t = trackById(id);
  if (!t || !confirm(`Удалить «${t.title}» из библиотеки?`)) return;
  state.tracks = state.tracks.filter((x) => x.id !== id);
  state.playlists.forEach((p) => (p.trackIds = p.trackIds.filter((x) => x !== id)));
  if (TAURI && !t.path.startsWith("blob:")) {
    try { await TAURI.core.invoke("delete_track_file", { path: t.path }); } catch (e) { console.error(e); }
  }
  saveState();
  renderLibrary();
  renderPlaylists();
}

// ---------- Плейлисты ----------
function renderPlaylists() {
  const grid = $("playlistGrid");
  const detail = $("playlistDetail");
  if (openedPlaylistId) {
    const pl = state.playlists.find((p) => p.id === openedPlaylistId);
    if (!pl) { openedPlaylistId = null; return renderPlaylists(); }
    grid.classList.add("hidden");
    $("newPlaylistBtn").classList.add("hidden");
    detail.classList.remove("hidden");
    $("plTitle").textContent = pl.name;
    const tracks = pl.trackIds.map(trackById).filter(Boolean);
    fillList($("plTracks"), tracks, (t) => ({
      onRemove: () => { pl.trackIds = pl.trackIds.filter((x) => x !== t.id); saveState(); renderPlaylists(); },
    }));
    return;
  }
  detail.classList.add("hidden");
  grid.classList.remove("hidden");
  $("newPlaylistBtn").classList.remove("hidden");
  grid.innerHTML = "";
  if (!state.playlists.length) grid.innerHTML = `<div class="empty">Создай первый плейлист</div>`;
  state.playlists.forEach((p, i) => {
    const c = document.createElement("div");
    c.className = "glass plcard";
    c.style.setProperty("--i", i);
    c.innerHTML = `<div class="big">${esc(p.name.charAt(0).toUpperCase())}</div><b>${esc(p.name)}</b><span class="muted">${p.trackIds.length} треков</span>`;
    c.onclick = () => { openedPlaylistId = p.id; renderPlaylists(); };
    grid.appendChild(c);
  });
}

function initPlaylists() {
  $("newPlaylistBtn").onclick = () => { $("plName").value = ""; $("plDlg").classList.remove("hidden"); $("plName").focus(); };
  $("plDlgCancel").onclick = () => $("plDlg").classList.add("hidden");
  $("plDlgOk").onclick = () => {
    const name = $("plName").value.trim();
    if (!name) return;
    state.playlists.push({ id: uid(), name, trackIds: [] });
    saveState();
    $("plDlg").classList.add("hidden");
    renderPlaylists();
    renderSourceBar();
  };
  $("plBack").onclick = () => { openedPlaylistId = null; renderPlaylists(); };
  $("plAdd").onclick = () => startUpload(openedPlaylistId);
  $("plPick").onclick = () => openPick(openedPlaylistId);
  $("pickCancel").onclick = () => $("pickDlg").classList.add("hidden");
  $("pickQ").oninput = renderPick;
  $("plPlay").onclick = () => {
    const pl = state.playlists.find((p) => p.id === openedPlaylistId);
    if (!pl) return;
    player.playlistId = pl.id;
    player.source = "playlist";
    renderSourceBar();
    startQueue(sourceTrackIds());
    showView("player");
  };
  $("plDelete").onclick = () => {
    const pl = state.playlists.find((p) => p.id === openedPlaylistId);
    if (!pl || !confirm(`Удалить плейлист «${pl.name}»? Треки останутся в библиотеке.`)) return;
    state.playlists = state.playlists.filter((p) => p.id !== pl.id);
    openedPlaylistId = null;
    saveState();
    renderPlaylists();
    renderSourceBar();
  };
  $("libAdd").onclick = () => startUpload(null);
}

let pickSel = new Set(), pickPl = null;
function openPick(plId) {
  const pl = state.playlists.find((p) => p.id === plId);
  if (!pl) return;
  pickPl = pl;
  pickSel = new Set();
  $("pickQ").value = "";
  $("pickDlg").classList.remove("hidden");
  renderPick();
  $("pickOk").onclick = () => {
    pickSel.forEach((id) => { if (!pl.trackIds.includes(id)) pl.trackIds.push(id); });
    saveState();
    $("pickDlg").classList.add("hidden");
    renderPlaylists();
    renderSourceBar();
  };
}
function renderPick() {
  const q = $("pickQ").value.trim().toLowerCase();
  const box = $("pickList");
  box.innerHTML = "";
  const list = state.tracks.filter((t) => !pickPl.trackIds.includes(t.id) && (!q || (t.title + " " + t.artist + " " + t.tags.join(" ")).toLowerCase().includes(q)));
  if (!list.length) box.innerHTML = `<div class="empty">${state.tracks.length ? "Нет подходящих треков (или все уже в плейлисте)" : "Библиотека пуста"}</div>`;
  list.forEach((t) => {
    const l = document.createElement("label");
    l.className = "pickrow";
    l.innerHTML = `<input type="checkbox" ${pickSel.has(t.id) ? "checked" : ""}><span><b>${esc(t.title)}</b><i>${esc(t.artist || "")}</i></span>`;
    l.querySelector("input").onchange = (e) => { e.target.checked ? pickSel.add(t.id) : pickSel.delete(t.id); $("pickCount").textContent = pickSel.size ? `Выбрано: ${pickSel.size}` : ""; };
    box.appendChild(l);
  });
  $("pickCount").textContent = pickSel.size ? `Выбрано: ${pickSel.size}` : "";
}

function openAddTo(trackId) {
  const box = $("addToList");
  box.innerHTML = "";
  if (!state.playlists.length) box.innerHTML = `<div class="empty">Сначала создай плейлист</div>`;
  state.playlists.forEach((p) => {
    const b = document.createElement("button");
    b.className = "btn";
    b.textContent = (p.trackIds.includes(trackId) ? "✓ " : "") + p.name;
    b.onclick = () => {
      if (!p.trackIds.includes(trackId)) p.trackIds.push(trackId);
      saveState();
      b.textContent = "✓ " + p.name;
    };
    box.appendChild(b);
  });
  $("addToDlg").classList.remove("hidden");
}

// ---------- Загрузка треков с тегами ----------
let uploadDrafts = [];
let uploadMeta = {};
let uploadItems = [];
let uploadRun = 0;

function paintDraft(i) {
  const d = uploadDrafts[i], it = uploadItems[i];
  if (!it) return;
  it.querySelectorAll(".tag").forEach((tg) => tg.classList.toggle("sel", d.tags.includes(tg.dataset.t)));
}

async function autoTagDrafts() {
  const run = ++uploadRun;
  const btn = $("uploadAuto");
  btn.disabled = true;
  for (let i = 0; i < uploadDrafts.length; i++) {
    if (run !== uploadRun) return;
    btn.textContent = `Анализ ${i + 1}/${uploadDrafts.length}…`;
    const d = uploadDrafts[i];
    const f = await analyzeTrack(srcUrl(d.src || d.path));
    if (run !== uploadRun) return;
    d.tags = mergeTags(d.tags, tagsFromFeatures(f), tagsFromGenre(d.genre));
    paintDraft(i);
  }
  btn.disabled = false;
  btn.textContent = "Авто-теги";
}

async function startUpload(playlistId) {
  const files = await pickAudioFiles();
  if (!files.length) return;
  const metas = await readMetas(files.map((f) => f.src));
  openUploadDialog(
    files.map((f, i) => {
      const guess = draftFromName(f.name);
      const m = metas[i] || {};
      return { src: f.src, title: m.title || guess.title, artist: m.artist || guess.artist, cover: m.cover || null, genre: m.genre || "", tags: tagsFromGenre(m.genre) };
    }),
    { playlistId }
  );
}

function openUploadDialog(drafts, meta) {
  uploadDrafts = drafts;
  uploadMeta = meta || {};
  uploadItems = [];
  uploadRun++;
  $("uploadAuto").disabled = false;
  $("uploadAuto").textContent = "Авто-теги";
  const box = $("uploadList");
  box.innerHTML = "";
  drafts.forEach((d, idx) => {
    const item = document.createElement("div");
    item.className = "upitem";
    let tagsHtml = "";
    for (const [group, tags] of Object.entries(TAG_GROUPS)) {
      tagsHtml += `<div class="muted" style="font-size:11px;margin:6px 0 4px">${group}</div><div class="tagpick">` +
        tags.map((x) => `<span class="tag ${d.tags.includes(x) ? "sel" : ""}" data-t="${x}">${x}</span>`).join("") + `</div>`;
    }
    item.innerHTML = `
      <div class="meta">
        <input class="input" data-f="title" value="${esc(d.title)}" placeholder="Название">
        <input class="input" data-f="artist" value="${esc(d.artist)}" placeholder="Артист">
      </div>${tagsHtml}`;
    item.querySelectorAll("[data-f]").forEach((inp) => (inp.oninput = () => (d[inp.dataset.f] = inp.value)));
    item.querySelectorAll(".tag").forEach((tg) => {
      tg.onclick = () => {
        const v = tg.dataset.t;
        d.tags = d.tags.includes(v) ? d.tags.filter((x) => x !== v) : [...d.tags, v];
        tg.classList.toggle("sel");
      };
    });
    box.appendChild(item);
    uploadItems.push(item);
  });
  $("uploadOk").textContent = uploadMeta.edit ? "Сохранить" : "Добавить";
  $("uploadDlg").classList.remove("hidden");
  if (!uploadMeta.edit) autoTagDrafts(); // новые треки размечаем автоматически
}

function initUpload() {
  $("uploadCancel").onclick = () => { uploadRun++; $("uploadDlg").classList.add("hidden"); };
  $("uploadAuto").onclick = autoTagDrafts;
  $("libAuto").onclick = autoTagLibrary;
  $("uploadOk").onclick = async () => {
    uploadRun++;
    if (uploadMeta.edit) {
      uploadDrafts.forEach((d) => {
        const t = trackById(d.id);
        if (t) { t.title = d.title.trim() || t.title; t.artist = d.artist.trim() || t.artist; t.tags = d.tags; }
      });
    } else {
      const paths = await importFiles(uploadDrafts.map((d) => d.src));
      uploadDrafts.forEach((d, i) => {
        if (!paths[i]) return;
        const t = { id: uid(), path: paths[i], title: d.title.trim() || "Без названия", artist: d.artist.trim() || "Неизвестный артист", tags: d.tags, cover: d.cover || null, coverChecked: true };
        state.tracks.push(t);
        if (uploadMeta.playlistId) {
          const pl = state.playlists.find((p) => p.id === uploadMeta.playlistId);
          if (pl) pl.trackIds.push(t.id);
        }
      });
    }
    saveState();
    $("uploadDlg").classList.add("hidden");
    renderLibrary();
    renderPlaylists();
    renderCarousel();
    renderNowPlaying();
    if (currentView === "player" && player.qi < 0 && player.source === "playlist") {
      player.queue = sourceTrackIds();
      renderCarousel();
    }
  };
  $("addToClose").onclick = () => { $("addToDlg").classList.add("hidden"); renderPlaylists(); };
}

// ---------- Авто-теги для уже загруженных треков ----------
let libAutoBusy = false;
async function autoTagLibrary() {
  if (libAutoBusy) return;
  const todo = state.tracks.filter((t) => !t.tags.length);
  const btn = $("libAuto");
  if (!todo.length) { btn.textContent = "Все треки уже с тегами"; setTimeout(() => (btn.textContent = "Авто-теги"), 2500); return; }
  libAutoBusy = true;
  btn.disabled = true;
  const metas = await readMetas(todo.map((t) => t.path));
  for (let i = 0; i < todo.length; i++) {
    btn.textContent = `Анализ ${i + 1}/${todo.length}…`;
    const t = todo[i];
    const f = await analyzeTrack(srcUrl(t.path));
    t.tags = mergeTags(tagsFromFeatures(f), tagsFromGenre(metas[i] && metas[i].genre));
    if (i % 5 === 4) saveState();
  }
  saveState();
  libAutoBusy = false;
  btn.disabled = false;
  btn.textContent = "Авто-теги";
  renderLibrary();
}

// ---------- Поиск ----------
function initSearch() {
  $("searchInput").oninput = (e) => {
    const q = e.target.value.trim().toLowerCase();
    if (!q) return showView(currentView === "search" ? "player" : currentView);
    const res = state.tracks.filter((t) => (t.title + " " + t.artist + " " + t.tags.join(" ")).toLowerCase().includes(q));
    document.querySelectorAll(".view").forEach((v) => v.classList.toggle("active", v.id === "view-search"));
    currentView = "search";
    updateMini();
    fillList($("searchResults"), res);
  };
}

// ---------- Эквалайзер ----------
const EQ_LABELS = ["31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k"];

function buildBands(box) {
  box.innerHTML = "";
  EQ_LABELS.forEach((l, i) => {
    const b = document.createElement("div");
    b.className = "band";
    b.innerHTML = `<span class="db" data-eqi="${i}">${state.eq.gains[i]} дБ</span>
      <input type="range" min="-12" max="12" step="0.5" value="${state.eq.gains[i]}" data-eqi="${i}"><label>${l}</label>`;
    b.querySelector("input").oninput = (e) => setEqBand(i, Number(e.target.value));
    box.appendChild(b);
  });
}

function paintEQ() {
  document.querySelectorAll("input[data-eqi]").forEach((inp) => (inp.value = state.eq.gains[inp.dataset.eqi]));
  document.querySelectorAll("span.db[data-eqi]").forEach((sp) => (sp.textContent = state.eq.gains[sp.dataset.eqi] + " дБ"));
  const p = state.eq.preset in EQ_PRESETS ? state.eq.preset : "Свой";
  $("eqPreset").value = p;
  $("eqPresetPop").value = p;
}

function setEqBand(i, v) {
  state.eq.gains[i] = v;
  state.eq.preset = "Свой";
  engine.setBand(i, v);
  paintEQ();
  saveState();
}

function applyPreset(name) {
  const g = EQ_PRESETS[name];
  if (!g) return;
  state.eq = { preset: name, gains: g.slice() };
  engine.setGains(state.eq.gains);
  paintEQ();
  saveState();
}

function renderEQ() {
  buildBands($("eqBands"));
  buildBands($("eqBandsPop"));
  paintEQ();
}

function closeEqPop() {
  $("eqPop").classList.add("hidden");
  $("btnEq").classList.remove("on");
}

function initEQ() {
  const opts = ["Свой", ...Object.keys(EQ_PRESETS)].map((p) => `<option>${p}</option>`).join("");
  ["eqPreset", "eqPresetPop"].forEach((id) => {
    $(id).innerHTML = opts;
    $(id).onchange = (e) => applyPreset(e.target.value);
  });
  $("eqReset").onclick = () => applyPreset("Плоский");
  $("xfade").value = state.xfade;
  $("xfVal").textContent = state.xfade;
  $("xfade").oninput = (e) => {
    state.xfade = Number(e.target.value);
    engine.xfade = state.xfade;
    $("xfVal").textContent = state.xfade;
    saveState();
  };
  renderEQ();

  // Окошко эквалайзера рядом с кнопками плеера
  $("btnEq").onclick = (e) => {
    e.stopPropagation();
    const open = $("eqPop").classList.toggle("hidden") === false;
    $("btnEq").classList.toggle("on", open);
  };
  document.addEventListener("click", (e) => {
    if (!$("eqPop").classList.contains("hidden") && !$("eqPop").contains(e.target) && e.target !== $("btnEq")) closeEqPop();
  });
  document.addEventListener("keydown", (e) => { if (e.code === "Escape") closeEqPop(); });
}

// ---------- Профиль ----------
let pendingAvatar = null;

function renderProfile() {
  $("pfName").value = state.profile ? state.profile.name : "";
  $("pfAvatarImg").src = pendingAvatar || avatarSrc();
  $("pfStats").textContent = `Треков: ${state.tracks.length} · Плейлистов: ${state.playlists.length}`;
}

function renderMiniProfile() {
  $("miniName").textContent = state.profile ? state.profile.name : "";
  $("miniAvatar").src = avatarSrc();
}

function initProfile() {
  $("pfAvatarInput").onchange = async (e) => {
    if (!e.target.files[0]) return;
    pendingAvatar = await resizeImage(e.target.files[0]);
    $("pfAvatarImg").src = pendingAvatar;
  };
  $("pfSave").onclick = () => {
    const name = $("pfName").value.trim();
    if (!name) return;
    state.profile.name = name;
    if (pendingAvatar) state.profile.avatar = pendingAvatar;
    pendingAvatar = null;
    saveState();
    renderMiniProfile();
  };
  $("miniProfile").onclick = () => showView("profile");

  $("perfSel").value = state.perf || "auto";
  $("perfSel").onchange = (e) => {
    state.perf = e.target.value;
    if (state.perf === "auto") { state.autoLite = undefined; measureFps(); }
    applyPerf();
    saveState();
  };

  // Онбординг
  let obAvatar = null;
  $("obAvatarInput").onchange = async (e) => {
    if (!e.target.files[0]) return;
    obAvatar = await resizeImage(e.target.files[0]);
    $("obAvatarPreview").innerHTML = `<img src="${obAvatar}" alt="">`;
  };
  $("obStart").onclick = () => {
    const name = $("obName").value.trim();
    if (!name) { $("obName").focus(); return; }
    state.profile = { name, avatar: obAvatar };
    saveState();
    $("onboarding").classList.add("hidden");
    renderMiniProfile();
  };
}

// ---------- Статистика ----------
function fmtDur(sec) {
  sec = Math.round(sec);
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
  if (h) return `${h} ч ${m} мин`;
  if (m) return `${m} мин`;
  return `${sec} с`;
}

function plural(n, a, b, c) {
  const m = n % 100, d = n % 10;
  if (m > 10 && m < 20) return c;
  if (d === 1) return a;
  if (d >= 2 && d <= 4) return b;
  return c;
}

function renderStats() {
  const st = state.stats;
  const arts = {};
  let totalSec = 0, totalPlays = 0;
  const heard = [];
  state.tracks.forEach((t) => {
    const p = st.plays[t.id] || 0, sec = st.secs[t.id] || 0;
    if (!p && !sec) return;
    heard.push({ t, p, sec });
    totalSec += sec;
    totalPlays += p;
    const a = arts[t.artist] || (arts[t.artist] = { name: t.artist, p: 0, sec: 0 });
    a.p += p;
    a.sec += sec;
  });
  const box = $("statsBody");
  if (!heard.length) {
    box.innerHTML = `<div class="glass card empty">Пока пусто. Послушай музыку — здесь появятся любимые артисты и треки.</div>`;
    return;
  }
  const topArtists = Object.values(arts).sort((x, y) => y.p - x.p || y.sec - x.sec).slice(0, 8);
  const topTracks = heard.sort((x, y) => y.p - x.p || y.sec - x.sec).slice(0, 5);
  const maxA = Math.max(1, topArtists[0].p), maxT = Math.max(1, topTracks[0].p);

  const artRows = topArtists.map((a, i) => `
    <div class="srow" style="--i:${i}">
      <span class="rank">${i + 1}</span>
      <div class="sinfo"><b>${esc(a.name)}</b>
        <div class="sbar"><i style="width:${Math.max(4, (a.p / maxA) * 100)}%"></i></div></div>
      <span class="muted smeta">${a.p} ${plural(a.p, "раз", "раза", "раз")} · ${fmtDur(a.sec)}</span>
    </div>`).join("");

  const trRows = topTracks.map((x, i) => {
    const cu = coverUrl(x.t);
    const ico = cu ? `style="background:url('${cu}') center/cover"` : "";
    return `
    <div class="srow" style="--i:${i}">
      <span class="rank">${i + 1}</span>
      <div class="sico" ${ico}>${cu ? "" : esc(x.t.title.charAt(0).toUpperCase())}</div>
      <div class="sinfo"><b>${esc(x.t.title)}</b><span class="muted">${esc(x.t.artist)}</span>
        <div class="sbar"><i style="width:${Math.max(4, (x.p / maxT) * 100)}%"></i></div></div>
      <span class="muted smeta">${x.p} ${plural(x.p, "раз", "раза", "раз")}</span>
    </div>`;
  }).join("");

  box.innerHTML = `
    <div class="stat-cards">
      <div class="glass card"><div class="muted">Время прослушивания</div><div class="bignum">${fmtDur(totalSec)}</div></div>
      <div class="glass card"><div class="muted">Прослушиваний</div><div class="bignum">${totalPlays}</div></div>
      <div class="glass card"><div class="muted">Треков в библиотеке</div><div class="bignum">${state.tracks.length}</div></div>
    </div>
    <div class="stat-cols">
      <div class="glass card"><h3>Топ артистов</h3>${artRows}</div>
      <div class="glass card"><h3>Любимые треки</h3>${trRows}</div>
    </div>`;
}

// ---------- Телефон: QR, ссылка, USB, статус ----------
let phonePoll = null;

async function updatePhoneStatus() {
  if (currentView !== "phone") { clearInterval(phonePoll); return; }
  const flow = $("flow"), txt = $("phoneState");
  if (!flow || !txt) return;
  try {
    const st = await TAURI.core.invoke("phone_status");
    const seen = st.lastAgoMs != null && st.lastAgoMs < 20000;
    const run = st.active > 0 || (st.lastAgoMs != null && st.lastAgoMs < 2500);
    flow.classList.toggle("on", seen);
    flow.classList.toggle("run", run);
    txt.className = "phone-status" + (seen ? " ok" : "");
    txt.textContent = run ? "Телефон синхронизируется…" : seen ? "Телефон подключён" : "Ждём телефон…";
  } catch (e) { /* сервер недоступен */ }
}

let adbPoll = null, adbBusy = false;
const adbLinked = new Map(); // serial -> true, чтобы не дёргать телефон повторно
async function pollAdb() {
  if (currentView !== "phone") { clearInterval(adbPoll); return; }
  const st = $("adbState"), devs = $("adbDevs");
  if (!st || !devs || adbBusy) return;
  try {
    const r = await TAURI.core.invoke("adb_status");
    if (!r.adb) {
      st.textContent = "adb не найден";
      st.className = "adb-state";
      $("adbHint").innerHTML = "Для подключения по кабелю нужен <b>adb</b>: он ставится вместе с Android Studio (SDK Platform-Tools). Либо положи <b>adb.exe</b> рядом с ZalupaMusic.exe.";
      devs.innerHTML = "";
      return;
    }
    const list = r.devices;
    const ready = list.filter((d) => d.state === "device");
    for (const k of [...adbLinked.keys()]) if (!ready.some((d) => d.serial === k)) adbLinked.delete(k);
    if (!list.length) { st.textContent = "Телефон не найден. Подключи кабель"; st.className = "adb-state"; devs.innerHTML = ""; return; }
    devs.innerHTML = "";
    list.forEach((d) => {
      const el = document.createElement("div");
      el.className = "adb-dev";
      const label = d.state === "unauthorized" ? "разреши отладку на экране телефона" : d.state !== "device" ? d.state : d.installed ? (adbLinked.has(d.serial) ? "подключён ✓" : "готов") : "приложение не установлено";
      el.innerHTML = `<b>${esc(d.model)}</b><span class="muted small">${esc(label)}</span>`;
      if (d.state === "device") {
        const b = document.createElement("button");
        b.className = "btn" + (d.installed ? "" : " primary");
        b.textContent = d.installed ? "Отправить на телефон" : "Установить приложение";
        b.onclick = () => adbDo(d, true);
        el.appendChild(b);
      }
      devs.appendChild(el);
    });
    const d0 = ready[0];
    if (!d0) { st.textContent = "Разреши отладку на телефоне"; st.className = "adb-state"; return; }
    st.className = "adb-state ok";
    st.textContent = adbLinked.has(d0.serial) ? `${d0.model}: подключён по USB` : `Найден ${d0.model}`;
    if (!adbLinked.has(d0.serial)) adbDo(d0, false);
  } catch (e) { /* ignore */ }
}
async function adbDo(d, manual) {
  if (adbBusy) return;
  adbBusy = true;
  const st = $("adbState");
  try {
    if (!d.installed) {
      if (!manual) { st.textContent = `${d.model}: приложение не установлено`; return; }
      st.textContent = "Устанавливаю приложение…";
      await TAURI.core.invoke("adb_install", { serial: d.serial });
    }
    st.textContent = "Подключаю телефон…";
    await TAURI.core.invoke("adb_link", { serial: d.serial });
    adbLinked.set(d.serial, true);
    st.textContent = `${d.model}: подключён по USB, треки перекидываются…`;
  } catch (e) {
    st.className = "adb-state";
    st.textContent = String(e);
    adbLinked.set(d.serial, true); // не долбим повторно при ошибке; кнопка «Отправить» повторит
  } finally { adbBusy = false; }
}

function bindCopy(btnId, inputId) {
  $(btnId).onclick = async () => {
    try { await navigator.clipboard.writeText($(inputId).value); $(btnId).textContent = "Скопировано ✓"; }
    catch (e) { $(inputId).select(); }
  };
}

async function renderPhone() {
  const box = $("phoneBody");
  if (!TAURI) {
    box.innerHTML = `<div class="glass card empty">Доступно только в установленном приложении.</div>`;
    return;
  }
  box.innerHTML = `
    <div class="glass card adb-card">
      <div class="adb-main">
        <div class="flow" id="flow"><div class="node"><svg viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg></div><div class="lane"><i></i><i></i><i></i><i></i><i></i></div><div class="node phone"><svg viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/></svg></div></div>
        <div id="phoneState" class="phone-status">Ждём телефон…</div>
        <div id="adbState" class="adb-state">Ищу телефон…</div>
        <div id="adbDevs" class="adb-devs"></div>
        <p class="muted small" id="adbHint">Включи на телефоне «Отладку по USB» (Настройки → О телефоне → 7 раз «Номер сборки» → Для разработчиков) и подключи кабель. Дальше всё произойдёт само: приложение откроется и начнёт перекидывать треки. Ни Wi-Fi, ни ссылок, ни QR не нужно.</p>
      </div>
    </div>`;
  clearInterval(phonePoll);
  updatePhoneStatus();
  pollAdb();
  phonePoll = setInterval(updatePhoneStatus, 1500);
  clearInterval(adbPoll);
  adbPoll = setInterval(pollAdb, 2500);
}

// ---------- Производительность ----------
function applyPerf() {
  const lite = state.perf === "lite" || ((state.perf || "auto") === "auto" && state.autoLite === true);
  document.body.classList.toggle("lite", lite);
}

function measureFps() {
  let frames = 0;
  const t0 = performance.now();
  const step = () => {
    frames++;
    if (performance.now() - t0 < 1500) return requestAnimationFrame(step);
    const fps = frames / ((performance.now() - t0) / 1000);
    state.autoLite = fps < 42;
    saveState();
    applyPerf();
  };
  requestAnimationFrame(step);
}

// ---------- Старт ----------
async function boot() {
  await loadState();
  applyTheme();
  applyPerf();
  engine.xfade = state.xfade;
  engine.setVolume(state.volume / 100);
  engine.setGains(state.eq.gains);
  $("vol").value = state.volume;

  document.querySelectorAll(".nav").forEach((n) => (n.onclick = () => { $("searchInput").value = ""; showView(n.dataset.view); }));
  $("themeBtn").onclick = () => {
    state.theme = state.theme === "dark" ? "light" : "dark";
    applyTheme();
    saveState();
  };

  initProfile();
  initPlaylists();
  initUpload();
  initSearch();
  initEQ();
  initPlayerControls();

  // Обложки теперь сжимаются до миниатюр (меньше памяти и лагов) — пересканируем один раз
  if (state.coverV !== 2) {
    state.tracks.forEach((t) => (t.coverChecked = false));
    state.coverV = 2;
  }
  if (state.perf === undefined) state.perf = "auto";
  if (state.perf === "auto" && state.autoLite === undefined) setTimeout(measureFps, 2500);

  // Для уже добавленных треков один раз подтягиваем обложки из файлов
  const unchecked = state.tracks.filter((t) => !t.coverChecked);
  if (TAURI && unchecked.length) {
    readMetas(unchecked.map((t) => t.path)).then((metas) => {
      unchecked.forEach((t, i) => {
        t.coverChecked = true;
        if (metas[i] && metas[i].cover) t.cover = metas[i].cover;
      });
      saveState();
      renderCarousel();
      renderLibrary();
    });
  }

  // Команды из меню трея
  if (TAURI && TAURI.event) {
    let lastAct = 0;
    TAURI.event.listen("tray-action", (e) => {
      const now = Date.now();
      if (now - lastAct < 300) return; // защита от двойного срабатывания
      lastAct = now;
      if (e.payload === "play") $("btnPlay").click();
      if (e.payload === "next") next();
      if (e.payload === "prev") prev();
      if (e.payload === "stop") engine.stop();
    });
  }

  if (!state.profile) $("onboarding").classList.remove("hidden");
  renderMiniProfile();
  renderSourceBar();
  player.queue = sourceTrackIds();
  renderCarousel();
  renderNowPlaying();
  renderLibrary();
}

// ---------- Заставка ----------
const splashT0 = performance.now();
function hideSplash() {
  const el = document.getElementById("splash");
  if (!el) return;
  const wait = Math.max(0, 1700 - (performance.now() - splashT0));
  setTimeout(() => { el.classList.add("hide"); setTimeout(() => el.remove(), 700); }, wait);
}

boot().finally(hideSplash);
