#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod phone;

use lofty::prelude::*;
use serde::Serialize;
use std::collections::hash_map::DefaultHasher;
use std::fs;
use std::hash::{Hash, Hasher};
use std::path::PathBuf;
use tauri::menu::{Menu, MenuItem};
use tauri::tray::{MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent};
use tauri::{Emitter, Manager};
use tauri_plugin_global_shortcut::{Code, GlobalShortcutExt, Shortcut, ShortcutState};

fn show_main(app: &tauri::AppHandle) {
    if let Some(w) = app.get_webview_window("main") {
        let _ = w.show();
        let _ = w.unminimize();
        let _ = w.set_focus();
    }
}

fn data_dir(app: &tauri::AppHandle) -> Result<PathBuf, String> {
    let dir = app.path().app_data_dir().map_err(|e| e.to_string())?;
    fs::create_dir_all(dir.join("music")).map_err(|e| e.to_string())?;
    Ok(dir)
}

/// Copies picked audio files into the app's own music folder.
/// Returns the new absolute paths in the same order (empty string for a failed copy).
#[tauri::command]
fn import_tracks(app: tauri::AppHandle, paths: Vec<String>) -> Result<Vec<String>, String> {
    let music = data_dir(&app)?.join("music");
    let mut out = Vec::new();
    for p in paths {
        let src = PathBuf::from(&p);
        let name = match src.file_name() {
            Some(n) => n.to_string_lossy().to_string(),
            None => {
                out.push(String::new());
                continue;
            }
        };
        let mut dest = music.join(&name);
        let mut i = 1;
        while dest.exists() {
            let stem = src.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
            let ext = src.extension().map(|s| format!(".{}", s.to_string_lossy())).unwrap_or_default();
            dest = music.join(format!("{stem}_{i}{ext}"));
            i += 1;
        }
        if fs::copy(&src, &dest).is_ok() {
            out.push(dest.to_string_lossy().to_string());
        } else {
            out.push(String::new());
        }
    }
    Ok(out)
}

/// Removes a copied track file from disk.
#[tauri::command]
fn delete_track_file(path: String) -> Result<(), String> {
    fs::remove_file(path).map_err(|e| e.to_string())
}

#[derive(Serialize)]
struct Meta {
    title: Option<String>,
    artist: Option<String>,
    genre: Option<String>,
    cover: Option<String>,
}

fn read_one(covers: &PathBuf, path: &str) -> Meta {
    let mut meta = Meta { title: None, artist: None, genre: None, cover: None };
    let Ok(tagged) = lofty::read_from_path(path) else { return meta };
    let Some(tag) = tagged.primary_tag().or_else(|| tagged.first_tag()) else { return meta };

    meta.title = tag.title().map(|s| s.to_string()).filter(|s| !s.trim().is_empty());
    meta.artist = tag.artist().map(|s| s.to_string()).filter(|s| !s.trim().is_empty());
    meta.genre = tag.genre().map(|s| s.to_string()).filter(|s| !s.trim().is_empty());

    if let Some(pic) = tag.pictures().first() {
        let data = pic.data();
        let mut h = DefaultHasher::new();
        data.hash(&mut h);
        // Сжимаем до миниатюры 400x400: огромные обложки сильно грузят память и дают лаги на слабых ПК
        let file = covers.join(format!("t{:x}.jpg", h.finish()));
        if file.exists() {
            meta.cover = Some(file.to_string_lossy().to_string());
        } else if let Ok(img) = image::load_from_memory(data) {
            let thumb = img.thumbnail(400, 400).to_rgb8();
            if thumb.save(&file).is_ok() {
                meta.cover = Some(file.to_string_lossy().to_string());
            }
        }
    }
    meta
}

/// Reads embedded tags (title, artist, cover art) from audio files.
/// Covers are saved to the app's `covers` folder; the cover path is returned.
#[tauri::command]
async fn read_metas(app: tauri::AppHandle, paths: Vec<String>) -> Result<Vec<Meta>, String> {
    let covers = data_dir(&app)?.join("covers");
    fs::create_dir_all(&covers).map_err(|e| e.to_string())?;
    Ok(paths.iter().map(|p| read_one(&covers, p)).collect())
}

/// Loads the saved app state (JSON string) or an empty string on first run.
#[tauri::command]
fn load_state(app: tauri::AppHandle) -> Result<String, String> {
    let f = data_dir(&app)?.join("state.json");
    if f.exists() {
        fs::read_to_string(f).map_err(|e| e.to_string())
    } else {
        Ok(String::new())
    }
}

/// Saves the app state (JSON string).
#[tauri::command]
fn save_state(app: tauri::AppHandle, json: String) -> Result<(), String> {
    let f = data_dir(&app)?.join("state.json");
    fs::write(f, json).map_err(|e| e.to_string())
}

fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        // Системные медиа-клавиши (в т.ч. Fn+F8/F9/F7 на ноутбуках) работают, даже когда окно свёрнуто в трей
        .plugin(
            tauri_plugin_global_shortcut::Builder::new()
                .with_handler(|app, shortcut, event| {
                    if event.state() != ShortcutState::Pressed {
                        return;
                    }
                    let id = match shortcut.key {
                        Code::MediaPlayPause => "play",
                        Code::MediaTrackNext => "next",
                        Code::MediaTrackPrevious => "prev",
                        Code::MediaStop => "stop",
                        _ => return,
                    };
                    let _ = app.emit("tray-action", id.to_string());
                })
                .build(),
        )
        .setup(|app| {
            for code in [Code::MediaPlayPause, Code::MediaTrackNext, Code::MediaTrackPrevious, Code::MediaStop] {
                // если клавишу уже занял другой плеер — просто пропускаем
                let _ = app.global_shortcut().register(Shortcut::new(None, code));
            }
            // Сервер для телефона (библиотека, аудио, обложки по Wi-Fi)
            match data_dir(app.handle()).and_then(phone::start) {
                Ok(info) => {
                    app.manage(info);
                }
                Err(e) => eprintln!("phone server not started: {e}"),
            }

            let show = MenuItem::with_id(app, "show", "Открыть ZalupaMusic", true, None::<&str>)?;
            let play = MenuItem::with_id(app, "play", "Играть / пауза", true, None::<&str>)?;
            let next = MenuItem::with_id(app, "next", "Следующий трек", true, None::<&str>)?;
            let prev = MenuItem::with_id(app, "prev", "Предыдущий трек", true, None::<&str>)?;
            let quit = MenuItem::with_id(app, "quit", "Выход", true, None::<&str>)?;
            let menu = Menu::with_items(app, &[&show, &play, &next, &prev, &quit])?;

            let mut tray = TrayIconBuilder::new()
                .tooltip("ZalupaMusic")
                .menu(&menu)
                .show_menu_on_left_click(false)
                .on_menu_event(|app, event| match event.id.as_ref() {
                    "show" => show_main(app),
                    "quit" => app.exit(0),
                    id => {
                        let _ = app.emit("tray-action", id.to_string());
                    }
                })
                .on_tray_icon_event(|tray, event| {
                    if let TrayIconEvent::Click {
                        button: MouseButton::Left,
                        button_state: MouseButtonState::Up,
                        ..
                    } = event
                    {
                        show_main(tray.app_handle());
                    }
                });
            if let Some(icon) = app.default_window_icon() {
                tray = tray.icon(icon.clone());
            }
            tray.build(app)?;
            Ok(())
        })
        .on_window_event(|window, event| {
            // Крестик сворачивает в трей, музыка продолжает играть. Полный выход: меню трея -> «Выход».
            if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                api.prevent_close();
                let _ = window.hide();
            }
        })
        .invoke_handler(tauri::generate_handler![
            import_tracks,
            delete_track_file,
            read_metas,
            phone::get_phone_link,
            phone::reset_phone_token,
            phone::phone_status,
            phone::adb_status,
            phone::adb_link,
            phone::adb_install,
            load_state,
            save_state
        ])
        .run(tauri::generate_context!())
        .expect("error while running ZalupaMusic");
}
